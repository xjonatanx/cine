<!DOCTYPE html>
<html>
<?php
$title = "Principal";
include "./head.php"
?>

<body style="background-color: #e1e1e1;">
    <div class="container" style="background-color: white; padding-left: 0px; padding-right: 0px;">
      <div class="row" style="width: 100%;">
        <?php
          $active = "peliculas";
          include "./nav.php";
        ?>
      </div>
      <?php
      include "banner_header.php"
      ?>
      <div class="row">
        <div class="cell-sm-full cell-md-full cell-lg-full titulos" id="cartelera_section">
          <b><span>CARTELERA</span></b>
        </div>
        <div style="padding: 30px !important;" class="cell-sm-full cell-md-full cell-lg-full fondo-orange">
          <div class='cartelera-item'>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="cell-sm-full cell-md-full cell-lg-full titulos" id="proximamente_section">
          <b><span>PRÓXIMOS ESTRENOS</span></b>
        </div>
        <div class="cell-sm-full cell-md-full cell-lg-full padding-content fondo-gray">
          <div class='proximos-estrenos-item'>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="cell-sm-full cell-md-full cell-lg-full titulos">
          <b><span>PROMOCIONES</span></b>
        </div>
        <div class="cell-sm-full cell-md-full cell-lg-full slider_movil">
          <div id="slides-promociones-escritorio"></div>
        </div>
        <div class="cell-sm-full cell-md-full cell-lg-full slider_escritorio">
          <div id="slides-promociones-movil"></div>
        </div>
      </div>
      <br><br>
    </div>
  <!-- TOP NAV -->
  <script>
    var id_cine = "";

    function getCartelera(id) {
      $.get("./api/getPeliculasCartelera.php?id_cine=" + id, function(data) {
        data.forEach(function(pelicula) {
          let fecha_pelicula = moment(new Date(pelicula.fecha_inicio_2d)).format('LL').toUpperCase();
          $('.cartelera-item').slick('slickAdd', `<a href='./cartelera_detalle.php?id=${pelicula.id}&nombre=${pelicula.nombre_pelicula}'><div style='margin: 10px;' class='centrar'>
                    ${pelicula.estreno === "1" ? `<div class="movie-details--poster-label">ESTRENO</div>`: ``}
                    <img width="100%" src="${pelicula.cover}"/>
                    <button style="background-color: #636363;" class='button rounded button_horarios secondary'>${pelicula.fecha_inicio_2d ? fecha_pelicula.substring(0, fecha_pelicula.length - 8) : "SIN DEFINIR"}</button>
                    </div></a>`);
        });
      }, "json");
    }

    function getCines() {
      $.get("./api/getCines.php", function(data) {
        if (data.length > 0) {
          var cines_option = "";
          data.forEach(c => {
            cines_option = cines_option + `<option value="${c.id}">${c.nombre}</option>`;
          });
          Metro.dialog.create({
            title: "Información",
            content: `
            <span>Seleccione un cine</span><br>
            <select id="id_cine" data-role="select">
              ${cines_option}
            </select>
            `,
            closeButton: true,
            actions: [{
              caption: "Aceptar",
              cls: "js-dialog-close warning",
              onclick: function() {
                id_cine = $("#id_cine").val();
                localStorage.setItem("id_cine", id_cine);
                getCartelera(id_cine);
                getProximosEstrenos(id_cine);
                getAllSliderPromocionEscritorio(id_cine);
                getAllSliderPromocionMovil(id_cine);
              }
            }]
          });

          /*  */
        }
      }, "json");
    }

    function getProximosEstrenos(id) {
      $.get("./api/getPeliculasProximosEstrenos.php?id_cine=" + id, function(data) {
        data.forEach(function(pelicula) {
          let fecha_pelicula = moment(new Date(pelicula.mes_estreno)).format('LL').toUpperCase();
          $('.proximos-estrenos-item').slick('slickAdd', `<a href='./cartelera_detalle.php?id=${pelicula.id}&nombre=${pelicula.nombre_pelicula}''><div style='margin: 10px;' class='centrar'>
                    <img width="100%" src="${pelicula.cover}"/>
                    <button class='button rounded button_horarios warning'>${pelicula.mes_estreno ? fecha_pelicula.substring(0, fecha_pelicula.length - 8) : "SIN DEFINIR"}</button>
                    </div></a>`);
        });
      }, "json");
    }

    function getAllSliderPromocionEscritorio(id) {
      $.get("./api/getAllSliderPromocionEscritorio.php?id_cine=" + id, function(data) {
        if (data.length > 0) {
          let slide_escritorio = "";
          data.forEach(slide => {
            slide_escritorio = slide_escritorio + `<div data-period="8000" class="slide"><img width="100%" src="${slide.url_slider}"/></div>`;
          });

          $("#slides-promociones-escritorio").append(
            `<div
            data-auto-start="true"
            data-role="carousel" 
            data-bullets="false" 
            data-height="@(max-width: 1920px),300| (max-width: 1366px),300 | (max-width: 1024px),220 | (max-width: 768px),146 | (max-width: 576px),100" 
            data-control-next="<span class='mif-chevron-right'></span>" 
            data-control-prev="<span class='mif-chevron-left'></span>">
            ${slide_escritorio}
          </div>`);
        }
      }, "json");
    }

    function getAllSliderPromocionMovil(id) {
      $.get("./api/getAllSliderPromocionMovil.php?id_cine=" + id, function(data) {
        if (data.length > 0) {
          let slide_movil = "";
          data.forEach(slide => {
            slide_movil = slide_movil + `<div data-period="8000" class="slide d-flex flex-justify-center flex-align-center"><img width="100%" src="${slide.url_slider}"/></div>`;
          });

          $("#slides-promociones-movil").append(
            `<div
            data-auto-start="true"
            data-role="carousel" 
            data-bullets="false" 
            data-height="@(max-width: 1920px),400| (max-width: 1366px),300 | (max-width: 1024px),220 | (max-width: 600px),590 | (max-width: 414px),407 | (max-width: 411px),403 | (max-width: 384px),378 | (max-width: 375px),370 | (max-width: 360px),354 | (max-width: 320px),315" 
            data-control-next="<span class='mif-chevron-right'></span>" 
            data-control-prev="<span class='mif-chevron-left'></span>">
            ${slide_movil}
          </div>`);
        }
      }, "json");
    }

    $(document).ready(function() {
      moment.locale('es');

      if (localStorage.getItem("id_cine")) {
        id_cine = localStorage.getItem("id_cine");
      }

      getCartelera(id_cine);
      getProximosEstrenos(id_cine);
      getAllSliderPromocionEscritorio(id_cine);
      getAllSliderPromocionMovil(id_cine);

      if (!localStorage.getItem("id_cine")) {
        getCines();
      }

      $('.promociones-item').slick({
        arrows: true,
        draggable: false
      });
      $('.cartelera-item').slick({
        infinite: true,
        autoplay: true,
        speed: 1200,
        arrows: true,
        centerMode: false,
        slidesToShow: 6,
        slidesToScroll: 6,
        draggable: false,
        responsive: [{
            breakpoint: 1366,
            settings: {
              draggable: false,
              arrows: true,
              centerMode: false,
              slidesToShow: 5,
              slidesToScroll: 5
            }
          },
          {
            breakpoint: 768,
            settings: {
              draggable: false,
              arrows: true,
              centerMode: false,
              slidesToShow: 3,
              slidesToScroll: 3
            }
          },
          {
            breakpoint: 480,
            settings: {
              draggable: false,
              arrows: true,
              centerMode: false,
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
        ]
      });
      $('.proximos-estrenos-item').slick({
        autoplay: true,
        infinite: true,
        speed: 1200,
        arrows: true,
        centerMode: false,
        slidesToShow: 6,
        slidesToScroll: 6,
        draggable: false,
        responsive: [{
            breakpoint: 1366,
            settings: {
              draggable: false,
              arrows: true,
              centerMode: false,
              slidesToShow: 5,
              slidesToScroll: 5
            }
          },
          {
            breakpoint: 768,
            settings: {
              draggable: false,
              arrows: true,
              centerMode: false,
              slidesToShow: 3,
              slidesToScroll: 3
            }
          },
          {
            breakpoint: 480,
            settings: {
              draggable: false,
              arrows: true,
              centerMode: false,
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
        ]
      });
    });
  </script>

  <?php
  include "./footer.php"
  ?>
  <script src="https://cdn.metroui.org.ua/v4/js/metro.min.js"></script>
</body>
<style>
  .jconfirm-box-container {
    margin: 0 auto !important;
  }
</style>

</html>