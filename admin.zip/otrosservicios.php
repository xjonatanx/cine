<!DOCTYPE html>
<html>
<?php
$title = "Otros servicios";
include "./head.php"
?>
<body style="background-color: #e1e1e1;">
    <div class="container" style="background-color: white; padding-left: 0px; padding-right: 0px;">
      <!-- TOP NAV -->
      <?php 
        $active = "otros_servicios";
        include "./nav.php"; 
      ?>
      <div class="row" style="width: 100%;">
        <div class="cell-sm-12 cell-md-12 cell-lg-12 titulos">
          <b><span>OTROS SERVICIOS</span></b>
        </div>
        <div class="cell-sm-full cell-md-full cell-lg-full">
            <div class="tab-wrap">
    
              <input type="radio" id="tab1" name="tabGroup1" class="tab" checked>
              <label for="tab1">CUMPLEAÑOS</label>
            
              <input type="radio" id="tab2" name="tabGroup1" class="tab">
              <label for="tab2">COLEGIOS</label>
            
              <input type="radio" id="tab3" name="tabGroup1" class="tab">
              <label for="tab3">ENTRADAS CORPORATIVAS</label>
              
              <input type="radio" id="tab4" name="tabGroup1" class="tab">
              <label for="tab4">PUBLICIDAD EN CINES</label>
              <br><br>
              <div class="tab__content">
                <div class="row flex-justify-center flex-align-center">
                    <div class="cell-sm-full cell-md-5 cell-lg-5">
                        <div class="img-container" style="margin-top: 25px; margin-bottom: 25px;">
                            <img id="img_birthday" src="">
                        </div>
                    </div>
                    <div class="cell-sm-full cell-md-5 cell-lg-5 offset-md-1">
                        <p id="birthday-text" style="font-size: 14px; font-weight: 360;"></p>
                    </div>
                </div>
              </div>
            
              <div class="tab__content">
                <div class="row flex-justify-center flex-align-center">
                    <div class="cell-sm-full cell-md-5 cell-lg-5">
                        <div class="img-container" style="margin-top: 25px; margin-bottom: 25px;">
                            <img id="img_colegios" src="">
                        </div>
                    </div>
                    <div class="cell-sm-full cell-md-5 cell-lg-5 offset-md-1">
                        <p id="colegios-text" style="font-size: 14px; font-weight: 360;"></p>
                    </div>
                </div>
              </div>
            
              <div class="tab__content">
                <div class="row flex-justify-center flex-align-center">
                    <div class="cell-sm-full cell-md-5 cell-lg-5">
                        <div class="img-container" style="margin-top: 25px; margin-bottom: 25px;">
                            <img id="img_entradas" src="">
                        </div>
                    </div>
                    <div class="cell-sm-full cell-md-5 cell-lg-5 offset-md-1">
                        <p id="entradas-text" style="font-size: 14px; font-weight: 360;"></p>
                    </div>
                </div>
              </div>
              
              <div class="tab__content">
                <div class="row flex-justify-center flex-align-center">
                    <div class="cell-sm-full cell-md-5 cell-lg-5">
                        <div class="img-container" style="margin-top: 25px; margin-bottom: 25px;">
                            <img id="img_publicidad" src="">
                        </div>
                    </div>
                    <div class="cell-sm-full cell-md-5 cell-lg-5 offset-md-1">
                        <p id="publicidad-text" style="font-size: 14px; font-weight: 360;"></p>
                    </div>
                </div>
              </div>
            
            </div>
        </div>
      </div>
      <div id="div-content"></div>
      <br>
  </div>
  <?php
    include "./footer.php"
  ?>
  <script>
    let params = new URLSearchParams(location.search);
    let section = params.get('section');
    console.log(section)
      $(document).ready(function() {
          if(section === "1") {
              $("#tab1").prop("checked", true);
          } else if(section === "2") {
              $("#tab2").prop("checked", true);
          } else if(section === "3") {
              $("#tab3").prop("checked", true);
          } else if(section === "4") {
              $("#tab4").prop("checked", true);
          } else {
              $("#tab1").prop("checked", true);
          }
          
          $.get("./api/getBirthday.php", function(data){
            $("#birthday-text").append(data[0]["descripcion"]);
            $("#img_birthday").attr("src", `../${data[0]["url_imagen"]}`);
          }, "json");
          $.get("./api/getColegios.php", function(data){
            $("#colegios-text").append(data[0]["descripcion"]);
            $("#img_colegios").attr("src", `../${data[0]["url_imagen"]}`);
          }, "json");
          $.get("./api/getEntrada.php", function(data){
            $("#entradas-text").append(data[0]["descripcion"]);
            $("#img_entradas").attr("src", `../${data[0]["url_imagen"]}`);
          }, "json");
          $.get("./api/getPublicidad.php", function(data){
            $("#publicidad-text").append(data[0]["descripcion"]);
            $("#img_publicidad").attr("src", `../${data[0]["url_imagen"]}`);
          }, "json");
      });
  </script>
</body>
<style>

    h3 {
        margin-top: 0px;
        font-size: 20px;
    }
    .jconfirm-box-container {
        margin: 0 auto !important;
    }
    
    .tab-wrap {
      z-index: 0;
      -webkit-transition: 0.3s box-shadow ease;
      transition: 0.3s box-shadow ease;
      max-width: 100%;
      display: -webkit-box;
      display: -webkit-flex;
      display: -ms-flexbox;
      display: flex;
      -webkit-flex-wrap: wrap;
      -ms-flex-wrap: wrap;
      flex-wrap: wrap;
      position: relative;
      list-style: none;
      background-color: #fff;
    }
    
    .tab { display: none; }
    
    .tab__content {
      padding: 10px 25px;
      background-color: transparent;
      position: absolute;
      width: 100%;
      z-index: -1;
      opacity: 0;
      left: 0;
      -webkit-transform: translateY(-3px);
      transform: translateY(-3px);
    }
    
    .tab:checked:nth-of-type(1) ~ .tab__content:nth-of-type(1) {
      opacity: 1;
      -webkit-transition: 0.5s opacity ease-in, 0.2s transform ease;
      transition: 0.5s opacity ease-in, 0.2s transform ease;
      position: relative;
      top: 0;
      z-index: 100;
      -webkit-transform: translateY(0px);
      transform: translateY(0px);
      text-shadow: 0 0 0;
    }
    
    .tab:checked:nth-of-type(2) ~ .tab__content:nth-of-type(2) {
      opacity: 1;
      -webkit-transition: 0.5s opacity ease-in, 0.2s transform ease;
      transition: 0.5s opacity ease-in, 0.2s transform ease;
      position: relative;
      top: 0;
      z-index: 100;
      -webkit-transform: translateY(0px);
      transform: translateY(0px);
      text-shadow: 0 0 0;
    }
    
    .tab:checked:nth-of-type(3) ~ .tab__content:nth-of-type(3) {
      opacity: 1;
      -webkit-transition: 0.5s opacity ease-in, 0.2s transform ease;
      transition: 0.5s opacity ease-in, 0.2s transform ease;
      position: relative;
      top: 0;
      z-index: 100;
      -webkit-transform: translateY(0px);
      transform: translateY(0px);
      text-shadow: 0 0 0;
    }
    
    .tab:checked:nth-of-type(4) ~ .tab__content:nth-of-type(4) {
      opacity: 1;
      -webkit-transition: 0.5s opacity ease-in, 0.2s transform ease;
      transition: 0.5s opacity ease-in, 0.2s transform ease;
      position: relative;
      top: 0;
      z-index: 100;
      -webkit-transform: translateY(0px);
      transform: translateY(0px);
      text-shadow: 0 0 0;
    }
    
    .tab:first-of-type:not(:last-of-type) + label {
      border-top-right-radius: 0;
      border-bottom-right-radius: 0;
    }
    
    .tab:not(:first-of-type):not(:last-of-type) + label { border-radius: 0; }
    
    .tab:last-of-type:not(:first-of-type) + label {
      border-top-left-radius: 0;
      border-bottom-left-radius: 0;
    }
    
    .tab:checked + label {
      background-color: #EE7821;
      cursor: default;
      color: white;
    }
    
    .tab:checked + label:hover {
      background-color: #EE7821;
      color: white;
    }
    
    .tab + label {
      width: 100%;
      box-shadow: 0 -1px 0 #eee inset;
      cursor: pointer;
      display: block;
      text-decoration: none;
      color: white;
      -webkit-box-flex: 3;
      -webkit-flex-grow: 3;
      -ms-flex-positive: 3;
      flex-grow: 3;
      text-align: center;
      background-color: #636363;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      text-align: center;
      -webkit-transition: 0.3s background-color ease, 0.3s box-shadow ease;
      transition: 0.3s background-color ease, 0.3s box-shadow ease;
      height: 40px;
      box-sizing: border-box;
      padding: 7px;
    }
    @media (min-width:768px) {
    
    .tab + label { width: auto; }
    }
    
    .tab + label:hover {
      background-color: #EE7821;
      color: white;
    }

</style>
</html>
