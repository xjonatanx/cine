<?php
session_start();
if (isset($_SESSION['email'])) {
?>
  <html>
  <?php
  include("./head.php")
  ?>

  <body>
    <?php
    include("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
      <div class="appbar bg-red z-1" data-role="appbar">
        <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
          <span class="mif-menu fg-white"></span>
        </button>
      </div>

      <div class="h-100 p-4">
        <p class="h1">Crear cine</p>
        <br>
        <form data-role="validator" id="form-add-cine" method="post" action="../api/add_cartelera.php" enctype="multipart/form-data">
          <div class="row">
            <div class="cell-md-12">
              <label for="nombre">Imagen del cine (869 x 535)</label>
              <input data-button-title="+" data-validate="required" d="uploadImage" type="file" accept="image/*" name="image" type="file" data-role="file" data-prepend="Seleccione imagen:">
            </div>
            <div class="cell-md-4">
              <br>
              <label for="nombre">Nombre</label>
              <input data-role="input" data-validate="required" name="nombre_cine" id="nombre_cine" type="text" placeholder="Ingrese nombre del cine">
            </div>
            <div class="cell-md-4">
              <br>
              <label for="ciudad">Ciudad</label>
              <input data-role="input" data-validate="required" name="ciudad_cine" id="ciudad_cine" type="text" placeholder="Ingrese ciudad del cine">
            </div>
            <div class="cell-md-4">
              <br>
              <label for="direccion">Dirección</label>
              <input data-role="input" data-validate="required" name="direccion_cine" id="direccion_cine" type="text" placeholder="Ingrese dirección del cine">
            </div>
            <div class="cell-md-6">
              <br>
              <label for="apertura">Hora de apertura</label>
              <input data-validate="required" name="apertura_cine" id="apertura_cine" data-role="timepicker" placeholder="Ingrese horario de apertura del cine">
            </div>
            <div class="cell-md-6">
              <br>
              <label for="cierre">Hora de cierre</label>
              <input data-validate="required" name="cierre_cine" id="cierre_cine" data-role="timepicker" placeholder="Ingrese horario de cierre del cine">
            </div>
            <div class="cell-md-6">
              <br>
              <label id="inicio_cine" for="duracion">Día inicio</label>
              <select name="dia_inicio_cine" id="dia_inicio_cine" data-validate="required" data-role="select">
                <option value="Lunes">Lunes</option>
                <option value="Martes">Martes</option>
                <option value="Miercoles">Miercoles</option>
                <option value="Jueves">Jueves</option>
                <option value="Viernes">Viernes</option>
                <option value="Sábado">Sábado</option>
                <option value="Domingo">Domingo</option>
              </select>
            </div>
            <div class="cell-md-6">
              <br>
              <label for="fin_cine">Día fin</label>
              <select name="dia_fin_cine" id="dia_fin_cine" data-validate="required" data-role="select">
                <option value="Lunes">Lunes</option>
                <option value="Martes">Martes</option>
                <option value="Miercoles">Miercoles</option>
                <option value="Jueves">Jueves</option>
                <option value="Viernes">Viernes</option>
                <option value="Sábado">Sábado</option>
                <option value="Domingo">Domingo</option>
              </select>
            </div>
            <div class="cell-md-12">
              <br>
              <label for="dir_map">Dirección del mapa (Google Maps)</label>
              <input data-role="input" name="dir_map_cine" id="dir_map_cine" data-validate="required" id="url_trailer" type="text" placeholder="Ingrese dirección del mapa">
            </div>
          </div>
          <br>
          <div class="centrar">
            <button onclick="history.back(); return false;" class="button js-dialog-close">Regresar</button>
            <button class="button warning js-dialog-close">Registrar Cine</button>
          </div>
          <br><br><br>
        </form>
      </div>
    </div>

    <script>
      $(document).ready(function() {
        $("#form-add-cine").submit(function(e) {
          e.preventDefault();
          var nombre_cine = $("#nombre_cine").val();
          var ciudad_cine = $("#ciudad_cine").val();
          var direccion_cine = $("#direccion_cine").val();
          var apertura_cine = $("#apertura_cine").val();
          var cierre_cine = $("#cierre_cine").val();
          var dia_inicio_cine = $("#dia_inicio_cine").val();
          var dia_fin_cine = $("#dia_fin_cine").val();
          var dir_map_cine = $("#dir_map_cine").val();
          if (
            nombre_cine !== "" && ciudad_cine !== "" && direccion_cine !== "" &&
            apertura_cine !== "" && cierre_cine !== "" && dia_inicio_cine !== "" &&
            dia_fin_cine !== "" && dir_map_cine !== ""
          ) {
            $.ajax({
              url: "../api/addCine.php",
              type: "POST",
              data: new FormData(this),
              contentType: false,
              cache: false,
              processData: false,
              success: function(result) {
                if (result == 1) {
                  PNotify.success({
                    title: 'Información',
                    text: 'Cine registrado correctamente.'
                  });
                  setTimeout(function() {
                    location.href = "./admin_cines.php"
                  }, 3000);
                } else {
                  PNotify.error({
                    title: 'Información',
                    text: 'No fue posible registrar el cine, verifique que todos los campos han sido completados.'
                  });
                }
              }
            });
          } else {
            PNotify.info({
              title: 'Advertencia',
              text: 'Debes completar todos los campos.'
            });
          }
        });
      });
    </script>
    <?php
    include("./footer.php");
    ?>
  </body>

  </html>
<?php
} else {
  // Redirect them to the login page
  header("Location: ./index.php");
}
?>