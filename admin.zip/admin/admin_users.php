<?php
session_start();
if ( isset( $_SESSION['email'] ) ) {
?>
<html>
  <?php 
    include ("./head.php")
  ?>
  <body>
    <?php
      include ("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
        <div class="appbar bg-red z-1" data-role="appbar">
            <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
                <span class="mif-menu fg-white"></span>
            </button>
        </div>

        <div class="h-100 p-4">
            <p class="h1">Administrar Usuarios</p>
            <br>
            <a href="./create_usuario.php" class="button warning"><span class="mif-add icon"></span> Agregar Usuarios</a>
            <br><br>
            <div id="data-user"></div>
        </div>
    </div>
    <script>
        function desbloquearUser(id_usuario, email) {
            Metro.dialog.create({
                title: "Advertencia",
                content: `¿Está seguro que desea desbloquear a ${email}?`,
                width: "580",
                actions: [
                    {
                        caption: "Aceptar",
                        cls: "js-dialog-close alert",
                        onclick: function(){
                            $.post("../api/desbloquearUser.php", 
                            { 
                                id: id_usuario
                            }, function(result) {
                                if (result == 1) {
                                    Swal.fire(
                                        'Información.',
                                        `El usuario ${email} ha sido desbloqueado correctamente!`,
                                        'success'
                                    ).then((r) => {
                                        location.href = "./admin_users.php"
                                    })
                                } else {
                                    Swal.fire({
                                        type: 'error',
                                        title: 'Oops...',
                                        text: 'Ha ocurrido un error!',
                                        footer: `${result}`
                                    })
                                }
                            })
                        }
                    },
                    {
                        caption: "Cancelar",
                        cls: "js-dialog-close",
                        onclick: function(){
                        }
                    }
                ]
            });
        }
        
        function bloquearUser(id_usuario, email) {
            Metro.dialog.create({
                title: "Advertencia",
                content: `¿Está seguro que desea bloquear a ${email}?`,
                width: "550",
                actions: [
                    {
                        caption: "Aceptar",
                        cls: "js-dialog-close alert",
                        onclick: function(){
                            $.post("../api/bloquearUser.php", 
                            { 
                                id: id_usuario
                            }, function(result) {
                                if (result == 1) {
                                    Swal.fire(
                                        'Información.',
                                        `El usuario ${email} ha sido bloqueado correctamente!`,
                                        'success'
                                    ).then((r) => {
                                        location.href = "./admin_users.php"
                                    })
                                } else {
                                    Swal.fire({
                                        type: 'error',
                                        title: 'Oops...',
                                        text: 'Ha ocurrido un error!',
                                        footer: `${result}`
                                    })
                                }
                            })
                        }
                    },
                    {
                        caption: "Cancelar",
                        cls: "js-dialog-close",
                        onclick: function(){
                        }
                    }
                ]
            });
        }
        function changePassword(id_usuario) {
            Metro.dialog.create({
                title: "Cambio de contraseña",
                content: `<label for="passwd">Ingrese nueva contraseña</label><input id="passwd" name="passwd" type="password" data-role="input">`,
                actions: [
                    {
                        caption: "Aceptar",
                        cls: "js-dialog-close",
                        onclick: function(){
                            let passwd = $("#passwd").val();
                            if(passwd !== "") {
                                $.post("../api/changePassword.php", 
                                    { 
                                        id: id_usuario,
                                        passwd: passwd
                                    }, function(result) {
                                        if (result == 1) {
                                            Swal.fire(
                                                'Información.',
                                                `La contraseña ha sido actualizada correctamente!`,
                                                'success'
                                            ).then((r) => {
                                                location.href = "./admin_users.php"
                                            })
                                        } else {
                                            Swal.fire({
                                                type: 'error',
                                                title: 'Oops...',
                                                text: 'Ha ocurrido un error!',
                                                footer: `${result}`
                                            })
                                        }
                                })
                            } else {
                                Swal.fire(
                                    'Acción cancelada.',
                                    `No se ha ingresado una contraseña`,
                                    'error'
                                )
                            }
                            
                        }
                    },
                    {
                        caption: "Cancelar",
                        cls: "js-dialog-close alert",
                        onclick: function(){
                        }
                    }
                ]
            });
        }
        
        function deleteUser (cell) {
            var id = $(event.target).parents("tr").find("td").eq(2).text();
            var url = $(event.target).parents("tr").find("td").eq(6).text();
            Swal.fire({
                title: '¿Estás seguro?',
                text: `Estas a punto de eliminar un usuario.`,
                type: 'warning',
                showCancelButton: true,
                cancelButtonText: 'Cancelar',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Aceptar'
            }).then((result) => {
                if (result.value) {
                    $.post("../api/deleteUser.php", 
                    { 
                        id: id,
                        url: url
                    }, function(result) {
                        if (result == 1) {
                            Swal.fire(
                                'Usuario eliminado.',
                                `Usuario ha sido eliminado correctamente!`,
                                'success'
                            ).then((r) => {
                                location.href = "./admin_users.php"
                            })
                        } else {
                            Swal.fire({
                                type: 'error',
                                title: 'Oops...',
                                text: 'Ha ocurrido un error!',
                                footer: `${result}`
                            })
                        }
                    })
                }
            })
        }
        function editarUser() {
            var id = $(event.target).parents("tr").find("td").eq(2).text();
            var destino = "./editarUser.php" + "?" + "id=" + id;
            location.href = destino;
        }
        $(document).ready(function() {
            $.get("../api/getAllUsers.php", function(data){
                let filas = [];
                let tbody = "";
                for (  i = 0 ; i < data.length; i++){ //cuenta la cantidad de registros
                    var nuevafila= "<tr><td>" +
                    data[i].id + "</td><td>" +
                    `<img width="50px" height="50px" src="../${data[i].avatar}"/></td><td>` +
                    data[i].email + "</td><td>" +
                    `${data[i].bloqueado === "0" ? "<span style='color: green;'>HABILITADO</span>" : "<span style='color: red;'>BLOQUEADO</span>"}` + "</td><td>" +
                    data[i].avatar + "</td><td>" +
                    `<button onclick='editarUser()' class='button info'>Editar</button><button style='margin-left: 10px;' onclick='changePassword(${data[i].id})' class='button yellow'>Cambiar Contraseña</button><button onclick='deleteUser(this)' style='margin-left: 10px;' class='button alert'>Eliminar</button>${data[i].bloqueado === "0" ? `<button onclick='bloquearUser(${data[i].id}, "${data[i].email}")' style='margin-left: 10px;' class="button warning">Bloquear</button>` : `<button onclick='desbloquearUser(${data[i].id}, "${data[i].email}")' style='margin-left: 10px;' class="button Secondary">Desbloquear</button>`}</td></tr>`;
                    filas.push(nuevafila);
                }
                for (let i = 0; i < filas.length; i++) {
                    tbody = tbody + filas[i]
                }
                $("#data-user").append(`
                    <table data-table-info-title="Visualizando $1 a $2 de $3 resultados" data-pagination-prev-title="Página anterior" data-pagination-next-title="Página siguiente" data-table-search-title="Búsqueda avanzada" data-role="table" data-show-rows-steps="false" class="table table-border cell-border">
                        <thead>
                            <tr>
                                <th data-show="false">#</th>
                                <th data-size="20">Foto de perfil</th>
                                <th data-size="20">Email</th>
                                <th>Bloqueado</th>
                                <th data-show="false">Dirección</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        ${tbody}
                        </tbody>
                    </table>
                `)
            }, "json");
        });
    </script>
    <?php
      include ("./footer.php");
    ?>
  </body>
</html>
<?php
} else {
    // Redirect them to the login page
    header("Location: ./index.php");
}
?>