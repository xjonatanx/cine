<?php
session_start();
if ( isset( $_SESSION['email'] ) ) {
?>
<html>
  <?php 
    include ("./head.php")
  ?>
  <body>
    <?php
      include ("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
        <div class="appbar bg-red z-1" data-role="appbar">
            <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
                <span class="mif-menu fg-white"></span>
            </button>
        </div>

        <div class="h-100 p-4">
            <p class="h1">Administrar Cines</p>
            <br>
            <a href="./create_cine.php" class="button warning"><span class="mif-add icon"></span> Agregar Cine</a>
            <br><br>
            <div id="data-cines"></div>
        </div>
    </div>

    <script>
        function editarCine() {
            var id = $(event.target).parents("tr").find("td").eq(2).text();
            var destino = "./editarCine.php" + "?" + "id=" + id;
            location.href = destino;
        }

        function deleteCine (cell) {
            var id = $(event.target).parents("tr").find("td").eq(2).text();
            var nombre_cine = $(event.target).parents("tr").find("td").eq(3).text();
            Swal.fire({
                title: '¿Estás seguro?',
                text: `Estás a punto de eliminar a ${nombre_cine}`,
                type: 'warning',
                showCancelButton: true,
                cancelButtonText: 'Cancelar',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Aceptar'
            }).then((result) => {
                if (result.value) {
                    $.post("../api/deleteCine.php", 
                    { 
                        id: id,
                    }, function(resultado) {
                        if (resultado == 1) {
                            Swal.fire(
                                'Cine eliminado!',
                                `${nombre_cine} ha sido eliminado correctamente!`,
                                'success'
                            ).then((r) => {
                                location.href = "./admin_cines.php"
                            })
                        } else {
                            PNotify.error({
                                title: 'Error',
                                text: resultado
                            });
                        }
                    })
                }
            })
        }
        $(document).ready(function() {
            $.get("../api/getCines.php", function(data){
                let filas = [];
                let tbody = "";
                for (  i = 0 ; i < data.length; i++){ //cuenta la cantidad de registros
                    var nuevafila= "<tr><td>" +
                    data[i].id + "</td><td>" +
                    data[i].nombre + "</td><td>" +
                    data[i].ciudad + "</td><td>" +
                    data[i].hora_apertura.substring(0, data[i].hora_apertura.length - 3) + "</td><td>" +
                    data[i].hora_cierre.substring(0, data[i].hora_cierre.length - 3) + "</td><td>" +
                    data[i].dia_inicio + "</td><td>" +
                    data[i].dia_fin + "</td><td>" +
                    "<button onclick='editarCine()' class='button info'>Editar</button><button onclick='deleteCine()' style='margin-left: 10px;' class='button alert'>Eliminar</button></td></tr>";
                    filas.push(nuevafila);
                }
                for (let i = 0; i < filas.length; i++) {
                    tbody = tbody + filas[i]
                }
                $("#data-cines").append(`
                    <table data-table-info-title="Visualizando $1 a $2 de $3 resultados" data-pagination-prev-title="Página anterior" data-pagination-next-title="Página siguiente" data-table-search-title="Búsqueda avanzada" data-role="table" data-show-rows-steps="false" class="table table-border cell-border">
                        <thead>
                            <tr>
                                <th data-show="false">#</th>
                                <th data-sortable="true">Nombre</th>
                                <th data-sortable="true">Ciudad</th>
                                <th data-sortable="true">Hora de apertura</th>
                                <th data-sortable="true">Hora de cierre</th>
                                <th>Dia inicio</th>
                                <th>Dia fin</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        ${tbody}
                        </tbody>
                    </table>
                `)
            }, "json");
        });
    </script>
    <?php
      include ("./footer.php");
    ?>
  </body>
</html>
<?php
} else {
    // Redirect them to the login page
    header("Location: ./index.php");
}
?>