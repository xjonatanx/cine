<?php
session_start();
if (isset($_SESSION['email'])) {
?>
  <html>
  <?php
  include("./head.php")
  ?>

  <body>
    <?php
    include("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
      <div class="appbar bg-red z-1" data-role="appbar">
        <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
          <span class="mif-menu fg-white"></span>
        </button>
      </div>

      <div class="h-100 p-4">
        <p class="h1">Editar pelicula</p>
        <br>
        <div class="row">
          <div class="cell-md-6">
            <form data-role="validator" id="form-cover-peliculas" method="post" enctype="multipart/form-data">
              <div class="row">
                <div class="cell-md-2" style="padding: 0px !important;">
                  <div class="img-container thumbnail"><img id="img_cover" width="300px" height="200px" src="" alt=""></div>
                  <br>
                </div>
                <div class="cell-md-10" style="padding: 0px !important;">
                  <label for="nombre">Imagen cover (405 x 607)</label>
                  <input data-button-title="+" data-validate="required" id="uploadImageCover" type="file" accept="image/*" name="imageCover" type="file" data-role="file" data-prepend="Seleccione imagen:">
                  <input style="display: none;" type="text" id="id_pelicula_cover" name="id_pelicula_cover" />
                  <input style="display: none;" type="text" id="url_imagen_cover_actual" name="url_imagen_cover_actual" />
                  <br>
                  <button class="button info js-dialog-close">Cambiar Imagen</button>
                  <br><br>
                </div>
              </div>
            </form>
          </div>
          <div class="cell-md-6">
            <form data-role="validator" id="form-banner-peliculas" method="post" enctype="multipart/form-data">
              <div class="row">
                <div class="cell-md-2" style="padding: 0px !important;">
                  <div class="img-container thumbnail"><img id="img_banner" width="300px" height="200px" src="" alt=""></div>
                  <br>
                </div>
                <div class="cell-md-10" style="padding: 0px !important;">
                  <label for="nombre">Imagen banner (1480 x 500)</label>
                  <input data-button-title="+" data-validate="required" id="uploadImageBanner" type="file" accept="image/*" name="imageBanner" type="file" data-role="file" data-prepend="Seleccione imagen:">
                  <input style="display: none;" type="text" id="id_pelicula_banner" name="id_pelicula_banner" />
                  <input style="display: none;" type="text" id="url_imagen_banner_actual" name="url_imagen_banner_actual" />
                  <br>
                  <button class="button info js-dialog-close">Cambiar Imagen</button>
                  <br><br>
                </div>
              </div>
            </form>
          </div>
        </div>
        <br>
        <form data-role="validator" id="form-edit-pelicula" method="post" enctype="multipart/form-data">
          <div class="row">
            <div class="cell-md-3">
              <label for="nombre">Nombre Pelicula</label>
              <input data-role="input" style="width: 100%;" data-validate="required" name="nombre_pelicula" id="nombre_pelicula" type="text" placeholder="Ingrese nombre de la pelicula">
              <br>
            </div>
            <div class="cell-md-3">
              <label for="director">Director Pelicula</label>
              <input data-role="input" style="width: 100%;" name="director_pelicula" id="director_pelicula" type="text" placeholder="Ingrese director de la pelicula">
              <br>
            </div>
            <div class="cell-md-3">
              <label for="director">Reparto</label><br>
              <input data-role="input" style="width: 100%;" name="reparto_pelicula" id="reparto_pelicula" type="text" placeholder="Ingrese reparto de la pelicula">
              <br>
            </div>
            <div class="cell-md-2 centrar">
              <label for="proximo_estreno">Próximo estreno</label>
              <br>
              <div id="proximamente"></div>
              <br>
            </div>
            <div class="cell-md-1 centrar">
              <label for="restriccion">Restriccón</label>
              <br>
              <div id="status_restriccion"></div>
              <br>
            </div>
            <div class="cell-md-6 fecha_restriccion">
              <label for="fecha_i_restriccion">Fecha inicio restricción</label>
              <input data-role="input" style="width: 100%;" id="fecha_inicio_restriccion" name="fecha_inicio_restriccion" type="text" datepicker data-date-format="mm/dd/yyyy">
              <br>
            </div>
            <div class="cell-md-6 fecha_restriccion">
              <label for="fecha_f_restriccion">Fecha fin restricción</label>
              <input data-role="input" style="width: 100%;" id="fecha_fin_restriccion" name="fecha_fin_restriccion" type="text" datepicker data-date-format="mm/dd/yyyy">
              <br>
            </div>
            <div class="cell-md-12">
              <label for="sinopsis">Sinopsis Pelicula</label>
              <textarea data-validate="required" name="sinopsis_pelicula" id="sinopsis_pelicula" data-role="textarea" placeholder="Ingrese sinopsis de la pelicula"></textarea>
              <br>
            </div>
            <div class="cell-md-3">
              <label for="nombre">Dirección trailer (URL)</label>
              <input style="width: 100%;" data-role="input" name="url_trailer" data-validate="required" id="url_trailer" type="text" placeholder="Ingrese url del trailer">
              <br>
            </div>
            <div class="cell-md-3">
              <label for="duracion">Duración (Minutos)</label>
              <input style="width: 100%;" type="text" data-role="input" name="duracion_pelicula" id="duracion_pelicula">
              <br>
            </div>
            <div class="cell-md-3">
              <label for="tipo_pelicula">Cine</label>
              <div id="listado_cines"></div>
              <br>
            </div>
            <div class="cell-md-3 centrar preventa">
              <label for="preventa">Mes de estreno</label>
              <br>
              <input style="width: 100%;" data-role="input" id="mes_estreno" name="mes_estreno" type="text" datepicker data-date-format="dd/mm/yyyy">
              <br>
            </div>
            <div class="cell-md-3 centrar proximo">
              <label for="tipo_pelicula">Tipo de pelicula</label>
              <br>
              <span id="3d"></span>
              <span id="2d"></span>
              <br><br>
            </div>
            <div class="cell-md-3">
              <label for="clasificacion">Clasificación</label>
              <br>
              <select data-role="select" style="width: 100%;" name="clasificacion" id="clasificacion">
                <option value="TE">TODO ESPECTADOR</option>
                <option value="TE+7">TODO ESPECTADOR, INCONVENIENTE PARA MENORES DE 7 AÑOS</option>
                <option value="+14">MAYORES DE 14 AÑOS</option>
              </select>
              <br>
            </div>
            <div class="cell-md-2 centrar proximo">
              <label for="estreno">Estreno</label>
              <br>
              <div id="status_estreno"></div>
              <br>
            </div>
            <div class="cell-md-2 centrar preventa">
              <label for="preventa">Preventa</label>
              <br>
              <div id="status_preventa"></div>
              <br>
            </div>
            <div class="cell-md-3 active_preventa">
              <label for="fecha_inicio_preventa">Fecha inicio preventa</label>
              <input data-role="input" style="width: 100%;" id="fecha_inicio_preventa" name="fecha_inicio_preventa" type="text" datepicker data-date-format="mm/dd/yyyy">
              <br>
            </div>
            <div class="cell-md-3 active_preventa">
              <label for="fecha_fin_preventa">Fecha fin preventa</label>
              <input data-role="input" style="width: 100%;" id="fecha_fin_preventa" name="fecha_fin_preventa" type="text" datepicker data-date-format="mm/dd/yyyy">
              <br>
            </div>
            <div class="cell-md-3 active_preventa">
              <label for="horario_preventa">Horario preventa (Doblada)</label>
              <div id="content_horario_preventa"></div>
              <br>
            </div>
            <div class="cell-md-3 active_preventa">
              <label for="horario_preventa">Horario preventa (Subtitulada)</label>
              <div id="content_horario_preventa_subtitulada"></div>
              <br>
            </div>
            <div class="cell-md-12 view_2d proximo">
              <h5>FORMATO 2D</h5>
            </div>
            <div class="cell-md-3 view_2d proximo">
              <label for="tipo_pelicula">Fecha inicio</label><br>
              <input data-role="input" style="width: 100%;" name="fecha_inicio_2d" id="fecha_inicio_2d" type="text" datepicker data-date-format="dd/mm/yyyy">
              <br>
            </div>
            <div class="cell-md-3 view_2d proximo">
              <label for="tipo_pelicula">Fecha fin</label><br>
              <input data-role="input" style="width: 100%;" name="fecha_fin_2d" id="fecha_fin_2d" type="text" datepicker data-date-format="dd/mm/yyyy">
              <br>
            </div>
            <div class="cell-md-3 view_2d proximo">
              <label for="tipo_pelicula">Horarios (Doblada)</label>
              <div id="horarios_2d"></div>
              <br>
            </div>
            <div class="cell-md-3 view_2d proximo">
              <label for="tipo_pelicula">Horarios (Subtitulada)</label>
              <div id="horarios_2d_subtitulada"></div>
              <br>
            </div>
            <div class="cell-md-12 view_3d proximo">
              <h5>FORMATO 3D</h5>
            </div>
            <div class="cell-md-3 view_3d proximo">
              <label for="tipo_pelicula">Fecha inicio</label><br>
              <input data-role="input" style="width: 100%;" name="fecha_inicio_3d" id="fecha_inicio_3d" type="text" datepicker data-date-format="dd/mm/yyyy">
              <br>
            </div>
            <div class="cell-md-3 view_3d proximo">
              <label for="tipo_pelicula">Fecha fin</label><br>
              <input data-role="input" style="width: 100%;" name="fecha_fin_3d" id="fecha_fin_3d" type="text" datepicker data-date-format="dd/mm/yyyy">
              <br>
            </div>
            <div class="cell-md-3 view_3d proximo">
              <label for="tipo_pelicula">Horarios (Doblada)</label>
              <div id="horarios_3d"></div>
              <br>
            </div>
            <div class="cell-md-3 view_3d proximo">
              <label for="tipo_pelicula">Horarios (Subtitulada)</label>
              <div id="horarios_3d_subtitulada"></div>
              <br>
            </div>
          </div>
          <br><br>
          <div class="centrar">
            <button onclick="history.back();" class="button js-dialog-close">Regresar</button>
            <button onclick="editarPelicula();" class="button warning js-dialog-close">Editar Pelicula</button>
          </div>
        </form>
        <br><br><br>
      </div>
    </div>

    <script>
      let params = new URLSearchParams(location.search);
      var id_pelicula = params.get('id');
      var url_actual_cover = "";
      var url_actual_banner = "";
      var id_cine = "";

      function editarPelicula() {
        var mes_estreno = new Date($("#mes_estreno").datepicker("getDate"));
        mes_estreno = (mes_estreno.getMonth() + 1) + "/" + mes_estreno.getDate() + "/" + mes_estreno.getFullYear();

        var id_cine = $("#id_cine").val();
        var nombre_pelicula = $("#nombre_pelicula").val();
        var director_pelicula = $("#director_pelicula").val();
        var reparto_pelicula = $("#reparto_pelicula").val();
        var clasificacion = $("#clasificacion").val();
        var restriccion_idioma = $("#restriccion_idioma").val();
        var sinopsis_pelicula = $("#sinopsis_pelicula").val();
        var fecha_inicio_2d = new Date($("#fecha_inicio_2d").datepicker("getDate"));
        fecha_inicio_2d = (fecha_inicio_2d.getMonth() + 1) + "/" + fecha_inicio_2d.getDate() + "/" + fecha_inicio_2d.getFullYear();
        var fecha_fin_2d = new Date($("#fecha_fin_2d").datepicker("getDate"));
        fecha_fin_2d = (fecha_fin_2d.getMonth() + 1) + "/" + fecha_fin_2d.getDate() + "/" + fecha_fin_2d.getFullYear();
        var fecha_inicio_3d = new Date($("#fecha_inicio_3d").datepicker("getDate"));
        fecha_inicio_3d = (fecha_inicio_3d.getMonth() + 1) + "/" + fecha_inicio_3d.getDate() + "/" + fecha_inicio_3d.getFullYear();
        var fecha_fin_3d = new Date($("#fecha_fin_3d").datepicker("getDate"));
        fecha_fin_3d = (fecha_fin_3d.getMonth() + 1) + "/" + fecha_fin_3d.getDate() + "/" + fecha_fin_3d.getFullYear();
        var horarios_pelicula_2d = JSON.stringify($("#horarios_pelicula_2d").val());
        var horarios_pelicula_2d_subtitulada = JSON.stringify($("#horarios_pelicula_2d_subtitulada").val());
        var horario_preventa = JSON.stringify($("#horario_preventa").val());
        var horario_preventa_subtitulada = JSON.stringify($("#horario_preventa_subtitulada").val());
        var horarios_pelicula_3d = JSON.stringify($("#horarios_pelicula_3d").val());
        var horarios_pelicula_3d_subtitulada = JSON.stringify($("#horarios_pelicula_3d_subtitulada").val());
        var duracion_pelicula = $("#duracion_pelicula").val();
        var tipo_pelicula_3d = 0;
        var restriccion = 0;

        if ($('#restriccion').is(":checked")) {
          restriccion = 1;
        } else {
          restriccion = 0;
        }

        if ($('#tipo_pelicula_3d').is(":checked")) {
          tipo_pelicula_3d = 1;
        } else {
          tipo_pelicula_3d = 0;
        }
        var tipo_pelicula_2d = 0;
        if ($('#tipo_pelicula_2d').is(":checked")) {
          tipo_pelicula_2d = 1;
        } else {
          tipo_pelicula_2d = 0;
        }

        var proximo_estreno = 0;
        if ($('#proximo_estreno').is(":checked")) {
          proximo_estreno = 1;
        } else {
          proximo_estreno = 0;
        }

        var url_trailer = $("#url_trailer").val();

        var estreno = 0;
        if ($('#estreno').is(":checked")) {
          estreno = 1;
        } else {
          estreno = 0;
        }

        var preventa = 0;
        if ($('#preventa').is(":checked")) {
          preventa = 1;
        } else {
          preventa = 0;
        }

        var fecha_inicio_restriccion = new Date($("#fecha_inicio_restriccion").datepicker("getDate"));
        fecha_inicio_restriccion = (fecha_inicio_restriccion.getMonth() + 1) + "/" + fecha_inicio_restriccion.getDate() + "/" + fecha_inicio_restriccion.getFullYear();
        var fecha_fin_restriccion = new Date($("#fecha_fin_restriccion").datepicker("getDate"));
        fecha_fin_restriccion = (fecha_fin_restriccion.getMonth() + 1) + "/" + fecha_fin_restriccion.getDate() + "/" + fecha_fin_restriccion.getFullYear();
        var fecha_inicio_preventa = new Date($("#fecha_inicio_preventa").datepicker("getDate"));
        fecha_inicio_preventa = (fecha_inicio_preventa.getMonth() + 1) + "/" + fecha_inicio_preventa.getDate() + "/" + fecha_inicio_preventa.getFullYear();
        var fecha_fin_preventa = new Date($("#fecha_fin_preventa").datepicker("getDate"));
        fecha_fin_preventa = (fecha_fin_preventa.getMonth() + 1) + "/" + fecha_fin_preventa.getDate() + "/" + fecha_fin_preventa.getFullYear();

        if (
          nombre_pelicula !== "" && sinopsis_pelicula !== "" && url_trailer !== ""
        ) {
          $.post("../api/editPelicula.php", {
            id: id_pelicula,
            id_cine: id_cine,
            mes_estreno: mes_estreno,
            nombre_pelicula: nombre_pelicula,
            director_pelicula: director_pelicula,
            reparto_pelicula: reparto_pelicula,
            restriccion: restriccion,
            fecha_inicio_restriccion: fecha_inicio_restriccion,
            fecha_fin_restriccion: fecha_fin_restriccion,
            restriccion_idioma: restriccion_idioma,
            sinopsis_pelicula: sinopsis_pelicula,
            fecha_inicio_2d: fecha_inicio_2d,
            fecha_fin_2d: fecha_fin_2d,
            fecha_inicio_3d: fecha_inicio_3d,
            fecha_fin_3d: fecha_fin_3d,
            horarios_pelicula_2d: horarios_pelicula_2d,
            horarios_pelicula_2d_subtitulada: horarios_pelicula_2d_subtitulada,
            horario_preventa: horario_preventa,
            horario_preventa_subtitulada: horario_preventa_subtitulada,
            horarios_pelicula_3d: horarios_pelicula_3d,
            horarios_pelicula_3d_subtitulada: horarios_pelicula_3d_subtitulada,
            duracion_pelicula: duracion_pelicula,
            tipo_pelicula_3d: tipo_pelicula_3d,
            tipo_pelicula_2d: tipo_pelicula_2d,
            clasificacion: clasificacion,
            proximo_estreno: proximo_estreno,
            url_trailer: url_trailer,
            estreno: estreno,
            preventa: preventa,
            fecha_inicio_preventa: fecha_inicio_preventa,
            fecha_fin_preventa: fecha_fin_preventa
          }, function(result) {
            if (result == 1) {
              Swal.fire({
                type: 'success',
                title: 'Información',
                text: 'Pelicula modificada correctamente.',
              }).then((r) => {
                location.href = "./admin_peliculas.php"
              })
            } else {
              Swal.fire({
                type: 'error',
                title: 'Ha ocurrido un error!',
                text: `${result}`
              })
            }
          });
        } else {
          Swal.fire({
            type: 'warning',
            title: 'Oops...',
            text: 'Debes completar todos los campos.'
          })
        }
      }

      function changeRestriccion(element) {
        if (element.checked) {
          $('.fecha_restriccion').show();
        } else {
          $('.fecha_restriccion').hide();
        }
      }

      function change3d(element) {
        if (element.checked) {
          $('.view_3d').show();
        } else {
          $('.view_3d').hide();
        }
      }

      function change2d(element) {
        if (element.checked) {
          $('.view_2d').show();
        } else {
          $('.view_2d').hide();
        }
      }

      function changePreventa(element) {
        if (element.checked) {
          $('.active_preventa').show();
        } else {
          $('.active_preventa').hide();
        }
      }

      function changeProximoEstreno(element) {
        if (element.checked) {
          $('.proximo').hide();
          $('.preventa').show();
        } else {
          $('.proximo').show();
          $('.preventa').hide();
        }

        if ($("#tipo_pelicula_3d").is(':checked')) {
          $('.view_3d').show();
        } else {
          $('.view_3d').hide();
        }

        if ($("#tipo_pelicula_2d").is(':checked')) {
          $('.view_2d').show();
        } else {
          $('.view_2d').hide();
        }
      }

      $(document).ready(function() {
        $("#fecha_inicio_2d").datepicker({});
        $("#fecha_fin_2d").datepicker({});
        $("#fecha_inicio_3d").datepicker({});
        $("#fecha_fin_3d").datepicker({});
        $("#mes_estreno").datepicker({});
        $("#fecha_inicio_restriccion").datepicker({});
        $("#fecha_fin_restriccion").datepicker({});
        $("#fecha_inicio_preventa").datepicker({});
        $("#fecha_fin_preventa").datepicker({});

        var options = ""
        for (i = 9; i < 24; i++) {
          for (x = 0; x < 60; x++) {
            options = options + `<option value="${i}:${x < 10 ? `0${x}`: x }">${i}:${x < 10 ? `0${x}`: x }</option>`;
          }
        }


        $('.preventa').hide();

        $("#form-edit-pelicula").on('submit', function(evt) {
          evt.preventDefault();
        });
        $("#form-banner-peliculas").on('submit', function(e) {
          e.preventDefault();
          if (id_pelicula && url_actual_banner) {
            $.ajax({
              url: "../api/change_banner_pelicula.php",
              type: "POST",
              data: new FormData(this),
              contentType: false,
              cache: false,
              processData: false,
              success: function(result) {
                if (result == 1) {
                  Swal.fire({
                    type: 'success',
                    title: 'Información',
                    text: 'Imagen modificada correctamente.',
                  }).then((r) => {
                    location.reload();
                  })
                } else {
                  Swal.fire({
                    type: 'error',
                    title: 'Ha ocurrido un error!',
                    text: `${result}`
                  })
                }
              }
            });
          } else {
            Swal.fire({
              type: 'warning',
              title: 'Oops...',
              text: 'Debes completar todos los campos requeridos.'
            })
          }
        });
        $("#form-cover-peliculas").on('submit', function(e) {
          e.preventDefault();
          if (id_pelicula && url_actual_cover) {
            $.ajax({
              url: "../api/change_cover_pelicula.php",
              type: "POST",
              data: new FormData(this),
              contentType: false,
              cache: false,
              processData: false,
              success: function(result) {
                if (result == 1) {
                  Swal.fire({
                    type: 'success',
                    title: 'Información',
                    text: 'Imagen modificada correctamente.',
                  }).then((r) => {
                    location.reload();
                  })
                } else {
                  Swal.fire({
                    type: 'error',
                    title: 'Ha ocurrido un error!',
                    text: `${result}`
                  })
                }
              }
            });
          } else {
            PNotify.error({
              title: 'Error',
              text: 'Fálta información requerida.'
            });
          }
        });
        $.get("../api/getPeliculasById.php?id=" + id_pelicula, function(data) {
          $("#inicio_3d").append(`<input data-validate="required" name="fecha_inicio_3d" id="fecha_inicio_3d" data-role="datepicker">`);
          $("#fin_3d").append(`<input data-validate="required" name="fecha_fin_3d" id="fecha_fin_3d" data-role="datepicker">`);
          $("#horarios_2d").append(`
                    <select data-validate="required" name="horarios_pelicula_2d[]" id="horarios_pelicula_2d" data-role="select" multiple placeholder="Seleccions horarios">
                       ${options}
                    </select>
                `);
          $("#horarios_2d_subtitulada").append(`
                    <select data-validate="required" name="horarios_pelicula_2d_subtitulada[]" id="horarios_pelicula_2d_subtitulada" data-role="select" multiple placeholder="Seleccions horarios">
                       ${options}
                    </select>
                `);
          $("#content_horario_preventa").append(`
                    <select data-validate="required" name="horario_preventa[]" id="horario_preventa" data-role="select" multiple placeholder="Seleccione horarios">
                       ${options}
                    </select>
                `);
          $("#content_horario_preventa_subtitulada").append(`
                    <select data-validate="required" name="horario_preventa_subtitulada[]" id="horario_preventa_subtitulada" data-role="select" multiple placeholder="Seleccione horarios">
                       ${options}
                    </select>
                `);
          $("#horarios_3d").append(`
                    <select data-validate="required" name="horarios_pelicula_3d[]" id="horarios_pelicula_3d" data-role="select" multiple placeholder="Seleccions horarios">
                        ${options}
                    </select>
                `);
          $("#horarios_3d_subtitulada").append(`
                    <select data-validate="required" name="horarios_pelicula_3d_subtitulada[]" id="horarios_pelicula_3d_subtitulada" data-role="select" multiple placeholder="Seleccions horarios">
                        ${options}
                    </select>
                `);
          $('#restriccion_idioma').val(data[0]["restriccion_idioma"]);
          $('#restriccion').val(data[0]["restriccion"]);
          $('#nombre_pelicula').val(data[0]["nombre_pelicula"]);
          $('#director_pelicula').val(data[0]["director_pelicula"]);
          $('#reparto_pelicula').val(data[0]["reparto_pelicula"]);
          $('#sinopsis_pelicula').val(data[0]["sinopsis_pelicula"]);
          $('#fecha_inicio_2d').datepicker('setDate', data[0]["fecha_inicio_2d"]);
          $('#fecha_fin_2d').datepicker('setDate', data[0]["fecha_fin_2d"]);
          $('#fecha_inicio_3d').datepicker('setDate', data[0]["fecha_inicio_3d"]);
          $('#fecha_fin_3d').datepicker('setDate', data[0]["fecha_fin_3d"]);
          $('#clasificacion').val(data[0]["clasificacion"]);
          $('#duracion_pelicula').val(data[0]["duracion"]);
          $('#url_trailer').val(data[0]["trailer"]);

          if (data[0]["mes_estreno"] !== null && data[0]["mes_estreno"] !== "") {
            $('#mes_estreno').datepicker('setDate', data[0]["mes_estreno"]);
          }

          if (data[0]["fecha_inicio_restriccion"] !== null && data[0]["fecha_inicio_restriccion"] !== "") {
            $('#fecha_inicio_restriccion').datepicker('setDate', data[0]["fecha_inicio_restriccion"]);
          }

          if (data[0]["fecha_fin_restriccion"] !== null && data[0]["fecha_fin_restriccion"] !== "") {
            $('#fecha_fin_restriccion').datepicker('setDate', data[0]["fecha_fin_restriccion"]);
          }

          if (data[0]["fecha_inicio_preventa"] !== null && data[0]["fecha_inicio_preventa"] !== "") {
            $('#fecha_inicio_preventa').datepicker('setDate', data[0]["fecha_inicio_preventa"]);
          }

          if (data[0]["fecha_fin_preventa"] !== null && data[0]["fecha_fin_preventa"] !== "") {
            $('#fecha_fin_preventa').datepicker('setDate', data[0]["fecha_fin_preventa"]);
          }

          $('#preventa').val(data[0]["preventa"]);
          $('#horarios_pelicula_2d').val(JSON.parse(data[0]["horarios_pelicula_2d"]));
          $('#horarios_pelicula_2d_subtitulada').val(JSON.parse(data[0]["horarios_pelicula_2d_subtitulada"]));
          $('#horario_preventa').val(JSON.parse(data[0]["horario_preventa"]));
          $('#horario_preventa_subtitulada').val(JSON.parse(data[0]["horario_preventa_subtitulada"]));
          $('#horarios_pelicula_3d').val(JSON.parse(data[0]["horarios_pelicula_3d"]));
          $('#horarios_pelicula_3d_subtitulada').val(JSON.parse(data[0]["horarios_pelicula_3d_subtitulada"]));

          if (data[0]["proximo_estreno"] === "0" || data[0]["proximo_estreno"] === null) {
            $("#proximamente").append(`<input onchange="changeProximoEstreno(this)" id="proximo_estreno" type="checkbox" data-role="checkbox">`);
            $('.proximo').show();
            $('.preventa').hide();
          } else {
            $("#proximamente").append(`<input onchange="changeProximoEstreno(this)" id="proximo_estreno" type="checkbox" data-role="checkbox" checked>`);
            $('.proximo').hide();
            $('.preventa').show();
          }


          if (data[0]["3d"] === "0" || data[0]["3d"] === null) {
            $("#3d").append(`<input onchange="change3d(this)" id="tipo_pelicula_3d" type="checkbox" data-role="checkbox" data-caption="3D">`);
            $('.view_3d').hide();
          } else {
            $("#3d").append(`<input onchange="change3d(this)" id="tipo_pelicula_3d" type="checkbox" data-role="checkbox" data-caption="3D" checked>`);
            $('.view_3d').show();
          }
          if (data[0]["2d"] === "0" || data[0]["2d"] === null) {
            $("#2d").append(`<input onchange="change2d(this)" id="tipo_pelicula_2d" type="checkbox" data-role="checkbox" data-caption="2D">`);
            $('.view_2d').hide();
          } else {
            $("#2d").append(`<input onchange="change2d(this)" id="tipo_pelicula_2d" type="checkbox" data-role="checkbox" data-caption="2D" checked>`);
            $('.view_2d').show();
          }

          if (data[0]["estreno"] === "0" || data[0]["estreno"] === null) {
            $("#status_estreno").append(`<input name="estreno" id="estreno" type="checkbox" data-role="checkbox">`);
          } else {
            $("#status_estreno").append(`<input name="estreno" id="estreno" type="checkbox" data-role="checkbox" checked>`);
          }

          if (data[0]["restriccion"] === "0" || data[0]["restriccion"] === null) {
            $("#status_restriccion").append(`<input name="restriccion" onchange="changeRestriccion(this)" id="restriccion" type="checkbox" data-role="checkbox">`);
            $('.fecha_restriccion').hide();
          } else {
            $("#status_restriccion").append(`<input name="restriccion" onchange="changeRestriccion(this)" id="restriccion" type="checkbox" data-role="checkbox" checked>`);
            $('.fecha_restriccion').show();
          }

          if (data[0]["preventa"] === "0" || data[0]["preventa"] === null) {
            $("#status_preventa").append(`<input name="preventa" onchange="changePreventa(this)" id="preventa" type="checkbox" data-role="checkbox">`);
            $('.active_preventa').hide();
          } else {
            $("#status_preventa").append(`<input name="preventa" onchange="changePreventa(this)" id="preventa" type="checkbox" data-role="checkbox" checked>`);
            $('.active_preventa').show();
          }

          $("#img_cover").attr("src", `../${data[0]["cover"]}`);
          $("#img_banner").attr("src", `../${data[0]["banner"]}`);
          url_actual_cover = data[0]["cover"];
          url_actual_banner = data[0]["banner"];
          $("#url_imagen_cover_actual").val(data[0]["cover"]);
          $("#url_imagen_banner_actual").val(data[0]["banner"]);
          $("#id_cine").val(data[0]["fk_id_cine"]);
          id_cine = data[0]["fk_id_cine"];
          $("#id_pelicula_cover").val(id_pelicula);
          $("#id_pelicula_banner").val(id_pelicula);
        }, "json")

        $.get(
          "../api/getCines.php",
          function(data) {
            let options = "";
            for (i = 0; i < data.length; i++) {
              if (data[i]["id"] == id_cine) {
                options = options + `<option selected = "selected" value="${data[i]["id"]}">${data[i]["nombre"]}</option>`;
              } else {
                options = options + `<option value="${data[i]["id"]}">${data[i]["nombre"]}</option>`;
              }

            }

            let selectCines = `<select id="id_cine" data-role="select">
                        ${options}
                    </select>`;

            $("#listado_cines").append(selectCines);
          },
          "json"
        );
      });
    </script>
    <?php
    include("./footer.php");
    ?>
  </body>

  </html>
<?php
} else {
  // Redirect them to the login page
  header("Location: ./index.php");
}
?>