<?php
session_start();
if ( isset( $_SESSION['email'] ) ) {
?>
<html>
  <?php 
    include ("./head.php")
  ?>
  <body>
    <?php
      include ("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
        <div class="appbar bg-red z-1" data-role="appbar">
            <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
                <span class="mif-menu fg-white"></span>
            </button>
        </div>

        <div class="h-100 p-4">
            <p class="h1">Editar cumpleaños (otros servicios)</p>
            <br>
            <form data-role="validator" id="form-image-birthday" method="post" enctype="multipart/form-data">
                <div class="row flex-align-center">
                    <div class="cell-md-3">
                        <div class="img-container thumbnail"><img id="img_birthday" width="300px" height="200px" src="" alt=""></div>
                        <br class="escritorio">
                    </div>
                    <div class="cell-md-9">
                        <label for="nombre">Imagen descriptiva (1200 x 709)</label>
                        <input data-button-title="+" data-validate="required" id="uploadImage" type="file" accept="image/*" name="image" type="file" data-role="file" data-prepend="Seleccione imagen:">
                        <input style="display: none;" type="text" id="url_imagen_actual" name="url_imagen_actual"/>
                        <br>
                        <button class="button info js-dialog-close">Cambiar Imagen</button>
                    </div>
                </div>
            </form>
            <form data-role="validator" id="form-edit-birthday" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="cell-md-12">
                        <br>
                        <label for="nombre">Descripción</label>
                        <div id="descripcion" style="height: 300px;">
                        </div>
                    </div>
                </div>
                <br><br>
                <div class="centrar">
                    <button onclick="editarBirthday();" class="button warning js-dialog-close">Actualizar datos</button>
                </div>
            </form>
            <br><br><br>
        </div>
    </div>

    <script>
        var quill = new Quill('#descripcion', {
            theme: 'snow'
          });
        var url_actual = "";
        
        quill.setHTML = (html) => {
          quill.root.innerHTML = html;
        };
        
        function editarBirthday() {
            var descripcion = quill.root.innerHTML;
            if (
                descripcion !== ""
            ) {
                $.post("../api/editBirthday.php", { 
                        id: 1,
                        descripcion: descripcion
                    }, function(result) {
                        if (result == 1) {
                            Swal.fire({
                                type: 'success',
                                title: 'Información',
                                text: 'Datos actualizados correctamente.',
                            }).then((r) => {
                                location.href = "./admin_birthday.php"
                            })
                        } else {
                            Swal.fire({
                                type: 'error',
                                title: 'Ha ocurrido un error!',
                                text: `${result}`
                            })
                        }

                })
            } else {
                Swal.fire({
                    type: 'warning',
                    title: 'Oops...',
                    text: 'Debes completar todos los campos.'
                })
            }
        }

        $(document).ready(function() {
            $("#form-edit-birthday").on('submit', function(evt){
                evt.preventDefault();  
            });
            $("#form-image-birthday").on('submit', function(e){
                e.preventDefault();
                if (url_actual) {
                    $.ajax({
                        url: "../api/change_img_birthday.php",
                        type: "POST",
                        data:  new FormData(this),
                        contentType: false,
                        cache: false,
                        processData:false,
                        success: function(result)
                        {
                            if (result == 1) {
                                Swal.fire({
                                    type: 'success',
                                    title: 'Información',
                                    text: 'Datos actualizados correctamente.',
                                }).then((r) => {
                                    location.reload();
                                })
                            } else {
                                Swal.fire({
                                    type: 'error',
                                    title: 'Ha ocurrido un error!',
                                    text: `${result}`
                                })
                            }
                        }
                    });
                } else {
                    Swal.fire({
                        type: 'warning',
                        title: 'Oops...',
                        text: 'Debes completar todos los campos requeridos.'
                    })
                }
            });
            $.get("../api/getBirthday.php", function(data){
                quill.setHTML(data[0]["descripcion"]);
                $("#img_birthday").attr("src", `../${data[0]["url_imagen"]}`);
                url_actual = data[0]["url_imagen"];
                $("#url_imagen_actual").val(data[0]["url_imagen"]);
            }, "json")
        });
    </script>
    <?php
      include ("./footer.php");
    ?>
  </body>
</html>
<?php
} else {
    // Redirect them to the login page
    header("Location: ./index.php");
}
?>