<html>
<?php
include "./head.php"
?>

<body class="fondo-login">
  <div class="container-login">
    <div class="login">
      <div class="centrar">
        <img class="img-logo" src="https://cinepaseodelvalle.cl/logo_chico.png">
      </div>
      <br>
      <form id="form-login" action="../api/auth.php" method="post">
        <div class="form-group">
          <label>Correo electrónico</label><br>
          <input data-role="input" id="email" type="email" placeholder="Correo electrónico" />
        </div>
        <div class="form-group">
          <label>Contraseña</label><br>
          <input data-role="input" id="password" type="password" placeholder="Contraseña" />
        </div>
        <div class="form-group centrar">
          <button style="width: 120px; margin-top: 10px;" class="button success">Iniciar sesión</button>
          <button style="width: 120px; margin-top: 10px;" onclick="goHome(); return false;" class="button warning">Ir al Home</button>
        </div>
      </form>
    </div>
  </div>
  <?php
  include("./footer.php");
  ?>
</body>

</html>

<script>
  function goHome() {
    location.href = "../index.php";
  }

  $(document).ready(function() {
    $("#form-login").submit(function(e) {
      e.preventDefault();
      $.post("../api/auth.php", {
        email: $("#email").val(),
        password: $("#password").val()
      }, function(result) {
        if (parseInt(result) === 0) {
          Metro.notify.create("Usuario y/o Contraseña incorrecta.", "Información", {
            cls: "alert"
          });
        } else {
          localStorage.setItem("user", result);
          location.href = "./menu.php";
        }
      });
    });
  });
</script>