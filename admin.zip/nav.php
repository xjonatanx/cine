<div style="width: 100%; margin-bottom:: 10px;">
  <div class="nav">
    <!--logo-->
    <input type="checkbox" id="nav-check">
    <div class="nav-header">
      <div class="nav-title">
        <img class="logo" style="width: 120px; margin-top: 5px;" src="./img/logo_chico.png">
      </div>
    </div>
    <!--toggle button for mobile-->
    <div class="nav-btn">
      <label for="nav-check">
        <span></span>
        <span></span>
        <span></span>
      </label>
    </div>
    <div class="nav-links" style="font-size: 13px;">
      <ul>
        <!--menu Item-->
        <li><a href="./">PELICULAS</a></li>
        <li><a href="./cines.php">CINES</a></li>
        <li><a href="./promociones.php">PROMOCIONES</a></li>
        <li><a href="./confiteria.php">CONFITERÍA</a></li>
        <li><a href="./preventas.php">PREVENTAS</a></li>
        <li><a href="./otrosservicios.php">OTROS SERVICIOS</a></li>
        <!--Social Icon-->
        <a class="icon">
          <a style="color: black;" href="https://www.facebook.com/cinepaseodelvalle/"><i style="cursor: pointer; font-size: 20px;" class="fa fa-facebook-square"></i></a>
          <a style="color: black;" href="https://www.instagram.com/cinepaseodelvalle/"><i style="cursor: pointer; font-size: 20px;" class="fa fa-instagram"></i></a>
        </a>
      </ul>
    </div>
  </div>
</div>

<style>
  .nav {
    width: 100%;
    position: relative;
  }

  .nav>.nav-header {
    display: inline;
  }

  .nav>.nav-header>.nav-title {
    display: inline-block;
    padding: 10px 10px 10px 10px;
  }

  .nav>.nav-links {
    z-index: 10000 !important;
    font-size: 18px;
    display: inline;

  }

  .nav>.nav-links>ul li a {
    color: black;
    line-height: 40px;
    font-size: 18px;
    display: block;
    padding: 0 8px;
    text-decoration: none;

  }

  .nav>.nav-links>ul {
    list-style: none;
    position: relative;
    padding: 0;
    margin-top: 20px;
  }

  .nav>.nav-links>ul li {
    margin-left: 30px;
    display: inline-block;
  }

  .nav>.nav-links>ul li:hover {
    border-bottom: 5px solid #ff7300;
  }

  .nav .nav-links ul a.icon {
    margin-left: 35px;
    margin-right: 10px;
  }

  .nav .nav-links ul a i {
    padding: 7px;
    margin-left: 5px;
    background-color: #fff;
    border-radius: 50px;

  }

  .nav>.nav-btn {
    display: none;
    /*Hide toggle button for desktop*/
  }

  .nav>#nav-check {
    display: none;
  }
  
  @media (min-width: 1366px) {
        .nav {
            text-align: center !important;
        }
    }

  @media (max-width:750px) {
    .nav>.nav-links>ul li a {
      color: white;
    }

    .nav>.nav-header>.nav-title {
      display: inline-block;
      padding: 5px;
    }

    .logo {
      width: 130px !important;
      margin-bottom: 10px !important;
    }

    .nav>.nav-btn {
      display: inline-block;
      position: absolute;
      right: 0px;
      top: 0px;
    }

    .nav>.nav-btn>label {
      height: 50px;
      padding: 13px;
      display: inline-block;
      width: 50px;
    }

    .nav>.nav-btn>label>span {
      height: 10px;
      border-top: 2px solid black;
      display: block;
      width: 25px;

    }

    .nav>.nav-links {
      position: absolute;
      height: 0px;
      transition: all 0.3s ease-in;
      overflow-y: hidden;
      display: block;
      width: 100%;
      background-color: #333;
      left: 0px;
    }

    .nav>.nav-links>ul li a {
      display: block;
      width: 100%;
    }

    /*   */



    .nav>.nav-links>ul li {
      padding: 0;
      background-color: #333;
      display: block;
      margin-bottom: 20px;

    }

    /*   */
    .nav>#nav-check:not(:checked)~.nav-links {
      height: 0px;
    }

    .nav>#nav-check:checked~.nav-links {
      height: calc(100vh - 50px);
      overflow-y: auto;
    }
  }
</style>