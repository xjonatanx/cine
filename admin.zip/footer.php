
<div class="row">
  <div class="cell-sm-full cell-md-full cell-lg-full fondo-gray footer">
    <div class="row">
      <div class="cell-sm-full cell-md-full cell-lg-4 centrar">
        <img style="width: 150px;" src="https://cinepaseodelvalle.cl/logo_chico.png">
        <br><br><br>
      </div>
      <div class="cell-sm-full cell-md-full cell-lg-2">
        <h5 class="margen-h5">PROGRAMACIÓN</h5>
        <li class="lista_footer"><a class="link" href="./index#cartelera_section">Cartelera</a></li>
        <li class="lista_footer"><a class="link" href="./index#proximamente_section">Próximamente</a></li>
        <li class="lista_footer"><a class="link" href="./preventas.php">Venta Anticipada</a></li>
        <br>
      </div>
      <div class="cell-sm-full cell-md-full cell-lg-2">
        <h5 class="margen-h5">SOBRE NOSOTROS</h5>
        <li class="lista_footer"><a class="link" href="./nosotros.php">Nosotros</a></li>
        <li class="lista_footer"><a class="link" href="./cines.php">Salas</a></li>
        <li class="lista_footer"><a class="link" href="./terminoscondiciones.php">Términos y condiciones</a></li>
        <br>
      </div>
      <div class="cell-sm-full cell-md-full cell-lg-2">
        <h5 class="margen-h5">OTROS SERVICIOS</h5>
        <li class="lista_footer"><a class="link" href="./otrosservicios.php?section=1">Cumpleaños</a></li>
        <li class="lista_footer"><a class="link" href="./otrosservicios.php?section=2">Colegios</a></li>
        <li class="lista_footer"><a class="link" href="./otrosservicios.php?section=3">Entradas corporativas</a></li>
        <li class="lista_footer"><a class="link" href="./otrosservicios.php?section=4">Publicidad en cines</a></li>
        <br>
      </div>
      <div class="cell-sm-full cell-md-full cell-lg-2">
        <h5 class="margen-h5">CONTACTO</h5>
        <li class="lista_footer"><a class="link" href="./contacto.php">Escribenos</a></li>
      </div>
    </div>
  </div>
</div>