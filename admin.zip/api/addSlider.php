<?php
    $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
    $path = '../img/'; // upload directory

    $slider = $_FILES['imageSlider']['name'];
    $tmp_slider = $_FILES['imageSlider']['tmp_name'];
    $nombre_identificativo = $_POST['nombre_identificativo'];
    $enlace = $_POST['enlace'];
    $orden = $_POST['orden'];
    $tipo_imagen = $_POST['tipo_imagen'];
    $id_cine = $_POST['id_cine'];
    
    if($nombre_identificativo == "" || $orden == "" || $tipo_imagen == "" || $id_cine == "") {
        echo "No se han ingresado todos los campos requeridos, verifíquelos y vuelva a intentarlo.";
    } else {
        // get uploaded file's extension
        $ext_slider = strtolower(pathinfo($slider, PATHINFO_EXTENSION));
        // can upload same image using rand function
        $final_image_slider = date("dmYHis").rand(1000,1000000).$slider;
        // check's valid format
        
        if(in_array($ext_slider, $valid_extensions)) 
        { 
            $path_slider = $path.strtolower($final_image_slider);
    
            $final_path_slider = "img/".strtolower($final_image_slider); 
    
            $upload = false;
    
            if(move_uploaded_file($tmp_slider,$path_slider)) 
            {
                $upload = true;
            }
    
            if ($upload === true) {
                include("./conexion.php");
    
                $sql = "INSERT INTO slider (nombre, orden, fk_id_cine, url_slider, tipo, enlace, create_at)
                VALUES ('$nombre_identificativo', $orden, $id_cine, '$final_path_slider', '$tipo_imagen', '$enlace', NOW());";
    
                if ($conn->query($sql) === true) {
                    echo true;
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
    
                $conn->close();
            } else {
                echo "No se han cargado las imagenes en la plataforma, intentelo más tarde.";
            }
            
        } 
        else 
        {
            echo 'No se ha seleccionado ninguna imagen o el formato del archivo no está permitido.';
        }
    }
?>