<?php
$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
$path = '../img/'; // upload directory

$confiteria = $_FILES['imageConfiteria']['name'];
$tmp_confiteria = $_FILES['imageConfiteria']['tmp_name'];
$nombre_identificativo = $_POST['nombre_identificativo'];
$orden = $_POST['orden'];
$id_cine = $_POST['id_cine'];

// get uploaded file's extension
$ext_confiteria = strtolower(pathinfo($confiteria, PATHINFO_EXTENSION));
// can upload same image using rand function
$final_image_confiteria = date("dmYHis") . rand(1000, 1000000) . $confiteria;
// check's valid format

if (in_array($ext_confiteria, $valid_extensions)) {
  $path_confiteria = $path . strtolower($final_image_confiteria);

  $final_path_confiteria = "img/" . strtolower($final_image_confiteria);

  $upload = false;

  if (move_uploaded_file($tmp_confiteria, $path_confiteria)) {
    $upload = true;
  }

  if ($upload === true) {
    include("./conexion.php");

    $sql = "INSERT INTO confiteria (nombre_imagen, path_direccion, fk_id_cine, orden, create_at)
            VALUES ('$nombre_identificativo', '$final_path_confiteria', $id_cine, $orden, NOW());";

    if ($conn->query($sql) === true) {
      echo true;
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
  } else {
    echo "No se han cargado las imagenes en la plataforma, intentelo más tarde.";
  }
} else {
  echo 'No se ha seleccionado ninguna imagen o el formato del archivo no está permitido.';
}
