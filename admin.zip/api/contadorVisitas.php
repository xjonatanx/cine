
<?php
  $contador = 0;
  $id= 0;
  include("./conexion.php");

  $sql = "SELECT * FROM visitas;";
  $result = $conn->query($sql);
  $return_arr = array();

  if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
          $contador = $row['visitas'];
          $id = $row['id'];
      }
  }
  
  $total_visitas = $contador + 1;

  $sql = "UPDATE visitas SET 
        visitas = $total_visitas
        WHERE id = $id;";

    if ($conn->query($sql) === true) {
      echo "Visita actualizada";
    } else {
      echo $conn->error;
    }

    $conn->close();
?>