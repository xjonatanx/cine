<?php
include("./conexion.php");
$id = $_GET['id'];
$sql = "SELECT * FROM slider WHERE id = $id;";
$result = $conn->query($sql);
$return_arr = array();
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $row_array['id'] = $row['id'];
        $row_array['nombre'] = $row['nombre'];
        $row_array['orden'] = $row['orden'];
        $row_array['url_slider'] = $row['url_slider'];
        $row_array['tipo'] = $row['tipo'];
        $row_array['create_at'] = $row['create_at'];
        $row_array['fk_id_cine'] = $row['fk_id_cine'];
        $row_array['enlace'] = $row['enlace'];
        array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
} else {
    echo 0;
}
$conn->close();
?>