<?php
include "./conexion.php";

$id = $_POST['id'];
$fecha_inicio_restriccion = $_POST['fecha_inicio_restriccion'];
$fecha_fin_restriccion = $_POST['fecha_fin_restriccion'];
$fecha_inicio_preventa = $_POST['fecha_inicio_preventa'];
$fecha_fin_preventa = $_POST['fecha_fin_preventa'];
$fecha_inicio_2d = $_POST['fecha_inicio_2d'];
$fecha_fin_2d = $_POST['fecha_fin_2d'];
$fecha_inicio_3d = $_POST['fecha_inicio_3d'];
$fecha_fin_3d = $_POST['fecha_fin_3d'];
$horario_preventa = $_POST['horario_preventa'];
$horario_preventa_subtitulada = $_POST['horario_preventa_subtitulada'];
$horarios_pelicula_2d = $_POST['horarios_pelicula_2d'];
$horarios_pelicula_2d_subtitulada = $_POST['horarios_pelicula_2d_subtitulada'];
$horarios_pelicula_3d = $_POST['horarios_pelicula_3d'];
$horarios_pelicula_3d_subtitulada = $_POST['horarios_pelicula_3d_subtitulada'];
$estreno = $_POST['estreno'];
$restriccion = $_POST['restriccion'];
$preventa = $_POST['preventa'];
$mes_estreno = $_POST['mes_estreno'];

$nombre_pelicula = $_POST['nombre_pelicula'];
$director_pelicula = $_POST['director_pelicula'];
$reparto_pelicula = $_POST['reparto_pelicula'];
$sinopsis_pelicula = $_POST['sinopsis_pelicula'];
$tipo_pelicula_3d = $_POST['tipo_pelicula_3d'];
$tipo_pelicula_2d = $_POST['tipo_pelicula_2d'];
$duracion_pelicula = $_POST['duracion_pelicula'];
$clasificacion = $_POST['clasificacion'];
$proximo_estreno = $_POST['proximo_estreno'];
$url_trailer = $_POST['url_trailer'];
$id_cine = $_POST['id_cine'];

$sql = "UPDATE peliculas SET 
        restriccion = $restriccion,
        fecha_inicio_restriccion = '$fecha_inicio_restriccion',
        fecha_fin_restriccion = '$fecha_fin_restriccion',
        mes_estreno = '$mes_estreno',
        nombre_pelicula = '$nombre_pelicula', 
        fecha_inicio_2d = '$fecha_inicio_2d', 
        fecha_fin_2d = '$fecha_fin_2d', 
        fecha_inicio_3d = '$fecha_inicio_3d', 
        fecha_fin_3d = '$fecha_fin_3d', 
        horarios_pelicula_2d = '$horarios_pelicula_2d', 
        horarios_pelicula_2d_subtitulada = '$horarios_pelicula_2d_subtitulada', 
        horario_preventa = '$horario_preventa',
        horario_preventa_subtitulada = '$horario_preventa_subtitulada',
        horarios_pelicula_3d = '$horarios_pelicula_3d', 
        horarios_pelicula_3d_subtitulada = '$horarios_pelicula_3d_subtitulada', 
        fecha_inicio_preventa = '$fecha_inicio_preventa',
        fecha_fin_preventa = '$fecha_fin_preventa',
        estreno = $estreno, 
        preventa = $preventa, 
        director_pelicula = '$director_pelicula', 
        reparto_pelicula = '$reparto_pelicula', 
        sinopsis_pelicula = '$sinopsis_pelicula', 
        2d = $tipo_pelicula_2d, 
        3d = $tipo_pelicula_3d, 
        duracion = '$duracion_pelicula', 
        clasificacion = '$clasificacion',
        proximo_estreno = $proximo_estreno,
        trailer = '$url_trailer',
        fk_id_cine = $id_cine
        WHERE id = $id";

if ($conn->query($sql) === TRUE) {
  echo true;
} else {
  echo $conn->error;
}

$conn->close();
?>