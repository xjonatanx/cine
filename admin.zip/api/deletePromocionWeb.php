<?php
    include("./conexion.php");
    $url_actual = $_POST['url'];
    unlink('../../'.$url_actual);
    $id = $_POST['id'];
    $sql = "DELETE FROM promociones WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo true;
    } else {
        echo $conn->error;
    }

    $conn->close();
?>