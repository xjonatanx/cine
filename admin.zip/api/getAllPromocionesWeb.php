<?php
include("./conexion.php");

$id_cine = $_GET["id_cine"];

$sql = "";

if ($id_cine == "") {
    $sql = "SELECT promociones.id as 'id', promociones.nombre_imagen as 'nombre', promociones.orden as 'orden', cines.nombre as 'nombre_cine', promociones.fk_id_cine as 'fk_id_cine', promociones.path_direccion as 'path_direccion', promociones.create_at as 'create_at' FROM promociones INNER JOIN cines ON promociones.fk_id_cine = cines.id ORDER BY promociones.orden ASC;";
}

if ($id_cine != "") {
    $sql = "SELECT promociones.id as 'id', promociones.nombre_imagen as 'nombre', promociones.orden as 'orden', cines.nombre as 'nombre_cine', promociones.fk_id_cine as 'fk_id_cine', promociones.path_direccion as 'path_direccion', promociones.create_at as 'create_at' FROM promociones INNER JOIN cines ON promociones.fk_id_cine = cines.id WHERE promociones.fk_id_cine = $id_cine ORDER BY promociones.orden ASC;";
}

$result = $conn->query($sql);
$return_arr = array();
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $row_array['id'] = $row['id'];
        $row_array['nombre'] = $row['nombre'];
        $row_array['orden'] = $row['orden'];
        $row_array['nombre_cine'] = $row['nombre_cine'];
        $row_array['fk_id_cine'] = $row['fk_id_cine'];
        $row_array['path_direccion'] = $row['path_direccion'];
        $row_array['create_at'] = $row['create_at'];
        array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
} else {
    echo 0;
}
$conn->close();
?>