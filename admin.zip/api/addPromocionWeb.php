<?php
$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
$path = '../img/'; // upload directory

$promocion = $_FILES['imagePromocion']['name'];
$tmp_promocion = $_FILES['imagePromocion']['tmp_name'];
$nombre_identificativo = $_POST['nombre_identificativo'];
$orden = $_POST['orden'];
$id_cine = $_POST['id_cine'];

// get uploaded file's extension
$ext_promocion = strtolower(pathinfo($promocion, PATHINFO_EXTENSION));
// can upload same image using rand function
$final_image_promocion = date("dmYHis") . rand(1000, 1000000) . $promocion;
// check's valid format

if (in_array($ext_promocion, $valid_extensions)) {
  $path_promocion = $path . strtolower($final_image_promocion);

  $final_path_promocion = "img/" . strtolower($final_image_promocion);

  $upload = false;

  if (move_uploaded_file($tmp_promocion, $path_promocion)) {
    $upload = true;
  }

  if ($upload === true) {
    include("./conexion.php");

    $sql = "INSERT INTO promociones (nombre_imagen, path_direccion, fk_id_cine, orden, create_at)
            VALUES ('$nombre_identificativo', '$final_path_promocion', $id_cine, $orden, NOW());";

    if ($conn->query($sql) === true) {
      echo true;
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
  } else {
    echo "No se han cargado las imagenes en la plataforma, intentelo más tarde.";
  }
} else {
  echo 'No se ha seleccionado ninguna imagen o el formato del archivo no está permitido.';
}
