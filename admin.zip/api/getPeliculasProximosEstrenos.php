<?php
include("./conexion.php");

$id_cine = $_GET["id_cine"];

$sql = "";

if ($id_cine == "") {
    $sql = "SELECT * FROM peliculas WHERE proximo_estreno = 1 ORDER BY STR_TO_DATE(mes_estreno, '%m/%d/%Y') ASC;;";
}

if ($id_cine != "") {
    $sql = "SELECT * FROM peliculas WHERE proximo_estreno = 1 AND fk_id_cine = $id_cine ORDER BY STR_TO_DATE(mes_estreno, '%m/%d/%Y') ASC;";
}

$result = $conn->query($sql);
$return_arr = array();
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $row_array['id'] = $row['id'];
        $row_array['nombre_pelicula'] = $row['nombre_pelicula'];
        $row_array['director_pelicula'] = $row['director_pelicula'];
        $row_array['reparto_pelicula'] = $row['reparto_pelicula'];
        $row_array['restriccion_idioma'] = $row['restriccion_idioma'];
        $row_array['restriccion'] = $row['restriccion'];
        $row_array['sinopsis_pelicula'] = $row['sinopsis_pelicula'];
        $row_array['fecha_inicio_2d'] = $row['fecha_inicio_2d'];
        $row_array['fecha_fin_2d'] = $row['fecha_fin_2d'];
        $row_array['fecha_inicio_3d'] = $row['fecha_inicio_3d'];
        $row_array['fecha_fin_3d'] = $row['fecha_fin_3d'];
        $row_array['horarios_pelicula_3d'] = $row['horarios_pelicula_3d'];
        $row_array['horarios_pelicula_2d'] = $row['horarios_pelicula_2d'];
        $row_array['2d'] = $row['2d'];
        $row_array['3d'] = $row['3d'];
        $row_array['duracion'] = $row['duracion'];
        $row_array['clasificacion'] = $row['clasificacion'];
        $row_array['estreno'] = $row['estreno'];
        $row_array['preventa'] = $row['preventa'];
        $row_array['proximo_estreno'] = $row['proximo_estreno'];
        $row_array['cover'] = $row['cover'];
        $row_array['banner'] = $row['banner'];
        $row_array['trailer'] = $row['trailer'];
        $row_array['cine'] = $row['cine'];
        $row_array['mes_estreno'] = $row['mes_estreno'];
        $row_array['fecha_inicio_restriccion'] = $row['fecha_inicio_restriccion'];
        $row_array['fecha_fin_restriccion'] = $row['fecha_fin_restriccion'];
        $row_array['fecha_inicio_preventa'] = $row['fecha_inicio_preventa'];
        $row_array['fecha_fin_preventa'] = $row['fecha_fin_preventa'];
        $row_array['horario_preventa'] = $row['horario_preventa'];
        $row_array['horario_preventa_subtitulada'] = $row['horario_preventa_subtitulada'];
        array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
} else {
    echo 0;
}
$conn->close();
?>