<?php
include "./conexion.php";
$id = $_POST['id'];
$nombre_referencial = $_POST['nombre_referencial'];
$id_cine = $_POST['id_cine'];
$orden = $_POST['orden'];
$tipo_imagen = $_POST['tipo_imagen'];
$enlace = $_POST['enlace'];

$sql = "UPDATE slider SET 
        enlace = '$enlace',
        orden = $orden,
        nombre = '$nombre_referencial', 
        fk_id_cine = $id_cine,
        tipo = '$tipo_imagen'
        WHERE id = $id";

if ($conn->query($sql) === TRUE) {
  echo true;
} else {
  echo $conn->error;
}

$conn->close();
?>