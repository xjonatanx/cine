<?php
$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
$path = '../img/'; // upload directory

$cover = $_FILES['imageCover']['name'];
$tmp_cover = $_FILES['imageCover']['tmp_name'];

$banner = $_FILES['imageBanner']['name'];
$tmp_banner = $_FILES['imageBanner']['tmp_name'];

// get uploaded file's extension
$ext_cover = strtolower(pathinfo($cover, PATHINFO_EXTENSION));
$ext_banner = strtolower(pathinfo($banner, PATHINFO_EXTENSION));
// can upload same image using rand function
$final_image_cover = date("dmYHis") . rand(1000, 1000000) . $cover;
$final_image_banner = date("dmYHis") . rand(1000, 1000000) . $banner;
// check's valid format

if (in_array($ext_cover, $valid_extensions) && in_array($ext_banner, $valid_extensions)) {
  $path_cover = $path . strtolower($final_image_cover);
  $path_banner = $path . strtolower($final_image_banner);

  $final_path_cover = "img/" . strtolower($final_image_cover);
  $final_path_banner = "img/" . strtolower($final_image_banner);

  $upload_1 = false;
  $upload_2 = false;

  if (move_uploaded_file($tmp_cover, $path_cover)) {
    $upload_1 = true;
  } else {
    $upload_1 = false;
  }

  if (move_uploaded_file($tmp_banner, $path_banner)) {
    $upload_2 = true;
  } else {
    $upload_2 = false;
  }

  if ($upload_1 === true && $upload_2 === true) {
    include("./conexion.php");

    $nombre_pelicula = $_POST['nombre_pelicula'];
    $director_pelicula = $_POST['director_pelicula'];
    $reparto_pelicula = $_POST['reparto_pelicula'];
    $sinopsis_pelicula = $_POST['sinopsis_pelicula'];
    $fecha_inicio_2d = $_POST['fecha_inicio_2d'];
    $fecha_fin_2d = $_POST['fecha_fin_2d'];
    $fecha_inicio_3d = $_POST['fecha_inicio_3d'];
    $fecha_fin_3d = $_POST['fecha_fin_3d'];
    $horario_preventa = '["' . implode('","', $_POST["horario_preventa"]) . '"]';
    $horario_preventa_subtitulada = '["' . implode('","', $_POST["horario_preventa_subtitulada"]) . '"]';
    $horarios_pelicula_2d = '["' . implode('","', $_POST["horarios_pelicula_2d"]) . '"]';
    $horarios_pelicula_2d_subtitulada = '["' . implode('","', $_POST["horarios_pelicula_2d_subtitulada"]) . '"]';
    $horarios_pelicula_3d = '["' . implode('","', $_POST["horarios_pelicula_3d"]) . '"]';
    $horarios_pelicula_3d_subtitulada = '["' . implode('","', $_POST["horarios_pelicula_3d_subtitulada"]) . '"]';
    $tipo_pelicula_3d = null;
    $tipo_pelicula_2d = null;
    $estreno = null;
    $preventa = null;
    $fecha_inicio_preventa = $_POST['fecha_inicio_preventa'];
    $fecha_fin_preventa = $_POST['fecha_fin_preventa'];
    $restriccion = null;
    $duracion_pelicula = $_POST['duracion_pelicula'];
    $clasificacion = $_POST['clasificacion'];
    $url_trailer = $_POST['url_trailer'];
    $proximo_estreno = null;
    $fk_id_cine = $_POST['id_cine'];
    $mes_estreno = $_POST['mes_estreno'];
    $fecha_inicio_restriccion = $_POST['fecha_inicio_restriccion'];
    $fecha_fin_restriccion = $_POST['fecha_fin_restriccion'];

    if (isset($_POST['preventa'])) {
      $preventa = 1;
    } else {
      $preventa = 0;
    }

    if (isset($_POST['estreno'])) {
      $estreno = 1;
    } else {
      $estreno = 0;
    }

    if (isset($_POST['restriccion'])) {
      $restriccion = 1;
    } else {
      $restriccion = 0;
    }

    if (isset($_POST['tipo_pelicula_3d'])) {
      $tipo_pelicula_3d = 1;
    } else {
      $tipo_pelicula_3d = 0;
    }

    if (isset($_POST['tipo_pelicula_2d'])) {
      $tipo_pelicula_2d = 1;
    } else {
      $tipo_pelicula_2d = 0;
    }

    if (isset($_POST['proximo_estreno'])) {
      $proximo_estreno = 1;
    } else {
      $proximo_estreno = 0;
    }

    $sinopsis_pelicula = str_replace(array('\'', '"'), '', $sinopsis_pelicula);

    $sql = "";

    if ($proximo_estreno === 1) {
      $sql = "INSERT INTO peliculas (nombre_pelicula, director_pelicula, reparto_pelicula, sinopsis_pelicula, trailer, duracion, fk_id_cine, clasificacion, preventa, fecha_inicio_preventa, fecha_fin_preventa, horario_preventa, horario_preventa_subtitulada, restriccion, proximo_estreno, cover, banner, fecha_inicio_2d, fecha_fin_2d, fecha_inicio_3d, fecha_fin_3d, horarios_pelicula_2d, horarios_pelicula_2d_subtitulada, horarios_pelicula_3d, horarios_pelicula_3d_subtitulada, 2d, 3d, estreno, mes_estreno, fecha_inicio_restriccion, fecha_fin_restriccion)
            VALUES ('$nombre_pelicula', '$director_pelicula', '$reparto_pelicula', '$sinopsis_pelicula', '$url_trailer', '$duracion_pelicula', $fk_id_cine, '$clasificacion', $preventa, '$fecha_inicio_preventa', '$fecha_fin_preventa', '$horario_preventa', '$horario_preventa_subtitulada', $restriccion, $proximo_estreno, '$final_path_cover', '$final_path_banner', null, null, null, null, null, null, null, null, null, null, null, '$mes_estreno', '$fecha_inicio_restriccion', '$fecha_fin_restriccion');";
    } else {
      $sql = "INSERT INTO peliculas (nombre_pelicula, director_pelicula, reparto_pelicula, sinopsis_pelicula, trailer, duracion, fk_id_cine, clasificacion, preventa, restriccion, proximo_estreno, cover, banner, fecha_inicio_2d, fecha_fin_2d, fecha_inicio_3d, fecha_fin_3d, horarios_pelicula_2d, horarios_pelicula_2d_subtitulada, horarios_pelicula_3d, horarios_pelicula_3d_subtitulada, 2d, 3d, estreno, fecha_inicio_restriccion, fecha_fin_restriccion)
            VALUES ('$nombre_pelicula', '$director_pelicula', '$reparto_pelicula', '$sinopsis_pelicula', '$url_trailer', '$duracion_pelicula', $fk_id_cine, '$clasificacion', null, $restriccion, $proximo_estreno, '$final_path_cover', '$final_path_banner', '$fecha_inicio_2d', '$fecha_fin_2d', '$fecha_inicio_3d', '$fecha_fin_3d', '$horarios_pelicula_2d', '$horarios_pelicula_2d_subtitulada', '$horarios_pelicula_3d', '$horarios_pelicula_3d_subtitulada', $tipo_pelicula_2d, $tipo_pelicula_3d, $estreno, '$fecha_inicio_restriccion', '$fecha_fin_restriccion');";
    }


    if ($conn->query($sql) === true) {
      echo true;
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
  } else {
    echo "No se han cargado las imagenes en la plataforma, intentelo más tarde.";
  }
} else {
  echo 'No se ha seleccionado ninguna imagen o el formato del archivo no está permitido.';
}
?>


<?php

?>