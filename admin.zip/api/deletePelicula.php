<?php
    include("./conexion.php");
    $url_cover = $_POST['cover'];
    $url_banner = $_POST['banner'];
    unlink('../../'.$url_cover);
    unlink('../../'.$url_banner);
    $id = $_POST['id'];
    $sql = "DELETE FROM peliculas WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo true;
    } else {
        echo $conn->error;
    }

    $conn->close();
?>