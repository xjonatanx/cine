<?php
include "./conexion.php";
$id = $_POST['id'];

$sql = "UPDATE usuarios SET 
        bloqueado = 1
        WHERE id = $id";

if ($conn->query($sql) === TRUE) {
  echo true;
} else {
  echo $conn->error;
}

$conn->close();
?>