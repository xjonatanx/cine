<?php
include "./conexion.php";
$descripcion = $_POST['descripcion'];

$descripcion = str_replace(array("\r\n", "\n\r", "\r", "\n"), "<br />", $descripcion);

$sql = "UPDATE colegios SET 
        descripcion = '$descripcion'
        WHERE id = 1";

if ($conn->query($sql) === TRUE) {
  echo true;
} else {
  echo $conn->error;
}

$conn->close();
?>