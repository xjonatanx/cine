<!DOCTYPE html>
<html>
  <?php
    $title = "Términos y Condiciones";
    include "./head.php"
  ?>
<body>
  <!-- TOP NAV -->
  <?php 
    include "./nav.php"; 
  ?>
  <br>
  <div class="row">
    <div class="cell-sm-full cell-md-full cell-lg-full titulos">
      <b><span>TÉRMINOS Y CONDICIONES</span></b>
    </div>
    <div class="cell-sm-full cell-md-full cell-lg-full">
        <center><img width="350px" src="http://www.cip.org.pe/wp-content/uploads/2017/12/EnConstruccion.png"/></center>
    </div>
  </div>
  <br><br><br>
  <?php
    include "./footer.php"
  ?>
</body>
<style>
    .jconfirm-box-container {
        margin: 0 auto !important;
    }
</style>
</html>
