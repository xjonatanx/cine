<div class="row slider_movil">
  <div class="cell-sm-full cell-md-full cell-lg-full" style="width: 100%;">
    <div id="slides-escritorio"></div>
  </div>
</div>
<div class="row slider_escritorio" style="width: 100%;">
  <div class="cell-sm-full cell-md-full cell-lg-full">
    <div id="slides-movil"></div>
  </div>
</div>

<script>
  var cine = "";

  function getAllSlider(id) {

    $.get("./api/getAllSlider.php?id_cine=" + id, function(data) {
      let slide_escritorio = "";
      let slide_movil = "";
      if (data.length > 0) {
        data.forEach(slide => {
          if (slide.tipo === "escritorio") {
            slide_escritorio = slide_escritorio + `<div data-period="8000" class="slide"><img onclick="redireccion('${slide.enlace}')" style="cursor: pointer;" width="100%" src="${slide.url_slider}"/></div>`;
          } else {
            slide_movil = slide_movil + `<div data-period="8000" class="slide"><img onclick="redireccion('${slide.enlace}')" style="cursor: pointer;" width="100%" src="${slide.url_slider}"/></div>`;
          }
        });
        $("#slides-escritorio").append(
          `<div
            data-role="carousel" 
            data-bullets="false" 
            data-auto-start="true"
            data-height="@(max-width: 1920px),370| (max-width: 1366px),300| (max-width: 1024px),220 | (max-width: 768px),146 | (max-width: 576px),100" 
            data-control-next="<span class='mif-chevron-right'></span>" 
            data-control-prev="<span class='mif-chevron-left'></span>">
            ${slide_escritorio}
          </div>`);
        $("#slides-movil").append(
          `<div
            data-role="carousel" 
            data-bullets="false" 
            data-auto-start="true"
            data-height="@(max-width: 1920px),400| (max-width: 1366px),300 | (max-width: 1024px),220 | (max-width: 600px),590 | (max-width: 414px),407 | (max-width: 411px),403 | (max-width: 384px),378 | (max-width: 375px),370 | (max-width: 360px),354 | (max-width: 320px),315" 
            data-control-next="<span class='mif-chevron-right'></span>" 
            data-control-prev="<span class='mif-chevron-left'></span>">
            ${slide_movil}
          </div>`);
      }
    }, "json");
  }

  function redireccion(params) {
    let url = "";
    if (params === "null" || params === "") {
      url = "#";
    } else {
      url = params
    }
    $(location).attr('href', url);
  }

  $(document).ready(function() {
    if (localStorage.getItem("id_cine")) {
      id_cine = localStorage.getItem("id_cine");
    }
    getAllSlider(id_cine)
  });
</script>