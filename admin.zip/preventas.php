<!DOCTYPE html>
<html>
<?php
$title = "Preventas";
include "./head.php"
?>
<body style="background-color: #e1e1e1;">
  <div class="container" style="background-color: white; padding-left: 0px; padding-right: 0px;">
      <!-- TOP NAV -->
      <?php 
        $active = "preventas";
        include "./nav.php"; 
      ?>
      <div id="item-proximo-estreno"></div>
      <br>
  </div>
  <?php
    include "./footer.php"
  ?>
  <script>
    var id_cine = "";
    
    function dialogRestriccion(nombre_pelicula, restriccion_inicio, restriccion_fin) {
        Metro.dialog.create({
            title: "RESTRICCIÓN",
            width: 700,
            clsDialog: 'alert',
            content: `
            <div>
                <span>
                    SE INFORMA QUE LA PELICULA ${nombre_pelicula.toUpperCase()} TIENE RESTRICCIÓN ENTRE LOS DÍAS ${restriccion_inicio} Y ${restriccion_fin}, LO QUE CONTEMPLA SU PREVENTA, Y EL USO DE:
                </span>
                <br>
                <ul>
                    <li>TODO TIPO DE PROMOCIONES</li>
                    <li>CONVENIO</li>
                </ul>
            </div>`,
            closeButton: true
        });
    }
    
    function getProximosEstrenos(id) {
      $.get("./api/getPeliculasProximosEstrenos.php?id_cine=" + id, function(data){
            var lista_preventas = data.filter(function (el) {
              return el.preventa === "1";
            });
            if(lista_preventas.length === 0) {
                $("#item-proximo-estreno").html(`
                    <div class="row" style="width: 100%;">
                        <div class="cell-sm-full cell-md-full cell-lg-full titulos">
                          <b><span>PREVENTAS</span></b>
                        </div>
                        <div class="cell-sm-full cell-md-full cell-lg-full" style="margin-left: 35px; height: 46vh;">
                            <br>
                            No hay preventas disponibles en este momento.
                            <br><br><br>
                        </div>
                    </div>`
                );
            } else {
                let item = "";
              lista_preventas.forEach(function(pelicula, i){
                  let data_horario_preventa = "";
                  let data_horario_preventa_subtitulada = "";
                  if(pelicula.preventa === "1") {
                        let horario_preventa = JSON.parse(pelicula.horario_preventa);
                        let horario_preventa_subtitulada = JSON.parse(pelicula.horario_preventa_subtitulada);
                        data_horario_preventa = "";
                        data_horario_preventa_subtitulada = "";
                        for (var i = 0; i < horario_preventa.length; i++) { 
                          data_horario_preventa = data_horario_preventa + `<button style="background-color: #636363; margin-right: 10px; margin-bottom: 10px; border-radius: 4px;" class="button secondary inline button_comprar">${horario_preventa[i]}</button>`;
                        }
                        for (var i = 0; i < horario_preventa_subtitulada.length; i++) { 
                          data_horario_preventa_subtitulada = data_horario_preventa_subtitulada + `<button style="background-color: #636363; margin-right: 10px; margin-bottom: 10px; border-radius: 4px;" class="button secondary inline button_comprar">${horario_preventa_subtitulada[i]}</button>`;
                        }
                    
                  let clasificacion = "";
                  if (pelicula.clasificacion === 'TE') {
                    clasificacion = "TODO ESPECTADOR";
                  }
                  if (pelicula.clasificacion === 'TE+7') {
                    clasificacion = "TODO ESPECTADOR, INCONVENIENTE PARA MENORES DE 7 AÑOS";
                  }
                  if (pelicula.clasificacion === '+14') {
                    clasificacion = "MAYORES DE 14 AÑOS";
                  }
                  if (pelicula.preventa === "1") {
                    item = item + `
                  <div class="dialog dialog-custom" data-role="dialog" data-overlay-alpha="0.7" id="demoDialog${i}" data-width="900" data-close-button="true">
                    <div class="dialog-title"><span class="titulo-dialogo"><span class="mif-video-camera"></span> <span id="titulo_trailer"> TRAILER</span></span></div>
                    <div class="dialog-content content-dialog">
                        <iframe class="trailer" src="${pelicula.trailer}" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <div class="dialog-actions" style="display: none">
                      <button class="button warning rounded js-dialog-close derecha">Cerrar</button>
                    </div>
                  </div>
                  <div class="escritorio full-width cell-sm-full cell-md-full cell-lg-full ${(i%2) ? "fondo-gray" : "fondo-orange"} content-preventa">
                    <div class="card">
                        <div class="card-header">
                            <center><b>${pelicula.mes_estreno ? moment(new Date(pelicula.mes_estreno)).format('LL').toUpperCase() : "SIN DEFINIR"}</b></center>
                        </div>
                        <div class="card-content p-2">
                            <div class="row flex-align-center">
                                <div class="cell-3">
                                  <div><img class="img-estreno" src="${pelicula.cover}" hspace="16" vspace="16" /></div>
                                </div>
                                <div class="cell-9">
                                  <div>
                                    <div style="margin-bottom: 10px;"><b>${pelicula.nombre_pelicula}</b></div>
                                    ${pelicula.clasificacion ? `<button data-role="hint" data-hint-position="bottom" data-hint-text="${clasificacion}" class="mini button warining outline rounded">${pelicula.clasificacion}</button>` : ""} 
                                    ${pelicula.duracion !== "" ? `<button class="mini button dark outline rounded">${pelicula.duracion} MIN</button>`: ""} 
                                    ${pelicula.restriccion === "1" ? `<button class="mini button alert rounded" onclick="dialogRestriccion('${pelicula.nombre_pelicula}', '${pelicula.fecha_inicio_restriccion}', '${pelicula.fecha_fin_restriccion}')">RESTRICCIÓN</button>` : ""} <br>
                                    <button style="margin-top: 10px;" onclick="Metro.dialog.open('#demoDialog${i}')" class="mini button alert outline rounded"><span class="mif-youtube-play"></span> VER TRAILER</button>
                                  </div>
                                </div>
                                <div class="cell-12">
                                    <br>
                                <div data-role="accordion" data-one-frame="false" data-show-active="true">
                                    <div class="frame">
                                      <div style="padding: 0px !important; color: #434343 !important; border: 1px solid #ddd;" class="heading button primary">MÁS INFORMACIÓN</div>
                                        <div class="content">
                                        <br>
                                        <span style="color: #b5121c;">SINOPSIS</span>
                                          <div style="border-top: 1px solid #8a8a8a; margin-top: 5px; margin-bottom: 10px;"></div>
                                          ${pelicula.sinopsis_pelicula}
                                          <br>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="cell-12">
                                    <br>
                                    <span style="font-size: 14px;"><b>DESDE EL ${moment(pelicula.fecha_inicio_preventa).format('LL').toUpperCase()} AL ${moment(pelicula.fecha_fin_preventa).format('LL').toUpperCase()}</b></span>
                                    <br><br>
                                    ${horario_preventa.length > 0 ? `<div style="margin-bottom: 10px;"><span style="font-size: 14px;">DOBLADA AL ESPAÑOL</span></div>
                        ${data_horario_preventa}` : ``}
                                    
                                    
                                    ${horario_preventa_subtitulada.length > 0 ? `<br><div style="margin-bottom: 10px;"><span style="font-size: 14px;">SUBTITULADA</span></div>
                        ${data_horario_preventa_subtitulada}` : ``}
                                  </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button style="width: 100%; margin: 0 auto;" class="medium button alert rounded">PREVENTA</button>
                        </div>
                    </div>
                  </div>
                  <div class="movil cell-sm-full cell-md-full cell-lg-full ${(i%2) ? "fondo-gray" : "fondo-orange"} content-preventa">
                    <div class="row flex-align-center">
                      <div class="cell-3 centrar without-padding">
                        <div>
                          <div style="display: inline-block; position:relative">
                              <img class="img-estreno" src="${pelicula.cover}" hspace="16" vspace="16" />
                              <div style="display: inline-block; position:absolute; top:50%; left:50%; transform: translate(-50%, -50%)">
                                  <img class="icon_play_preventa" onclick="Metro.dialog.open('#demoDialog${i}')" border="0" src="./img/play-button.png"/>
                              </div>
                          </div>
                        </div>
                      </div>
                      <div class="cell-9 describe-estreno">
                        <div class="row">
                            <div class="cell-7"><div><span class="title-describe-estreno">${pelicula.nombre_pelicula}</span></div></div>
                            <div class="cell-5"><div><button class="button dark rounded derecha">${pelicula.mes_estreno ? moment(new Date(pelicula.mes_estreno)).format('LL').toUpperCase() : "SIN DEFINIR"}</button>${pelicula.restriccion === "1" ? `<button style="margin-left: 7px; margin-right: 5px;" class="button alert rounded derecha" onclick="dialogRestriccion('${pelicula.nombre_pelicula}', '${pelicula.fecha_inicio_restriccion}', '${pelicula.fecha_fin_restriccion}')">RESTRICCIÓN</button>` : ""}</div></div>
                        </div>
                        <br>
                        <p class="descripcion-pelicula-estreno">
                          ${pelicula.sinopsis_pelicula}
                        </p>
                        <br>
                        
                        <span style="font-size: 14px;"><b>PREVENTA ABIERTA DESDE EL ${moment(pelicula.fecha_inicio_preventa).format('LL').toUpperCase()} AL ${moment(pelicula.fecha_fin_preventa).format('LL').toUpperCase()}</b></span>
                        <br><br>
                        ${horario_preventa.length > 0 ? `<div style="margin-bottom: 10px;"><b><span style="font-size: 14px;">DOBLADA AL ESPAÑOL</span></b></div>
                        ${data_horario_preventa}` : ``}
                        
                        ${horario_preventa_subtitulada.length > 0 ? `<br><div style="margin-bottom: 10px;"><b><span style="font-size: 14px;">SUBTITULADA</span></b></div>
                        ${data_horario_preventa_subtitulada}` : ``}
                        <br><br><br>
                        <div class="centrar">
                          ${pelicula.clasificacion ? `<button data-role="hint" data-hint-position="bottom" data-hint-text="${clasificacion}" style="margin-left: 7px; margin-right: 5px;" class="button dark outline rounded">${pelicula.clasificacion}</button>` : ""} 
                          ${pelicula.duracion !== "" ? `<button style="margin-left: 7px; margin-right: 5px;" class="button dark outline rounded">${pelicula.duracion} MIN</button>`: ""}  
                          <button style="margin-left: 7px; margin-right: 5px;" class="button alert outline rounded">PREVENTA</button>
                        </div>
                        </div>
                      </div>
                    </div>`;
                  }
                  }
              });
              $("#item-proximo-estreno").html(`<div class="row" style="width: 100%;">
                <div class="cell-sm-full cell-md-full cell-lg-full titulos">
                  <b><span>PREVENTAS</span></b>
                </div>${item}</div>`);
            }
            
        },"json");
    }

    $(document).ready(function() {
      moment.locale('es');
      if(localStorage.getItem("id_cine")) {
        id_cine = localStorage.getItem("id_cine");
      }
      getProximosEstrenos(id_cine);
    });

  </script>
  <script src="https://cdn.metroui.org.ua/v4/js/metro.min.js"></script>
</body>
<style>
    .jconfirm-box-container {
        margin: 0 auto !important;
    }
</style>
</html>