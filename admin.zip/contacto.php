<!DOCTYPE html>
<html>
<?php
include "./head.php"
?>
<body>
  <!-- TOP NAV -->
  <?php 
    $active = "promociones";
    include "./nav.php"; 
  ?>
  <br>
  <div class="row">
    <div class="cell-sm-full cell-md-full cell-lg-full">
      <div class="titulos">
        <b><span>CONTÁCTANOS</span></b>
      </div>
      <div class="description-contactanos">
        <h4 class="subtitle-contacto">Queremos conocer tu opinión</h4>
        <p>
          Para asegurar la calidad y optimización de nuestro servicio te pedimos por favor llenar todos los campos que vienen a continuación. <br>
          ¡Gracias por compartir tus sugerencias con nosotros!
        </p>
        <br>
      </div>
    </div>
    <div class="cell-sm-full cell-md-full cell-lg-full form-contacto">
      <form action="./api/sendMessage.php" method="post">
          <div class="row">
              <div class="cell-md-4">
                  <label for="motivo">Motivo</label>
                  <select data-validate="required" data-role="select" id="motivo" name="motivo">
                      <option>Consulta</option>
                      <option>Felicitaciones</option>
                      <option>Solicitud</option>
                      <option>Sugerencia</option>
                      <option>Queja</option>
                  </select>
                  <br>
              </div>
              <div class="cell-md-4">
                  <label for="detalle">Cine paseo del valle</label>
                  <select data-validate="required" data-role="select" id="cine" name="cine">
                      <option>La Calera</option>
                      <option>Quillota</option>
                  </select>
                  <br>
              </div>
          </div>
          <div class="row">
              <div class="cell-md-8">
                <label for="nombre-completo">Nombre Completo</label>
                <input id="nombre" name="nombre" data-validate="required" type="text" class="mt-1">
                <br>
              </div>
          </div>
          <div class="row">
              <div class="cell-md-4">
                <label for="nombre-completo">Correo electrónico</label>
                <input name="email" id="email" data-validate="required" type="text" class="mt-1">
                <br>
              </div>
              <div class="cell-md-4">
                <label for="nombre-completo">Teléfono de contacto</label>
                <input name="telefono" id="telefono" data-validate="required" type="text" class="mt-1">
                <br>
              </div>
          </div>
          <div class="row">
              <div class="cell-md-8">
                <label for="nombre-completo">Mensaje</label>
                <textarea data-validate="required" data-role="textarea" name="mensaje" id="mensaje"></textarea>
                <br>
              </div>
          </div>
          <div class="row">
            <div class="cell-md-8">
              <button class="button warning rounded enviar-consulta">Enviar Consulta</button>
            </div>
          </div>
      </form>
      <br><br><br>
    </div>
  </div>
  <?php
    include "./footer.php"
  ?>
</body>
</html>
