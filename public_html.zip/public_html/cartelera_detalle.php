<?php
include "methods.php";
?>
<!DOCTYPE html>
<html>
<?php
$title = $_GET['nombre'];
include "./head.php"
?>

<body style="background-color: #e1e1e1;">
  <div id="dialogo_trailer"></div>
  <div class="container" style="background-color: white; padding-left: 0px; padding-right: 0px;">
      <?php
      $active = "peliculas";
      include "./nav.php";
      ?>
      <div class="row movil" style="width: 100%;">
        <div class="cell-sm-full cell-md-full cell-lg-full">
          <div id="banner-pelicula"></div>
        </div>
      </div>
      <div class="row" style="padding-left: 10px; padding-right: 10px;">
        <div class="cell-sm-full cell-md-2 cell-lg-3">
          <div id="caratula"></div>
          <br>
          <div class="content">
            <b>SINOPSIS</b>
            <p class="sinopsis" style="font-size: 15px;">
            </p>
            <br>
            <b>DIRECTOR</b>
            <p class="director" style="font-size: 15px;"></p>
            <br>
            <b>REPARTO</b>
            <p class="reparto" style="font-size: 15px;"></p>
          </div>
        </div>
        <div class="cell-sm-full cell-md-full cell-lg-4 offset-lg-1">
          <div>
            <span class="titulo_cartelera_detail"></span>
            <div style="margin-bottom: 10px;"></div>
            <span id="content-idioma"></span>
            <span id="content-duracion"></span>
            <span id="content-restriccion"></span>
            <button onclick="Metro.dialog.open('#demoDialog1')" style="margin-left: 10px;" class="button alert rounded small">VER TRAILER</button>
            <h4 class="font-gray horarios-title"></h4>
            <div class="informacion-2d"></div>
            <div class="informacion-3d"></div>
            <a href="https://sertex.stonline.cl/CinePaseodelValle/VentaTickets/cpvFrontOffice/"><button class="button alert rounded"><span class="mif-add-shopping-cart icon" style="margin-right: 10px;"></span> Compra <b style="margin-left: 4px;">Online</b></button></a>
          </div>
        </div>
      </div>
      <br><br>
  </div>
  <?php
  include "./footer.php"
  ?>
  <script>
    var nombre_pelicula = '';
    var restriccion_inicio = '';
    var restriccion_fin = '';

    function dialogRestriccion() {
      Metro.dialog.create({
        title: "RESTRICCIÓN",
        width: 700,
        clsDialog: 'alert',
        content: `
            <div>
                <span>
                    SE INFORMA QUE LA PELICULA ${nombre_pelicula.toUpperCase()} TIENE RESTRICCIÓN ENTRE LOS DÍAS ${restriccion_inicio} Y ${restriccion_fin}, LO QUE CONTEMPLA SU PREVENTA, Y EL USO DE:
                </span>
                <br>
                <ul>
                    <li>TODO TIPO DE PROMOCIONES</li>
                    <li>CONVENIO</li>
                </ul>
            </div>`,
        closeButton: true
      });
    }

    $(document).ready(function() {
      moment.locale('es');
      let params = new URLSearchParams(location.search);
      var id_pelicula = params.get('id');
      $.get("./api/getPeliculasById.php?id=" + id_pelicula, function(data) {
        data.forEach(function(pelicula) {

          nombre_pelicula = pelicula.nombre_pelicula;
          restriccion_inicio = pelicula.fecha_inicio_restriccion;
          restriccion_fin = pelicula.fecha_fin_restriccion;

          let clasificacion = "";
          if (pelicula.clasificacion === 'TE') {
            clasificacion = "TODO ESPECTADOR";
          }
          if (pelicula.clasificacion === 'TE+7') {
            clasificacion = "TODO ESPECTADOR, INCONVENIENTE PARA MENORES DE 7 AÑOS";
          }
          if (pelicula.clasificacion === '+14') {
            clasificacion = "MAYORES DE 14 AÑOS";
          }
          $("#dialogo_trailer").append(`
                    <div 
                        class="dialog dialog-custom" 
                        data-overlay-alpha="0.7" 
                        id="demoDialog1" 
                        data-width="900" 
                        data-close-button="true" 
                        data-role="dialog">
                        <div 
                            class="dialog-title">
                            <span 
                                class="titulo-dialogo">
                                <span 
                                    class="mif-video-camera">
                                </span> TRAILER
                            </span>
                        </div>
                        <div
                            class="dialog-content content-dialog">
                            <iframe class="trailer" src="${pelicula.trailer}" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <div 
                            class="dialog-actions" 
                            style="display: none">
                            <button 
                                class="button warning rounded js-dialog-close derecha">Cerrar
                            </button>
                        </div>
                    </div>`)


          $("#banner-pelicula").html(`
              <div style="display: inline-block; position:relative; width: 100%; margin-bottom: 20px;">
                  <div style="background-color: #000000;">
                    <img src="${pelicula.banner}" style="width: 100%; height: 350px; opacity: 0.4;" />
                  </div>
                  <div style="display: inline-block; position:absolute; top:46%; left:50%; transform: translate(-50%, -50%)">
                      <img onclick="Metro.dialog.open('#demoDialog1')" style="cursor: pointer; width: 120px;" border="0" src="https://pngimage.net/wp-content/uploads/2018/06/icono-youtube-png-5.png"/>
                  </div>
              </div>
          `)
          $("#caratula").html(`<img width="100%" src="${pelicula.cover}" alt="" srcset="">`)
          $(".titulo_cartelera_detail").append(pelicula.nombre_pelicula.toUpperCase())
          if (pelicula.duracion) {
            $("#content-duracion").html(`<button style="margin-left: 10px;" class="button secondary outline rounded small">${pelicula.duracion} min</button>`)
          }
          if (pelicula.clasificacion) {
            $("#content-idioma").html(`<button style="data-role="hint" data-hint-position="bottom" data-hint-text="${clasificacion}" class="button warning outline rounded small">${pelicula.clasificacion}</button>`)
          }
          if (pelicula.restriccion === "1") {
            $("#content-restriccion").html(`<button onclick="dialogRestriccion()" style="margin-left: 10px;" class="button alert outline rounded small">RESTRICCIÓN</button>`)
          }
          $(".sinopsis").append(pelicula.sinopsis_pelicula)
          $(".director").append(pelicula.director_pelicula)
          $(".reparto").append(pelicula.reparto_pelicula)

          if (pelicula["2d"] === "1") {
            let horarios_2d = JSON.parse(pelicula.horarios_pelicula_2d);
            let horarios_2d_subtitulada = JSON.parse(pelicula.horarios_pelicula_2d_subtitulada);
            let data_horarios_2d = "";
            let data_horarios_2d_subtitulada = "";
            for (var i = 0; i < horarios_2d.length; i++) {
              data_horarios_2d = data_horarios_2d + `<button style="background-color: #636363; margin-right: 15px; margin-bottom: 15px; border-radius: 4px;" class="button secondary inline button_comprar">${horarios_2d[i]}</button>`;
            }
            for (var i = 0; i < horarios_2d_subtitulada.length; i++) {
              data_horarios_2d_subtitulada = data_horarios_2d_subtitulada + `<button style="background-color: #636363; margin-right: 15px; margin-bottom: 15px; border-radius: 4px;" class="button secondary inline button_comprar">${horarios_2d_subtitulada[i]}</button>`;
            }

            $(".informacion-2d").append(`<span>DESDE EL ${pelicula.fecha_inicio_2d ? moment(new Date(pelicula.fecha_inicio_2d)).format('LL').toUpperCase() : ""} HASTA EL ${pelicula.fecha_fin_2d ? moment(new Date(pelicula.fecha_fin_2d)).format('LL').toUpperCase() : ""}</span>
                  <br><br><button style="margin-bottom: 15px; border-radius: 4px; background-color: #636363;" class="button secondary">FORMATO 2D</button>
                  ${horarios_2d.length > 0 ? `<div class="horarios_responsive">${data_horarios_2d}</div><button class="button warning rounded">DOBLADA AL ESPAÑOL</button><br><br>` : ''}
                  ${horarios_2d_subtitulada.length > 0 ? `<div class="horarios_responsive">${data_horarios_2d_subtitulada}</div><button class="button warning rounded">SUBTITULADA</button>` : ``}
                  `)

          }

          if (pelicula["3d"] === "1") {
            let horarios_3d = JSON.parse(pelicula.horarios_pelicula_3d);
            let horarios_3d_subtitulada = JSON.parse(pelicula.horarios_pelicula_3d_subtitulada);
            let data_horarios_3d = "";
            let data_horarios_3d_subtitulada = "";
            for (var i = 0; i < horarios_3d.length; i++) {
              data_horarios_3d = data_horarios_3d + `<button style="background-color: #636363; margin-right: 15px; margin-bottom: 15px; border-radius: 4px;" class="button secondary inline button_comprar">${horarios_3d[i]}</button>`;
            }
            for (var i = 0; i < horarios_3d_subtitulada.length; i++) {
              data_horarios_3d_subtitulada = data_horarios_3d_subtitulada + `<button style="background-color: #636363; margin-right: 15px; margin-bottom: 15px; border-radius: 4px;" class="button secondary inline button_comprar">${horarios_3d_subtitulada[i]}</button>`;
            }

            $(".informacion-3d").append(`<hr><span>DESDE EL ${pelicula.fecha_inicio_2d ? moment(new Date(pelicula.fecha_inicio_2d)).format('LL').toUpperCase() : ""} HASTA EL ${pelicula.fecha_fin_2d ? moment(new Date(pelicula.fecha_fin_2d)).format('LL').toUpperCase() : ""}</span>
                  <br><br><button style="margin-bottom: 15px; border-radius: 4px; background-color: #636363;" class="button secondary">FORMATO 3D</button>
                  <div class="horarios_responsive">
                    ${data_horarios_3d}
                  </div>
                  <button class="button warning rounded">DOBLADA AL ESPAÑOL</button>
                  ${horarios_3d_subtitulada.length > 0 ? `<br><br><div class="horarios_responsive">${data_horarios_3d_subtitulada}</div><button class="button warning rounded">SUBTITULADA</button>` : ``}`)
          }
        });
      }, "json");
      /* let smallTagText = "";
      $(document).on({
          mouseenter: function () {
            $(this).css("background-color", "red");
            $(this).css("border", "none");
            smallTagText = $(this).text()
            $(this).text("Comprar");
          },
          mouseleave: function () {
            $(this).css("background-color", "#636363");
            $(this).text(smallTagText);
          }
      }, ".button_comprar"); */
    });
  </script>
  <script src="https://cdn.metroui.org.ua/v4/js/metro.min.js"></script>
</body>
<style>
  .jconfirm-box-container {
    margin: 0 auto !important;
  }
</style>

</html>