<?php
session_start();
if (isset($_SESSION['email'])) {
?>
  <html>
  <?php
  include("./head.php")
  ?>

  <body>
    <?php
    include("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
      <div class="appbar bg-red z-1" data-role="appbar">
        <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
          <span class="mif-menu fg-white"></span>
        </button>
      </div>

      <div class="h-100 p-4">
        <p class="h1">Administrar Peliculas</p>
        <br>
        <a href="./create_pelicula.php" class="button warning"><span class="mif-add icon"></span> Agregar Pelicula</a>
        <br><br>
        <div id="data-cartelera"></div>
      </div>
    </div>

    <script>
      function editarPelicula() {
        var id = $(event.target).parents("tr").find("td").eq(2).text();
        var destino = "./editarPelicula.php" + "?" + "id=" + id;
        location.href = destino;
      }

      function deletePelicula(cell) {
        var id = $(event.target).parents("tr").find("td").eq(2).text();
        var nombre_pelicula = $(event.target).parents("tr").find("td").eq(3).text();
        var cover = $(event.target).parents("tr").find("td").eq(6).text();
        var banner = $(event.target).parents("tr").find("td").eq(7).text();
        Swal.fire({
          title: '¿Estás seguro?',
          text: `Estás a punto de eliminar ${nombre_pelicula}`,
          type: 'warning',
          showCancelButton: true,
          cancelButtonText: 'Cancelar',
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Aceptar'
        }).then((result) => {
          if (result.value) {
            $.post("../api/deletePelicula.php", {
              id: id,
              cover: cover,
              banner: banner
            }, function(response) {
              if (response == 1) {
                Swal.fire(
                  'Pelicula eliminada!',
                  `${nombre_pelicula} ha sido eliminada correctamente!`,
                  'success'
                ).then((r) => {
                  location.href = "./admin_peliculas.php"
                })
              } else {
                Swal.fire({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Ha ocurrido un error!',
                  footer: `${response}`
                })
              }
            })
          }
        })
      }
      $(document).ready(function() {
        $.get("../api/getPeliculas.php", function(data) {
          let tbody = "";
          for (i = 0; i < data.length; i++) { //cuenta la cantidad de registros
            tbody = tbody + `
                    <tr>
                        <td>${data[i].id}</td>
                        <td>${data[i].nombre_pelicula}</td>
                        <td>${data[i].cine}</td>
                        <td>${data[i].proximo_estreno === "1" ? "Próximo estreno" : (data[i].estreno === "1" ? "Estreno" : "Cartelera")}</div></td>
                        <td>${data[i].cover}</td>
                        <td>${data[i].banner}</td>
                        <td><button onclick='editarPelicula()' class='button info'>Editar</button><button onclick='deletePelicula(this)' style='margin-left: 10px;' class='button alert'>Eliminar</button></td>
                    </tr>`;
          }

          $("#data-cartelera").append(`
                    <table data-table-info-title="Visualizando $1 a $2 de $3 resultados" data-pagination-prev-title="Página anterior" data-pagination-next-title="Página siguiente" data-table-search-title="Búsqueda avanzada" data-role="table" data-show-rows-steps="false" class="table table-border cell-border">
                        <thead>
                            <tr>
                                <th data-show="false">#</th>
                                <th data-sortable="true">Nombre Pelicula</th>
                                <th>Cine</th>
                                <th data-sortable="true">Estado</th>
                                <th data-show="false">Cover</th>
                                <th data-show="false">Banner</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        ${tbody}
                        </tbody>
                    </table>
                `)
        }, "json");
      });
    </script>
    <?php
    include("./footer.php");
    ?>
  </body>

  </html>
<?php
} else {
  // Redirect them to the login page
  header("Location: ./index.php");
}
?>