<?php
session_start();
if (isset($_SESSION['email'])) {
?>
  <html>
  <?php
  include("./head.php")
  ?>

  <body>
    <?php
    include("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
      <div class="appbar bg-red z-1" data-role="appbar">
        <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
          <span class="mif-menu fg-white"></span>
        </button>
      </div>

      <div class="h-100 p-4">
        <p class="h1">Crear usuario</p>
        <br>
        <form data-role="validator" id="form-add-usuario" method="post" action="../api/add_usuario.php" enctype="multipart/form-data">
          <div class="row">
            <div class="cell-md-12">
              <label for="nombre">Foto de perfil</label>
              <input data-button-title="+" data-validate="required" id="uploadImage" type="file" accept="image/*" name="image" type="file" data-role="file" data-prepend="Seleccione imagen:">
            </div>
            <div class="cell-md-6">
              <br>
              <label for="nombre">Email</label>
              <input data-role="input" data-validate="required" name="email" id="email" type="text" placeholder="Ingrese email">
            </div>
            <div class="cell-md-6">
              <br>
              <label for="ciudad">Contraseña</label>
              <input data-role="input" data-validate="required" name="passwd" id="passwd" type="password" placeholder="Ingrese contraseña">
            </div>
          </div>
          <br>
          <div class="centrar">
            <button onclick="history.back(); return false;" class="button js-dialog-close">Regresar</button>
            <button class="button warning js-dialog-close">Registrar Usuario</button>
          </div>
          <br><br><br>
        </form>
      </div>
    </div>

    <script>
      $(document).ready(function() {
        $("#form-add-usuario").submit(function(e) {
          e.preventDefault();
          var email = $("#email").val();
          var password = $("#passwd").val();
          if (
            email !== "" && password !== ""
          ) {
            $.ajax({
              url: "../api/addUsuario.php",
              type: "POST",
              data: new FormData(this),
              contentType: false,
              cache: false,
              processData: false,
              success: function(result) {
                if (result == 1) {
                  PNotify.success({
                    title: 'Información',
                    text: 'Usuario registrado correctamente.'
                  });
                  setTimeout(function() {
                    location.href = "./admin_users.php"
                  }, 3000);
                } else {
                  PNotify.error({
                    title: 'Información',
                    text: 'No fue posible registrar el usuario, verifique que todos los campos han sido completados.'
                  });
                }
              }
            });
          } else {
            PNotify.info({
              title: 'Advertencia',
              text: 'Debes completar todos los campos.'
            });
          }
        });
      });
    </script>
    <?php
    include("./footer.php");
    ?>
  </body>

  </html>
<?php
} else {
  // Redirect them to the login page
  header("Location: ./index.php");
}
?>