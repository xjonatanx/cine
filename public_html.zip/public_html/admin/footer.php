<script src="https://cdn.metroui.org.ua/v4/js/metro.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.10/datepicker.min.js"></script>