<?php
session_start();
if (isset($_SESSION['email'])) {
?>
  <html>
  <?php
  include("./head.php")
  ?>

  <body>
    <?php
    include("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
      <div class="appbar bg-red z-1" data-role="appbar">
        <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
          <span class="mif-menu fg-white"></span>
        </button>
      </div>

      <div class="h-100 p-4">
        <p class="h1">Editar cine</p>
        <br>
        <form data-role="validator" id="form-image-cine" method="post" enctype="multipart/form-data">
          <div class="row flex-align-center">
            <div class="cell-md-3">
              <div class="img-container thumbnail"><img id="img_cine" width="300px" height="200px" src="" alt=""></div>
              <br class="escritorio">
            </div>
            <div class="cell-md-9">
              <label for="nombre">Imagen del cine (869 x 535)</label>
              <input data-button-title="+" data-validate="required" id="uploadImage" type="file" accept="image/*" name="image" type="file" data-role="file" data-prepend="Seleccione imagen:">
              <input style="display: none;" type="text" id="id_cine" name="id_cine" />
              <input style="display: none;" type="text" id="url_imagen_actual" name="url_imagen_actual" />
              <br>
              <button class="button info js-dialog-close">Cambiar Imagen</button>
            </div>
        </form>
        <form data-role="validator" id="form-edit-cine" method="post" enctype="multipart/form-data">
          <div class="row">
            <div class="cell-md-4">
              <br>
              <label for="nombre">Nombre</label>
              <input data-role="input" data-validate="required" id="nombre_cine" type="text" placeholder="Ingrese nombre del cine">
            </div>
            <div class="cell-md-4">
              <br>
              <label for="ciudad">Ciudad</label>
              <input data-role="input" data-validate="required" id="ciudad_cine" type="text" placeholder="Ingrese ciudad del cine">
            </div>
            <div class="cell-md-4">
              <br>
              <label for="direccion">Dirección</label>
              <input data-role="input" data-validate="required" id="direccion_cine" type="text" placeholder="Ingrese dirección del cine">
            </div>
            <div class="cell-md-6">
              <br>
              <label for="apertura">Hora de apertura</label>
              <div id="hora-apertura"></div>
            </div>
            <div class="cell-md-6">
              <br>
              <label for="cierre">Hora de cierre</label>
              <div id="hora-cierre"></div>
            </div>
            <div class="cell-md-6">
              <br>
              <label id="inicio_cine" for="duracion">Día inicio</label>
              <select id="dia_inicio_cine" data-validate="required" data-role="select">
                <option value="Lunes">Lunes</option>
                <option value="Martes">Martes</option>
                <option value="Miercoles">Miercoles</option>
                <option value="Jueves">Jueves</option>
                <option value="Viernes">Viernes</option>
                <option value="Sábado">Sábado</option>
                <option value="Domingo">Domingo</option>
              </select>
            </div>
            <div class="cell-md-6">
              <br>
              <label for="fin_cine">Día fin</label>
              <select id="dia_fin_cine" data-validate="required" data-role="select">
                <option value="Lunes">Lunes</option>
                <option value="Martes">Martes</option>
                <option value="Miercoles">Miercoles</option>
                <option value="Jueves">Jueves</option>
                <option value="Viernes">Viernes</option>
                <option value="Sábado">Sábado</option>
                <option value="Domingo">Domingo</option>
              </select>
            </div>
            <div class="cell-md-12">
              <br>
              <label for="dir_map">Dirección del mapa (Google Maps)</label>
              <input data-role="input" id="dir_map_cine" data-validate="required" id="url_trailer" type="text" placeholder="Ingrese dirección del mapa">
            </div>
          </div>
          <br><br>
          <div class="centrar">
            <button onclick="regresar();" class="button js-dialog-close">Regresar</button>
            <button onclick="editarCine();" class="button warning js-dialog-close">Editar Cine</button>
          </div>
        </form>
        <br><br><br>
      </div>
    </div>

    <script>
      let params = new URLSearchParams(location.search);
      var id_cine = params.get('id');
      var url_actual = "";

      function editarCine() {
        var nombre_cine = $("#nombre_cine").val();
        var ciudad_cine = $("#ciudad_cine").val();
        var direccion_cine = $("#direccion_cine").val();
        var apertura_cine = $("#apertura_cine").val();
        var cierre_cine = $("#cierre_cine").val();
        var dia_inicio_cine = $("#dia_inicio_cine").val();
        var dia_fin_cine = $("#dia_fin_cine").val();
        var dir_map_cine = $("#dir_map_cine").val();
        if (
          nombre_cine !== "" && ciudad_cine !== "" && direccion_cine !== "" &&
          apertura_cine !== "" && cierre_cine !== "" && dia_inicio_cine !== "" &&
          dia_fin_cine !== "" && dir_map_cine !== ""
        ) {
          $.post("../api/editCine.php", {
            id: id_cine,
            nombre_cine: nombre_cine,
            ciudad_cine: ciudad_cine,
            direccion_cine: direccion_cine,
            apertura_cine: apertura_cine,
            cierre_cine: cierre_cine,
            dia_inicio_cine: dia_inicio_cine,
            dia_fin_cine: dia_fin_cine,
            dir_map_cine: dir_map_cine,
          }, function(result) {
            if (result == 1) {
              Swal.fire({
                type: 'success',
                title: 'Información',
                text: 'Cine modificado correctamente.',
              }).then((r) => {
                location.href = "./admin_cines.php"
              })
            } else {
              Swal.fire({
                type: 'error',
                title: 'Ha ocurrido un error!',
                text: `${result}`
              })
            }

          })
        } else {
          Swal.fire({
            type: 'warning',
            title: 'Oops...',
            text: 'Debes completar todos los campos.'
          })
        }
      }

      function regresar() {
        history.back();
      }

      $(document).ready(function() {
        $("#form-edit-cine").on('submit', function(evt) {
          evt.preventDefault();
        });
        $("#form-image-cine").on('submit', function(e) {
          e.preventDefault();
          if (id_cine && url_actual) {
            $.ajax({
              url: "../api/change_img_cine.php",
              type: "POST",
              data: new FormData(this),
              contentType: false,
              cache: false,
              processData: false,
              success: function(result) {
                if (result == 1) {
                  Swal.fire({
                    type: 'success',
                    title: 'Información',
                    text: 'Imagen modificada correctamente.',
                  }).then((r) => {
                    location.reload();
                  })
                } else {
                  Swal.fire({
                    type: 'error',
                    title: 'Ha ocurrido un error!',
                    text: `${result}`
                  })
                }
              }
            });
          } else {
            Swal.fire({
              type: 'warning',
              title: 'Oops...',
              text: 'Debes completar todos los campos requeridos.'
            })
          }
        });
        $.get("../api/getCinesById.php?id=" + id_cine, function(data) {
          $("#hora-apertura").append(`<input data-validate="required" id="apertura_cine" data-role="timepicker" placeholder="Ingrese horario de apertura del cine">`);
          $("#hora-cierre").append(`<input data-validate="required" id="cierre_cine" data-role="timepicker" placeholder="Ingrese horario de cierre del cine">`);
          $('#nombre_cine').val(data[0]["nombre"]);
          $('#ciudad_cine').val(data[0]["ciudad"]);
          $('#direccion_cine').val(data[0]["direccion"]);
          $('#apertura_cine').val(data[0]["hora_apertura"]);
          $('#cierre_cine').val(data[0]["hora_cierre"]);
          $('#dia_inicio_cine').val(data[0]["dia_inicio"]);
          $('#dia_fin_cine').val(data[0]["dia_fin"]);
          $('#dir_map_cine').val(data[0]["dir_map"]);
          $("#img_cine").attr("src", `../${data[0]["url_imagen"]}`);
          url_actual = data[0]["url_imagen"];
          $("#url_imagen_actual").val(data[0]["url_imagen"]);
          $("#id_cine").val(id_cine);
        }, "json")
      });
    </script>
    <?php
    include("./footer.php");
    ?>
  </body>

  </html>
<?php
} else {
  // Redirect them to the login page
  header("Location: ./index.php");
}
?>