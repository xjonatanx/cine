<?php
session_start();
if (isset($_SESSION['email'])) {
?>
  <?php
  include("./head.php")
  ?>
  <aside style="overflow-x: hidden !important; overflow: auto; font-size: 14px; width: 220px;" class="sidebar z-2" data-role="sidebar" data-toggle="#sidebar-toggle-4" id="sb4" data-shift=".shifted-content-2" data-static-shift=".shifted-content-2" data-static="md">
    <ul class="sidebar-menu" style="height: auto !important;">
      <li><a style="padding-left: 25px;" href="./menu.php"><span class="mif-chart-bars" style="margin-right: 10px;"></span>Dashboard</a></li>
      <li><a style="padding-left: 25px;" href="./admin_slider.php"><span class="mif-images" style="margin-right: 10px;"></span>Slider inicio</a></li>
      <li><a style="padding-left: 25px;" href="./admin_peliculas.php"><span class="mif-video-camera" style="margin-right: 10px;"></span>Peliculas</a></li>
      <li><a style="padding-left: 25px;" href="./admin_promociones.php"><span class="mif-cart" style="margin-right: 10px;"></span>Slider promociones</a></li>
      <li><a style="padding-left: 25px;" href="./admin_cines.php"><span class="mif-widgets" style="margin-right: 10px;"></span>Cines</a></li>
      <li><a style="padding-left: 25px;" href="./admin_confiteria.php"><span class="mif-shop" style="margin-right: 10px;"></span>Confitería</a></li>
      <li><a style="padding-left: 25px;" href="./admin_promociones_web.php"><span class="mif-dollars" style="margin-right: 10px;"></span>Promociones</a></li>
      <?php
      if ($_SESSION['can_admin_user'] == 1) {
        echo '<li><a style="padding-left: 25px;" href="./admin_users.php"><span class="mif-user" style="margin-right: 10px;"></span>Usuarios</a></li>';
      } else {
        echo '';
      }
      ?>
      <li><a style="padding-left: 25px;" href="./admin_birthday.php"><span class="mif-magic-wand" style="margin-right: 10px;"></span>Cumpleaños</a></li>
      <li><a style="padding-left: 25px;" href="./admin_colegios.php"><span class="mif-library" style="margin-right: 10px;"></span>Colegios</a></li>
      <li><a style="padding-left: 25px;" href="./admin_entradas_corporativas.php"><span class="mif-tags" style="margin-right: 10px;"></span>Entradas corporativas</a></li>
      <li><a style="padding-left: 25px;" href="./admin_publicidad.php"><span class="mif-earth2" style="margin-right: 10px;"></span>Publicidad en cines</a></li>
      <br>
      <li onclick="logout()" style="color: white;" class="bg-red"><a style="padding-left: 25px;" href="#"><span class="mif-exit" style="margin-right: 10px;"></span>Cerrar sesión</a></li>
    </ul>
    <div class="centrar">
      <br>
      <img width="130px" style="margin-top: 20px;" src="https://cinepaseodelvalle.cl/logo_chico.png">
    </div>
  </aside>
<?php
} else {
  // Redirect them to the login page
  header("Location: ./index.php");
}
?>

<script>
  function logout() {
    $.get("../api/logout.php", function(data) {}, "json");
    location.href = "./index.php";
  }
</script>