<div class="centrar" hidden id="content-auth-button">
  <br>
  <button class="button primary" id="auth-button" hidden>Iniciar sesión (Google Analytics)</button>
  <br><br>
</div>
<div class="row" id="content-graph">
    <div class="cell-md-4">
      <div class="card">
          <div class="card-header centrar">
              ¿Cuáles son sus dispositivos principales?
          </div>
          <div class="card-content p-2">
              <div id="devices"></div>
          </div>
      </div>
    </div>
    <div class="cell-md-4">
      <div class="card">
          <div class="card-header centrar">
              ¿Dónde están sus usuarios?
          </div>
          <div class="card-content p-2">
              <div id="region"></div>
          </div>
      </div>
    </div>
    <div class="cell-md-4">
      <div class="card">
          <div class="card-header centrar">
              ¿Desde que sistema acceden sus usuarios?
          </div>
          <div class="card-content p-2">
              <div id="system"></div>
          </div>
      </div>
    </div>
    <div class="cell-md-4">
      <div class="card">
          <div class="card-header centrar">
              Cantidad de visitas por dispositivo
          </div>
          <div class="card-content p-2">
              <div id="views"></div>
          </div>
      </div>
    </div>
    <div class="cell-md-4">
      <div class="card">
          <div class="card-header centrar">
              Cantidad de visitas por ciudad
          </div>
          <div class="card-content p-2">
              <div id="views_city"></div>
          </div>
      </div>
    </div>
    <div class="cell-md-4">
      <div class="card">
          <div class="card-header centrar">
              Cantidad de visitas por páginas
          </div>
          <div class="card-content p-2">
            <div class="content_visitas">
              <table class="tabla_visitas">
                <thead>
                  <th>Página</th>
                  <th>Visitas</th>
                </thead>
                <tbody id="body_page_views">
                </tbody>
              </table>
            </div>
          </div>
      </div>
    </div>
</div>

<script>
  var needAuthorize = false;
  // Replace with your client ID from the developer console.
  var CLIENT_ID = '209430628420-rm7nju09m1fkv5sjs6givk0tdfa8aaqe.apps.googleusercontent.com';

  // Set authorized scope.
  var SCOPES = ['https://www.googleapis.com/auth/analytics.readonly'];

  function authorize(event) {
    // Handles the authorization flow.
    // `immediate` should be false when invoked from the button click.
    var useImmdiate = event ? false : true;
    needAuthorize = useImmdiate;
    var authData = {
      client_id: CLIENT_ID,
      scope: SCOPES,
      immediate: useImmdiate
    };

    gapi.auth.authorize(authData, function(response) {
      var authButton = document.getElementById('auth-button');
      var content = document.getElementById('content-auth-button');
      var content_graph = document.getElementById('content-graph');
      if (response.error) {
        authButton.hidden = false;
        content.hidden = false;
        content_graph.hidden = true;
      }
      else {
        authButton.hidden = true;
        content.hidden = true;
        content_graph.hidden = false;
        queryAccounts();
      }
    });
  }

function queryAccounts() {
  // Load the Google Analytics client library.
  gapi.client.load('analytics', 'v3').then(function() {

    // Get a list of all Google Analytics accounts for this user
    gapi.client.analytics.management.accounts.list().then(handleAccounts);
  });
}

function handleAccounts(response) {
  // Handles the response from the accounts list method.
  if (response.result.items && response.result.items.length) {
    // Get the first Google Analytics account.
    var firstAccountId = response.result.items[0].id;

    // Query for properties.
    queryProperties(firstAccountId);
  } else {
    console.log('No accounts found for this user.');
  }
}

function queryProperties(accountId) {
  // Get a list of all the properties for the account.
  gapi.client.analytics.management.webproperties.list(
      {'accountId': accountId})
    .then(handleProperties)
    .then(null, function(err) {
      // Log any errors.
      console.log(err);
  });
}

function handleProperties(response) {
  // Handles the response from the webproperties list method.
  if (response.result.items && response.result.items.length) {

    // Get the first Google Analytics account
    var firstAccountId = response.result.items[0].accountId;

    // Get the first property ID
    var firstPropertyId = response.result.items[0].id;

    // Query for Views (Profiles).
    queryProfiles(firstAccountId, firstPropertyId);
  } else {
    console.log('No properties found for this user.');
  }
}

function queryProfiles(accountId, propertyId) {
  // Get a list of all Views (Profiles) for the first property
  // of the first Account.
  gapi.client.analytics.management.profiles.list({
      'accountId': accountId,
      'webPropertyId': propertyId
  })
  .then(handleProfiles)
  .then(null, function(err) {
      // Log any errors.
      console.log(err);
  });
}

function handleProfiles(response) {
  // Handles the response from the profiles list method.
  if (response.result.items && response.result.items.length) {
    // Get the first View (Profile) ID.
    var firstProfileId = response.result.items[0].id;

    // Query the Core Reporting API.
    queryCoreReportingApi(firstProfileId);
  } else {
    console.log('No views (profiles) found for this user.');
  }
}

function queryCoreReportingApi(profileId) {
  // Query the Core Reporting API for the number sessions for
  // the past seven days.
  gapi.client.analytics.data.ga.get({
    'ids': 'ga:' + profileId,
    'start-date': '7daysAgo',
    'end-date': 'today',
    'metrics': 'ga:users,ga:pageviews',
    'dimensions': 'ga:country,ga:region,ga:city,ga:deviceCategory,ga:browser,ga:operatingSystem'
  })
  .then(function(response) {
    let datos = response.result.rows;
    /* DEVICES */
    let legend = [];
    let colums = [];
    for (let i = 0; i < datos.length; i++) {
      legend.push(datos[i][3])
    }
    let unique_legend = legend.unique();
    for (let i = 0; i < unique_legend.length; i++) {
      let total = 0;
      let results = datos.filter(array => array.includes(unique_legend[i]));
      for (let index = 0; index < results.length; index++) {
        total = total + parseInt(results[index][6]);
      }
      colums.push([unique_legend[i], total])
    }
    var chart = c3.generate({
        bindto: '#devices',
        data: {
          columns: colums,
          type : 'pie'
        }
    });
    /* REGION */
    let legend_region = [];
    let colums_region = [];
    for (let i = 0; i < datos.length; i++) {
      legend_region.push(datos[i][1])
    }
    let unique_legend_region = legend_region.unique();
    for (let i = 0; i < unique_legend_region.length; i++) {
      let total = 0;
      let results = datos.filter(array => array.includes(unique_legend_region[i]));
      for (let index = 0; index < results.length; index++) {
        total = total + parseInt(results[index][6]);
      }
      colums_region.push([unique_legend_region[i], total])
    }
    var chart = c3.generate({
        bindto: '#region',
        data: {
          columns: colums_region,
          type : 'pie'
        }
    });
    /* SYSTEM */
    let legend_system = [];
    let colums_system = [];
    for (let i = 0; i < datos.length; i++) {
      legend_system.push(datos[i][5])
    }
    let unique_legend_system = legend_system.unique();
    for (let i = 0; i < unique_legend_system.length; i++) {
      let total = 0;
      let results = datos.filter(array => array.includes(unique_legend_system[i]));
      for (let index = 0; index < results.length; index++) {
        total = total + parseInt(results[index][6]);
      }
      colums_system.push([unique_legend_system[i], total])
    }
    var chart = c3.generate({
        bindto: '#system',
        data: {
          columns: colums_system,
          type : 'pie'
        }
    });
    /* QUANTITY VIEWS PER DEVICE */
    let legend_views = [];
    let colums_views = [];
    for (let i = 0; i < datos.length; i++) {
      legend_views.push(datos[i][3])
    }
    let unique_legend_views = legend_views.unique();
    for (let i = 0; i < unique_legend_views.length; i++) {
      let total = 0;
      let results = datos.filter(array => array.includes(unique_legend_views[i]));
      for (let index = 0; index < results.length; index++) {
        total = total + parseInt(results[index][7]);
      }
      colums_views.push([unique_legend_views[i], total])
    }
    var chart = c3.generate({
        bindto: '#views',
        data: {
          columns: colums_views,
          type : 'bar'
        }
    });
    /* QUANTITY VIEWS PER CITY */
    let legend_views_vity = [];
    let colums_views_city = [];
    for (let i = 0; i < datos.length; i++) {
      legend_views_vity.push(datos[i][2])
    }
    let unique_legend_views_vity = legend_views_vity.unique();
    for (let i = 0; i < unique_legend_views_vity.length; i++) {
      let total = 0;
      let results = datos.filter(array => array.includes(unique_legend_views_vity[i]));
      for (let index = 0; index < results.length; index++) {
        total = total + parseInt(results[index][7]);
      }
      colums_views_city.push([unique_legend_views_vity[i], total])
    }
    var chart = c3.generate({
        bindto: '#views_city',
        data: {
          columns: colums_views_city,
          type : 'pie'
        }
    });
  })
  .then(null, function(err) {
      // Log any errors.
      console.log(err);
  });

  gapi.client.analytics.data.ga.get({
    'ids': 'ga:' + profileId,
    'start-date': '7daysAgo',
    'end-date': 'today',
    'metrics': 'ga:pageviews',
    'dimensions': 'ga:pageTitle'
  })
  .then(function(response) {
    let datos = response.result.rows;
    let tbody = "";
    for (let i = 0; i < datos.length; i++) {
      tbody = tbody + `<tr><td>${datos[i][0]}</td><td>${datos[i][1]}</td></tr>`;
    }
    $("#body_page_views").append(tbody);
  })
  .then(null, function(err) {
      // Log any errors.
      console.log(err);
  });
}

  // Add an event listener to the 'auth-button'.
  document.getElementById('auth-button').addEventListener('click', authorize);
</script>

<script src="https://apis.google.com/js/client.js?onload=authorize"></script>

<style>
.tabla_visitas {
  border: 1px solid #ccc;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  width: 100%;
  table-layout: fixed;
}

.tabla_visitas caption {
  font-size: 1.5em;
  margin: .5em 0 .75em;
}

.tabla_visitas tr {
  background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;
}

.tabla_visitas th,
.tabla_visitas td {
  padding: .625em;
  text-align: center;
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.tabla_visitas th {
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}

.content_visitas {
  height: 320px;
  overflow: auto;
}
</style>