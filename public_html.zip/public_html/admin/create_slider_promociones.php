<?php
session_start();
if (isset($_SESSION['email'])) {
?>
  <html>
  <?php
  include("./head.php")
  ?>

  <body>
    <?php
    include("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
      <div class="appbar bg-red z-1" data-role="appbar">
        <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
          <span class="mif-menu fg-white"></span>
        </button>
      </div>

      <div class="h-100 p-4">
        <p class="h1">Crear slider Promoción</p>
        <br>
        <form data-role="validator" id="form-add-slider-promocion" method="post" enctype="multipart/form-data">
          <div class="row">
            <div class="cell-md-6">
              <label for="nombre">Nombre identificativo</label><br>
              <input data-role="input" data-validate="required" name="nombre_identificativo" id="nombre_cine" type="text" placeholder="Ingrese nombre identificativo">
              <br>
            </div>
            <div class="cell-md-6">
              <label for="listado_cines">Cine</label>
              <div id="listado_cines"></div>
              <br>
            </div>
            <div class="cell-md-12">
              <label for="cover">Imagen del slider (Escritorio: 1480 x 400, Movil: 375 x 370)</label>
              <input data-button-title="+" data-validate="required" id="uploadImageSlider" type="file" accept="image/*" name="imageSlider" type="file" data-role="file" data-prepend="Seleccione imagen:">
              <br>
            </div>
            <div class="cell-md-12">
              <label for="tipo">Tipo de imagen</label>
              <select id="tipo_imagen" name="tipo_imagen" data-role="select">
                <option value="escritorio">Escritorio</option>
                <option value="movil">Movil</option>
              </select>
            </div>
          </div>
          <br>
          <div class="centrar">
            <button onclick="history.back(); return false;" class="button js-dialog-close">Regresar</button>
            <button class="button warning js-dialog-close">Registrar Promoción</button>
          </div>
        </form>
      </div>
    </div>

    <script>
      $(document).ready(function() {
        $.get(
          "../api/getCines.php",
          function(data) {
            let options = "";
            for (i = 0; i < data.length; i++) {
              options = options + `<option value="${data[i]["id"]}">${data[i]["nombre"]}</option>`;
            }

            let selectCines = `<select data-validate="required" id="id_cine" name="id_cine" data-role="select">
                        ${options}
                    </select>`;

            $("#listado_cines").append(selectCines);
          },
          "json"
        );
        $("#form-add-slider-promocion").submit(function(e) {
          e.preventDefault();
          $.ajax({
            url: "../api/addSliderPromocion.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(result) {
              if (result == 1) {
                Swal.fire({
                  type: 'success',
                  title: 'Información',
                  text: 'Promoción registrada correctamente.',
                }).then((r) => {
                  location.href = "./admin_promociones.php"
                })
              } else {
                Swal.fire({
                  type: 'error',
                  title: 'Ha ocurrido un error!',
                  text: `${result}`
                })
              }
            }
          });
        });
      });
    </script>
    <?php
    include("./footer.php");
    ?>
  </body>

  </html>
<?php
} else {
  // Redirect them to the login page
  header("Location: ./index.php");
}
?>