<?php
session_start();
if ( isset( $_SESSION['email'] ) ) {
?>
<html>
  <?php 
    include ("./head.php")
  ?>
  <body>
    <?php
      include ("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
        <div class="appbar bg-red z-1" data-role="appbar">
            <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
                <span class="mif-menu fg-white"></span>
            </button>
        </div>

        <div class="h-100 p-4">
            <p class="h1">Administrar Confitería</p>
            <br>
            <a href="./create_confiteria.php" class="button warning"><span class="mif-add icon"></span> Agregar Imagen</a>
            <br><br>
            <div id="data-cines"></div>
        </div>
    </div>

    <script>
        function editarConfiteria() {
            var id = $(event.target).parents("tr").find("td").eq(2).text();
            var destino = "./editarConfiteria.php" + "?" + "id=" + id;
            location.href = destino;
        }

        function deleteConfiteria (cell) {
            var id = $(event.target).parents("tr").find("td").eq(2).text();
            var url = $(event.target).parents("tr").find("td").eq(7).text();
            console.log(url)
            Swal.fire({
                title: '¿Estás seguro?',
                text: `Estás a punto de eliminar una imagen de la confitería`,
                type: 'warning',
                showCancelButton: true,
                cancelButtonText: 'Cancelar',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Aceptar'
            }).then((result) => {
                if (result.value) {
                    $.post("../api/deleteConfiteria.php", 
                    { 
                        id: id,
                        url: url
                    }, function(resultado) {
                        if (resultado == 1) {
                            Swal.fire(
                                'Imagen eliminada!',
                                `La imagen ha sido eliminada correctamente!`,
                                'success'
                            ).then((r) => {
                                location.href = "./admin_confiteria.php"
                            })
                        } else {
                            PNotify.error({
                                title: 'Error',
                                text: resultado
                            });
                        }
                    })
                }
            })
        }
        $(document).ready(function() {
            $.get("../api/getAllConfiteria.php", function(data){
                let filas = [];
                let tbody = "";
                for (  i = 0 ; i < data.length; i++){ //cuenta la cantidad de registros
                    var nuevafila= "<tr><td>" +
                    data[i].id + "</td><td>" +
                    data[i].orden + "</td><td>" +
                    data[i].nombre + "</td><td>" +
                    data[i].nombre_cine + "</td><td>" +
                    data[i].create_at + "</td><td>" +
                    data[i].path_direccion + "</td><td>" +
                    "<button onclick='editarConfiteria()' class='button info'>Editar</button><button onclick='deleteConfiteria()' style='margin-left: 10px;' class='button alert'>Eliminar</button></td></tr>";
                    filas.push(nuevafila);
                }
                for (let i = 0; i < filas.length; i++) {
                    tbody = tbody + filas[i]
                }
                $("#data-cines").append(`
                    <table data-table-info-title="Visualizando $1 a $2 de $3 resultados" data-pagination-prev-title="Página anterior" data-pagination-next-title="Página siguiente" data-table-search-title="Búsqueda avanzada" data-role="table" data-show-rows-steps="false" class="table table-border cell-border">
                        <thead>
                            <tr>
                                <th data-show="false">#</th>
                                <th data-sortable="true">Orden</th>
                                <th>Nombre</th>
                                <th data-sortable="true">Cine</th>
                                <th>Fecha de creación</th>
                                <th data-show="false">Dirección</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        ${tbody}
                        </tbody>
                    </table>
                `)
            }, "json");
        });
    </script>
    <?php
      include ("./footer.php");
    ?>
  </body>
</html>
<?php
} else {
    // Redirect them to the login page
    header("Location: ./index.php");
}
?>