<?php
session_start();
if ( isset( $_SESSION['email'] ) ) {
?>
<html>
  <?php 
    include ("./head.php")
  ?>
  <body>
    <?php
      include ("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
        <div class="appbar bg-red z-1" data-role="appbar">
            <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
                <span class="mif-menu fg-white"></span>
            </button>
        </div>

        <div class="h-100 p-4">
            <p class="h1">Administrar Slider Promociones</p>
            <br>
            <a href="./create_slider_promociones.php" class="button warning"><span class="mif-add icon"></span> Agregar Promoción</a>
            <br><br>
            <div id="data-slider-promociones"></div>
        </div>
    </div>
    <script>
      function deleteSlider (cell) {
            var id = $(event.target).parents("tr").find("td").eq(2).text();
            var url = $(event.target).parents("tr").find("td").eq(7).text();
            Swal.fire({
                title: '¿Estás seguro?',
                text: `Estas a punto de eliminar una imagen.`,
                type: 'warning',
                showCancelButton: true,
                cancelButtonText: 'Cancelar',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Aceptar'
            }).then((result) => {
                if (result.value) {
                    $.post("../api/deleteSliderPromociones.php", 
                    { 
                        id: id,
                        url: url
                    }, function(result) {
                        if (result == 1) {
                            Swal.fire(
                                'Imagen eliminada.',
                                `Imagen ha sido eliminada correctamente!`,
                                'success'
                            ).then((r) => {
                                location.href = "./admin_promociones.php"
                            })
                        } else {
                            Swal.fire({
                                type: 'error',
                                title: 'Oops...',
                                text: 'Ha ocurrido un error!',
                                footer: `${result}`
                            })
                        }
                    })
                }
            })
        }
      function editarSlider() {
            var id = $(event.target).parents("tr").find("td").eq(2).text();
            var destino = "./editarSliderPromocion.php" + "?" + "id=" + id;
            location.href = destino;
        }
        $(document).ready(function() {
            $.get("../api/getAllSliderPromocion.php", function(data){
                let filas = [];
                let tbody = "";
                for (  i = 0 ; i < data.length; i++){ //cuenta la cantidad de registros
                    var nuevafila= "<tr><td>" +
                    data[i].id + "</td><td>" +
                    data[i].nombre + "</td><td>" + 
                    data[i].nombre_cine + "</td><td>" +
                    data[i].create_at + "</td><td>" +
                    data[i].tipo.charAt(0).toUpperCase() + data[i].tipo.slice(1) + "</td><td>" +
                    data[i].url_slider + "</td><td>" +
                    "<button onclick='editarSlider()' class='button info'>Editar</button><button onclick='deleteSlider(this)' style='margin-left: 10px;' class='button alert'>Eliminar</button></td></tr>";
                    filas.push(nuevafila);
                }
                for (let i = 0; i < filas.length; i++) {
                    tbody = tbody + filas[i]
                }
                $("#data-slider-promociones").append(`
                    <table data-table-info-title="Visualizando $1 a $2 de $3 resultados" data-pagination-prev-title="Página anterior" data-pagination-next-title="Página siguiente" data-table-search-title="Búsqueda avanzada" data-role="table" data-show-rows-steps="false" class="table table-border cell-border">
                        <thead>
                            <tr>
                                <th data-show="false">#</th>
                                <th>Nombre</th>
                                <th>Cine</th>
                                <th>Fecha creación</th>
                                <th>Tipo</th>
                                <th data-show="false">Url slider</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        ${tbody}
                        </tbody>
                    </table>
                `)
            }, "json");
        });
    </script>
    <?php
      include ("./footer.php");
    ?>
  </body>
</html>
<?php
} else {
    // Redirect them to the login page
    header("Location: ./index.php");
}
?>