<?php
session_start();
if ( isset( $_SESSION['email'] ) ) {
?>
<html>
  <?php 
    include ("./head.php")
  ?>
  <body>
    <?php
      include ("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab" style="margin-left: 260px;">
        <div class="appbar bg-red z-1" data-role="appbar">
            <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
                <span class="mif-menu fg-white"></span>
            </button>
        </div>

        <div class="h-100 p-4">
            <p style="margin-top: 10px;" class="h4">DASHBOARD GENERAL</p>
            <br>
            <?php 
              include ("./Analytics.php")
            ?>
            <br><br><br>
        </div>
    </div>
    <?php
      include ("./footer.php");
    ?>
  </body>
</html>
<?php
} else {
    // Redirect them to the login page
    header("Location: ./index.php");
}
?>