<?php
session_start();
if (isset($_SESSION['email'])) {
?>
  <html>
  <?php
  include("./head.php")
  ?>

  <body>
    <?php
    include("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
      <div class="appbar bg-red z-1" data-role="appbar">
        <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
          <span class="mif-menu fg-white"></span>
        </button>
      </div>

      <div class="h-100 p-4">
        <p class="h1">Crear pelicula</p>
        <br>
        <form data-role="validator" id="form-add-cartelera" method="post" enctype="multipart/form-data">
          <div class="row">
            <div class="cell-md-4">
              <label for="cover">Cover de la pelicula (405 x 607)</label>
              <input data-button-title="+" id="uploadImageCover" type="file" accept="image/*" name="imageCover" type="file" data-role="file" data-prepend="Seleccione imagen:">
              <br>
            </div>
            <div class="cell-md-4">
              <label for="slider">Banner de la pelicula (1480 x 500)</label>
              <input data-button-title="+" id="uploadimageBanner" type="file" accept="image/*" name="imageBanner" type="file" data-role="file" data-prepend="Seleccione imagen:">
              <br>
            </div>
            <div class="cell-md-4">
              <label for="nombre">Nombre Pelicula</label>
              <input data-role="input" style="width: 100%;" data-validate="required" name="nombre_pelicula" id="nombre_pelicula" type="text" placeholder="Ingrese nombre de la pelicula">
              <br>
            </div>
            <div class="cell-md-4">
              <label for="director">Director Pelicula</label>
              <input data-role="input" style="width: 100%;" name="director_pelicula" id="director_pelicula" type="text" placeholder="Ingrese director de la pelicula">
              <br>
            </div>
            <div class="cell-md-4">
              <label for="director">Reparto</label><br>
              <input data-role="input" style="width: 100%;" name="reparto_pelicula" id="reparto_pelicula" type="text" placeholder="Ingrese reparto de la pelicula">
              <br>
            </div>
            <div class="cell-md-2 centrar">
              <label for="proximo_estreno">Próximo estreno</label>
              <br>
              <input name="proximo_estreno" id="proximo_estreno" type="checkbox" data-role="checkbox">
              <br>
            </div>
            <div class="cell-md-2 centrar">
              <label for="proximo_estreno">Restricción</label>
              <br>
              <input name="restriccion" id="restriccion" type="checkbox" data-role="checkbox">
              <br>
            </div>
            <div class="cell-md-6 fecha_restriccion">
              <label for="fecha_i_restriccion">Fecha inicio restricción</label>
              <input data-role="input" style="width: 100%;" id="fecha_inicio_restriccion" name="fecha_inicio_restriccion" type="text" datepicker data-date-format="mm/dd/yyyy">
              <br>
            </div>
            <div class="cell-md-6 fecha_restriccion">
              <label for="fecha_f_restriccion">Fecha fin restricción</label>
              <input data-role="input" style="width: 100%;" id="fecha_fin_restriccion" name="fecha_fin_restriccion" type="text" datepicker data-date-format="mm/dd/yyyy">
              <br>
            </div>
            <div class="cell-md-12">
              <label for="sinopsis">Sinopsis Pelicula</label>
              <textarea data-validate="required" name="sinopsis_pelicula" id="sinopsis_pelicula" data-role="textarea" placeholder="Ingrese sinopsis de la pelicula"></textarea>
              <br>
            </div>
            <div class="cell-md-3">
              <label for="nombre">Dirección trailer (URL)</label>
              <input style="width: 100%;" data-role="input" name="url_trailer" data-validate="required" id="url_trailer" type="text" placeholder="Ingrese url del trailer">
              <br>
            </div>
            <div class="cell-md-3">
              <label for="duracion">Duración (Minutos)</label>
              <input style="width: 100%;" type="text" data-role="input" name="duracion_pelicula" id="duracion_pelicula">
              <br>
            </div>
            <div class="cell-md-3">
              <label for="tipo_pelicula">Cine</label>
              <div id="listado_cines"></div>
              <br>
            </div>
            <div class="cell-md-3 centrar preventa">
              <label for="preventa">Mes de estreno</label>
              <br>
              <input style="width: 100%;" data-role="input" id="mes_estreno" name="mes_estreno" type="text" datepicker data-date-format="dd/mm/yyyy">
              <br>
            </div>
            <div class="cell-md-3 centrar proximo">
              <label for="tipo_pelicula">Tipo de pelicula</label>
              <br>
              <div style="display: inline-block;"><input name="tipo_pelicula_3d" id="tipo_pelicula_3d" type="checkbox" data-role="checkbox" data-caption="3D" checked></div>
              <div style="display: inline-block; margin-left: 40px;"><input name="tipo_pelicula_2d" id="tipo_pelicula_2d" type="checkbox" data-role="checkbox" data-caption="2D" checked></div>
              <br><br>
            </div>
            <div class="cell-md-3">
              <label for="clasificacion">Clasificación</label>
              <br>
              <select data-role="select" style="width: 100%;" name="clasificacion" id="clasificacion">
                <option value="TE">TODO ESPECTADOR</option>
                <option value="TE+7">TODO ESPECTADOR, INCONVENIENTE PARA MENORES DE 7 AÑOS</option>
                <option value="+14">MAYORES DE 14 AÑOS</option>
              </select>
              <br>
            </div>
            <div class="cell-md-1 centrar proximo">
              <label for="proximo_estreno">Estreno</label>
              <br>
              <input name="estreno" id="estreno" type="checkbox" data-role="checkbox">
              <br>
            </div>
            <div class="cell-md-2 centrar preventa">
              <label for="preventa">Preventa</label>
              <br>
              <input name="preventa" id="preventa" type="checkbox" data-role="checkbox">
              <br>
            </div>
            <div class="cell-md-3 active_preventa">
              <label for="fecha_inicio_preventa">Fecha inicio preventa</label>
              <input data-role="input" style="width: 100%;" id="fecha_inicio_preventa" name="fecha_inicio_preventa" type="text" datepicker data-date-format="mm/dd/yyyy">
              <br>
            </div>
            <div class="cell-md-3 active_preventa">
              <label for="fecha_fin_preventa">Fecha fin preventa</label>
              <input data-role="input" style="width: 100%;" id="fecha_fin_preventa" name="fecha_fin_preventa" type="text" datepicker data-date-format="mm/dd/yyyy">
              <br>
            </div>
            <div class="cell-md-3 active_preventa">
              <label for="horario_preventa">Horario preventa (Doblada)</label>
              <div id="content_horario_preventa"></div>
              <br>
            </div>
            <div class="cell-md-3 active_preventa">
              <label for="horario_preventa">Horario preventa (Subtitulada)</label>
              <div id="content_horario_preventa_subtitulada"></div>
              <br>
            </div>
            <div class="cell-md-12 view_2d proximo">
              <h5>FORMATO 2D</h5>
            </div>
            <div class="cell-md-3 view_2d proximo">
              <label for="tipo_pelicula">Fecha inicio</label><br>
              <input data-role="input" style="width: 100%;" name="fecha_inicio_2d" id="fecha_inicio_2d" type="text" datepicker data-date-format="dd/mm/yyyy">
              <br>
            </div>
            <div class="cell-md-3 view_2d proximo">
              <label for="tipo_pelicula">Fecha fin</label><br>
              <input data-role="input" style="width: 100%;" name="fecha_fin_2d" id="fecha_fin_2d" type="text" datepicker data-date-format="dd/mm/yyyy">
              <br>
            </div>
            <div class="cell-md-3 view_2d proximo">
              <label for="tipo_pelicula">Horarios (Doblada)</label>
              <div id="horarios_2d"></div>
              <br>
            </div>
            <div class="cell-md-3 view_2d proximo">
              <label for="tipo_pelicula">Horarios (Subtitulada)</label>
              <div id="horarios_2d_subtitulada"></div>
              <br>
            </div>
            <div class="cell-md-12 view_3d proximo">
              <h5>FORMATO 3D</h5>
            </div>
            <div class="cell-md-3 view_3d proximo">
              <label for="tipo_pelicula">Fecha inicio</label><br>
              <input data-role="input" style="width: 100%;" name="fecha_inicio_3d" id="fecha_inicio_3d" type="text" datepicker data-date-format="dd/mm/yyyy">
              <br>
            </div>
            <div class="cell-md-3 view_3d proximo">
              <label for="tipo_pelicula">Fecha fin</label><br>
              <input data-role="input" style="width: 100%;" name="fecha_fin_3d" id="fecha_fin_3d" type="text" datepicker data-date-format="dd/mm/yyyy">
              <br>
            </div>
            <div class="cell-md-3 view_3d proximo">
              <label for="tipo_pelicula">Horarios (Doblada)</label>
              <div id="horarios_3d"></div>
              <br>
            </div>
            <div class="cell-md-3 view_3d proximo">
              <label for="tipo_pelicula">Horarios (Subtitulada)</label>
              <div id="horarios_3d_subtitulada"></div>
              <br>
            </div>
          </div>
          <br>
          <div class="centrar">
            <button onclick="history.back(); return false;" class="button js-dialog-close">Regresar</button>
            <button class="button warning js-dialog-close">Registrar Pelicula</button>
            <br><br><br>
          </div>
        </form>
      </div>
    </div>

    <script>
      $(document).ready(function() {
        $("#mes_estreno").datepicker({});
        $("#fecha_inicio_2d").datepicker({});
        $("#fecha_fin_2d").datepicker({});
        $("#fecha_inicio_3d").datepicker({});
        $("#fecha_fin_3d").datepicker({});
        $("#fecha_inicio_restriccion").datepicker({});
        $("#fecha_fin_restriccion").datepicker({});
        $("#fecha_inicio_preventa").datepicker({});
        $("#fecha_fin_preventa").datepicker({});

        var options = ""
        for (i = 9; i < 24; i++) {
          for (x = 0; x < 60; x++) {
            options = options + `<option value="${i}:${x < 10 ? `0${x}`: x }">${i}:${x < 10 ? `0${x}`: x }</option>`;
          }
        }
        $("#horarios_2d").append(`<select name="horarios_pelicula_2d[]" id="horarios_pelicula_2d" data-role="select" multiple placeholder="Seleccione horarios">${options}</select>`);
        $("#horarios_2d_subtitulada").append(`<select name="horarios_pelicula_2d_subtitulada[]" id="horarios_pelicula_2d_subtitulada" data-role="select" multiple placeholder="Seleccione horarios">${options}</select>`);
        $("#horarios_3d").append(`<select name="horarios_pelicula_3d[]" id="horarios_pelicula_3d" data-role="select" multiple placeholder="Seleccione horarios">${options}</select>`);
        $("#horarios_3d_subtitulada").append(`<select name="horarios_pelicula_3d_subtitulada[]" id="horarios_pelicula_3d_subtitulada" data-role="select" multiple placeholder="Seleccione horarios">${options}</select>`);
        $("#content_horario_preventa").append(`<select name="horario_preventa[]" id="horario_preventa" data-role="select" multiple placeholder="Seleccione horarios">${options}</select>`);
        $("#content_horario_preventa_subtitulada").append(`<select name="horario_preventa_subtitulada[]" id="horario_preventa_subtitulada" data-role="select" multiple placeholder="Seleccione horarios">${options}</select>`);


        $('.preventa').hide();
        $('.active_preventa').hide();
        $('#tipo_pelicula_3d').change(function() {
          if ($(this).is(':checked')) {
            $('.view_3d').show();
          } else {
            $('.view_3d').hide();
          }
        });

        $('#tipo_pelicula_2d').change(function() {
          if ($(this).is(':checked')) {
            $('.view_2d').show();
          } else {
            $('.view_2d').hide();
          }
        });

        $('#preventa').change(function() {
          if ($(this).is(':checked')) {
            $('.active_preventa').show();
          } else {
            $('.active_preventa').hide();
          }
        });

        $('#proximo_estreno').change(function() {
          $("#estreno").prop("checked", false);
          if (!$(this).is(':checked')) {
            $('.proximo').show();
            $('.preventa').hide();
          } else {
            $('.proximo').hide();
            $('.preventa').show();
          }
        });

        $('.fecha_restriccion').hide();

        $('#restriccion').change(function() {
          if ($(this).is(':checked')) {
            $('.fecha_restriccion').show();
          } else {
            $('.fecha_restriccion').hide();
          }
        });

        $.get(
          "../api/getCines.php",
          function(data) {
            let options = "";
            for (i = 0; i < data.length; i++) {
              options = options + `<option value="${data[i]["id"]}">${data[i]["nombre"]}</option>`;
            }

            let selectCines = `<select id="id_cine" name="id_cine" data-role="select">
                        ${options}
                    </select>`;

            $("#listado_cines").append(selectCines);
          },
          "json"
        );
        $("#form-add-cartelera").submit(function(e) {
          e.preventDefault();
          var nombre_pelicula = $("#nombre_pelicula").val();
          var sinopsis_pelicula = $("#sinopsis_pelicula").val();
          var duracion_pelicula = $("#duracion_pelicula").val();
          var url_trailer = $("#url_trailer").val();


          if (
            nombre_pelicula !== "" && sinopsis_pelicula !== "" && url_trailer !== ""
          ) {
            $.ajax({
              url: "../api/addPelicula.php",
              type: "POST",
              data: new FormData(this),
              contentType: false,
              cache: false,
              processData: false,
              success: function(result) {
                if (result == 1) {
                  Swal.fire({
                    type: 'success',
                    title: 'Información',
                    text: 'Pelicula registrada correctamente.',
                  }).then((r) => {
                    location.href = "./admin_peliculas.php"
                  })
                } else {
                  Swal.fire({
                    type: 'error',
                    title: 'Ha ocurrido un error!',
                    text: `${result}`
                  })
                }
              }
            });
          } else {
            Swal.fire({
              type: 'warning',
              title: 'Oops...',
              text: 'Debes completar todos los campos.'
            })
          }
        });
      });
    </script>
    <?php
    include("./footer.php");
    ?>
  </body>

  </html>
<?php
} else {
  // Redirect them to the login page
  header("Location: ./index.php");
}
?>