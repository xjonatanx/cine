<?php
session_start();
if (isset($_SESSION['email'])) {
?>
	<html>
	<?php
	include("./head.php")
	?>

	<body>
		<?php
		include("./aside.php");
		?>
		<div class="shifted-content-2 h-100 p-ab">
			<div class="appbar bg-red z-1" data-role="appbar">
				<button class="app-bar-item c-pointer" id="sidebar-toggle-4">
					<span class="mif-menu fg-white"></span>
				</button>
			</div>

			<div class="h-100 p-4">
				<p class="h1">Editar slider</p>
				<br>
				<div class="row">
					<div class="cell-md-12">
						<form data-role="validator" id="form-slider" method="post" enctype="multipart/form-data">
							<div class="row">
								<div class="cell-md-2" style="padding: 0px !important;">
									<div class="img-container thumbnail"><img id="img_slider" width="300px" height="200px" src="" alt=""></div>
									<br>
								</div>
								<div class="cell-md-10" style="padding: 0px !important;">
									<label for="nombre">Imagen (Escritorio: 1480 x 400, Movil: 375 x 370)</label>
									<input data-button-title="+" data-validate="required" id="uploadImageSlider" type="file" accept="image/*" name="imageSlider" type="file" data-role="file" data-prepend="Seleccione imagen:">
									<input style="display: none;" type="text" id="id_slider" name="id_slider" />
									<input style="display: none;" type="text" id="url_imagen_slider_actual" name="url_imagen_slider_actual" />
									<br>
									<button class="button info js-dialog-close">Cambiar Imagen</button>
									<br><br>
								</div>
							</div>
						</form>
					</div>
					<div class="cell-md-12">
						<label for="tipo">Tipo de imagen</label>
						<div id="listado_tipos"></div>
					</div>
				</div>
				<form data-role="validator" id="form-edit-slider" method="post" enctype="multipart/form-data">
					<div class="row">
						<div class="cell-md-6">
							<br>
							<label for="nombre">Nombre referencial</label>
							<input data-role="input" data-validate="required" id="nombre_referencial" type="text" placeholder="Ingrese nombre referencial del slider">
						</div>
						<div class="cell-md-6">
							<br>
							<label for="nombre">Orden de visualización</label>
							<input data-role="input" data-validate="required" id="orden" name="orden" type="text" placeholder="Número para orden de visualización">
						</div>
						<div class="cell-md-12">
							<br>
							<label for="enlace">Dirección del enlace</label>
							<input data-role="input" data-validate="required" id="enlace" type="text" placeholder="Ingrese dirección del enlace">
						</div>
						<div class="cell-md-12">
							<br>
							<label for="tipo_pelicula">Cine</label>
							<div id="listado_cines"></div>
						</div>
					</div>
					<br><br>
					<div class="centrar">
						<button onclick="history.back();" class="button js-dialog-close">Regresar</button>
						<button onclick="editarSlider();" class="button warning js-dialog-close">Editar Slider</button>
					</div>
				</form>
				<br><br>
			</div>
		</div>

		<script>
			let params = new URLSearchParams(location.search);
			var id_slider = params.get('id');
			var url_imagen_slider_actual = "";
			var url_imagen_slider_movil_actual = "";
			var id_cine = "";

			function editarSlider() {
				var id_cine = $("#id_cine").val();
				var nombre_referencial = $("#nombre_referencial").val();
				var orden = $("#orden").val();
				var tipo_imagen = $("#tipo_imagen").val();
				var enlace = $("#enlace").val();

				if (
					nombre_referencial !== "" && id_cine !== ""
				) {
					$.post("../api/editSlider.php", {
						id: id_slider,
						nombre_referencial: nombre_referencial,
						orden: orden,
						id_cine: id_cine,
						tipo_imagen: tipo_imagen,
						enlace: enlace
					}, function(result) {
						if (result == 1) {
							Swal.fire({
								type: 'success',
								title: 'Información',
								text: 'Slider modificado correctamente.',
							}).then((r) => {
								location.href = "./admin_slider.php"
							})
						} else {
							Swal.fire({
								type: 'error',
								title: 'Ha ocurrido un error!',
								text: `${result}`
							})
						}
					});
				} else {
					Swal.fire({
						type: 'warning',
						title: 'Oops...',
						text: 'Debes completar todos los campos.'
					})
				}
			}

			$(document).ready(function() {
				$("#form-edit-slider").on('submit', function(evt) {
					evt.preventDefault();
				});
				$("#form-slider").on('submit', function(e) {
					e.preventDefault();
					if (id_slider && url_imagen_slider_actual) {
						$.ajax({
							url: "../api/change_slider.php",
							type: "POST",
							data: new FormData(this),
							contentType: false,
							cache: false,
							processData: false,
							success: function(result) {
								if (result == 1) {
									Swal.fire({
										type: 'success',
										title: 'Información',
										text: 'Imagen modificada correctamente.',
									}).then((r) => {
										location.reload();
									})
								} else {
									Swal.fire({
										type: 'error',
										title: 'Ha ocurrido un error!',
										text: `${result}`
									})
								}
							}
						});
					} else {
						Swal.fire({
							type: 'warning',
							title: 'Oops...',
							text: 'Debes completar todos los campos requeridos.'
						})
					}
				});
				$.get("../api/getSliderById.php?id=" + id_slider, function(data) {
					$('#nombre_referencial').val(data[0]["nombre"]);
					$('#orden').val(data[0]["orden"]);
					$('#enlace').val(data[0]["enlace"]);
					$('#id_cine').val(data[0]["fk_id_cine"]);
					$("#img_slider").attr("src", `../${data[0]["url_slider"]}`);
					$("#img_slider_movil").attr("src", `../${data[0]["url_slider_movil"]}`);
					url_imagen_slider_actual = data[0]["url_slider"];
					url_imagen_slider_movil_actual = data[0]["url_slider_movil"];
					$("#url_imagen_slider_actual").val(data[0]["url_slider"]);
					$("#url_imagen_slider_movil_actual").val(data[0]["url_slider_movil"]);
					id_cine = data[0]["fk_id_cine"];
					$("#id_slider").val(id_slider);

					let tipos_imagen = ["escritorio", "movil"];
					let options_tipo = "";
					for (let i = 0; i < tipos_imagen.length; i++) {
						if (data[0]["tipo"] == tipos_imagen[i]) {
							options_tipo = options_tipo + `<option selected = "selected" value="${tipos_imagen[i]}">${MaysPrimera(tipos_imagen[i].toLowerCase())}</option>`;
						} else {
							options_tipo = options_tipo + `<option value="${tipos_imagen[i]}">${MaysPrimera(tipos_imagen[i].toLowerCase())}</option>`;
						}
					}
					let selectTipos = `<select id="tipo_imagen" name="tipo_imagen" data-role="select">
                        ${options_tipo}
                    </select>`;
					$("#listado_tipos").append(selectTipos);

				}, "json")

				$.get(
					"../api/getCines.php",
					function(data) {
						let options = "";
						for (i = 0; i < data.length; i++) {
							if (data[i]["id"] == id_cine) {
								options = options + `<option selected = "selected" value="${data[i]["id"]}">${data[i]["nombre"]}</option>`;
							} else {
								options = options + `<option value="${data[i]["id"]}">${data[i]["nombre"]}</option>`;
							}

						}

						let selectCines = `<select id="id_cine" data-role="select">
                        ${options}
                    </select>`;

						$("#listado_cines").append(selectCines);
					},
					"json"
				);
			});

			function MaysPrimera(string) {
				return string.charAt(0).toUpperCase() + string.slice(1);
			}
		</script>
		<?php
		include("./footer.php");
		?>
	</body>

	</html>
<?php
} else {
	// Redirect them to the login page
	header("Location: ./index.php");
}
?>