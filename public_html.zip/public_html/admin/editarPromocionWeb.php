<?php
session_start();
if (isset($_SESSION['email'])) {
?>
  <html>
  <?php
  include("./head.php")
  ?>

  <body>
    <?php
    include("./aside.php");
    ?>
    <div class="shifted-content-2 h-100 p-ab">
      <div class="appbar bg-red z-1" data-role="appbar">
        <button class="app-bar-item c-pointer" id="sidebar-toggle-4">
          <span class="mif-menu fg-white"></span>
        </button>
      </div>

      <div class="h-100 p-4">
        <p class="h1">Editar imagen promoción</p>
        <br>
        <div class="row">
          <div class="cell-md-12">
            <form data-role="validator" id="form-promocion" method="post" enctype="multipart/form-data">
              <div class="row">
                <div class="cell-md-2" style="padding: 0px !important;">
                  <div class="img-container thumbnail"><img id="img_promocion" width="300px" height="200px" src="" alt=""></div>
                  <br>
                </div>
                <div class="cell-md-10" style="padding: 0px !important;">
                  <label for="nombre">Imagen promocion (1752 x 1066)</label>
                  <input data-button-title="+" data-validate="required" id="uploadImagePromocion" type="file" accept="image/*" name="imagePromocion" type="file" data-role="file" data-prepend="Seleccione imagen:">
                  <input style="display: none;" type="text" id="id_promocion" name="id_promocion" />
                  <input style="display: none;" type="text" id="url_imagen_promocion_actual" name="url_imagen_promocion_actual" />
                  <br>
                  <button class="button info js-dialog-close">Cambiar Imagen</button>
                  <br><br>
                </div>
              </div>
            </form>
          </div>
        </div>
        <form data-role="validator" id="form-edit-promocion" method="post" enctype="multipart/form-data">
          <div class="row">
            <div class="cell-md-4">
              <br>
              <label for="nombre">Nombre referencial</label>
              <input data-role="input" data-validate="required" id="nombre_referencial" type="text" placeholder="Ingrese nombre referencial de la promoción">
            </div>
            <div class="cell-md-4">
              <br>
              <label for="nombre">Orden de visualización</label>
              <input data-role="input" data-validate="required" id="orden" name="orden" type="text" placeholder="Número para orden de visualización">
            </div>
            <div class="cell-md-4">
              <br>
              <label for="tipo_pelicula">Cine</label>
              <div id="listado_cines"></div>
            </div>
          </div>
          <br><br>
          <div class="centrar">
            <button onclick="history.back();" class="button js-dialog-close">Regresar</button>
            <button onclick="editarPromocionWeb();" class="button warning js-dialog-close">Editar Promoción</button>
          </div>
        </form>
        <br><br>
      </div>
    </div>

    <script>
      let params = new URLSearchParams(location.search);
      var id_promocion = params.get('id');
      var url_imagen_promocion_actual = "";
      var id_cine = "";

      function editarPromocionWeb() {
        var id_cine = $("#id_cine").val();
        var nombre_referencial = $("#nombre_referencial").val();
        var orden = $("#orden").val();

        if (
          nombre_referencial !== "" && id_cine !== ""
        ) {
          $.post("../api/editPromocionWeb.php", {
            id: id_promocion,
            nombre_referencial: nombre_referencial,
            orden: orden,
            id_cine: id_cine
          }, function(result) {
            if (result == 1) {
              Swal.fire({
                type: 'success',
                title: 'Información',
                text: 'Imagen modificada correctamente.',
              }).then((r) => {
                location.href = "./admin_promociones_web.php"
              })
            } else {
              Swal.fire({
                type: 'error',
                title: 'Ha ocurrido un error!',
                text: `${result}`
              })
            }
          });
        } else {
          Swal.fire({
            type: 'warning',
            title: 'Oops...',
            text: 'Debes completar los campos solicitados.'
          })
        }
      }

      $(document).ready(function() {
        $("#form-edit-promocion").on('submit', function(evt) {
          evt.preventDefault();
        });
        $("#form-promocion").on('submit', function(e) {
          e.preventDefault();
          if (id_promocion && url_imagen_promocion_actual) {
            $.ajax({
              url: "../api/change_promocion_web.php",
              type: "POST",
              data: new FormData(this),
              contentType: false,
              cache: false,
              processData: false,
              success: function(result) {
                if (result == 1) {
                  Swal.fire({
                    type: 'success',
                    title: 'Información',
                    text: 'Imagen modificada correctamente.',
                  }).then((r) => {
                    location.reload();
                  })
                } else {
                  Swal.fire({
                    type: 'error',
                    title: 'Ha ocurrido un error!',
                    text: `${result}`
                  })
                }
              }
            });
          } else {
            Swal.fire({
              type: 'warning',
              title: 'Oops...',
              text: 'Debes completar todos los campos requeridos.'
            })
          }
        });
        $.get("../api/getPromocionWebById.php?id=" + id_promocion, function(data) {
          $('#nombre_referencial').val(data[0]["nombre_imagen"]);
          $('#orden').val(data[0]["orden"]);
          $('#id_cine').val(data[0]["fk_id_cine"]);
          $("#img_promocion").attr("src", `../${data[0]["path_direccion"]}`);
          url_imagen_promocion_actual = data[0]["path_direccion"];
          $("#url_imagen_promocion_actual").val(data[0]["path_direccion"]);
          id_cine = data[0]["fk_id_cine"];
          $("#id_promocion").val(id_promocion);
        }, "json")

        $.get(
          "../api/getCines.php",
          function(data) {
            let options = "";
            for (i = 0; i < data.length; i++) {
              if (data[i]["id"] == id_cine) {
                options = options + `<option selected = "selected" value="${data[i]["id"]}">${data[i]["nombre"]}</option>`;
              } else {
                options = options + `<option value="${data[i]["id"]}">${data[i]["nombre"]}</option>`;
              }

            }

            let selectCines = `<select id="id_cine" data-role="select">
                        ${options}
                    </select>`;

            $("#listado_cines").append(selectCines);
          },
          "json"
        );
      });
    </script>
    <?php
    include("./footer.php");
    ?>
  </body>

  </html>
<?php
} else {
  // Redirect them to the login page
  header("Location: ./index.php");
}
?>