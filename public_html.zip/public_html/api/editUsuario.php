<?php
include "./conexion.php";
$id = $_POST['id'];
$email = $_POST['email'];

$sql = "UPDATE usuarios SET 
        email = '$email'
        WHERE id = $id";

if ($conn->query($sql) === TRUE) {
  echo true;
} else {
  echo $conn->error;
}

$conn->close();
?>