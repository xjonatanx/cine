<?php
include("./conexion.php");

$sql = "SELECT * FROM birthday WHERE id = 1;";
$result = $conn->query($sql);
$return_arr = array();
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $row_array['id'] = $row['id'];
        $row_array['descripcion'] = $row['descripcion'];
        $row_array['url_imagen'] = $row['url_imagen'];
        array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
} else {
    echo 0;
}
$conn->close();
?>