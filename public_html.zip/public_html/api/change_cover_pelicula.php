<?php
  $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
  $path = '../img/'; // upload directory
  $img = $_FILES['imageCover']['name'];
  $tmp = $_FILES['imageCover']['tmp_name'];
  // get uploaded file's extension
  $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
  // can upload same image using rand function
  $final_image = date("dmYHis").rand(1000,1000000).$img;
  // check's valid format

  if(in_array($ext, $valid_extensions)) 
  { 
      $path = $path.strtolower($final_image); 
      $final_path = "../img/".strtolower($final_image); 
      move_uploaded_file($tmp,$path);
      $id = $_POST['id_pelicula_cover'];
      $url_actual = $_POST['url_imagen_cover_actual'];
      unlink('../'.$url_actual);
      //include database configuration file
      include("./conexion.php");
      //insert form data in the database
      $insert = $conn->query("UPDATE peliculas SET cover = '$final_path'  WHERE id = $id;");
      echo $insert ? true : $conn->error;
  } 
  else 
  {
  echo 'No se ha seleccionado ninguna imagen o el formato del archivo no está permitido.';
  }
?>