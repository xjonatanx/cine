<?php
function saltoLinea($str) {
  return str_replace(array("\r\n", "\r", "\n"), "<br />", $str);
}
$email_origen = $_POST['email'];
$email_destino = "contacto@cinepaseodelvalle.cl";
$asunto = $_POST['motivo'];
$nombre = $_POST['nombre'];
$cine = $_POST['cine'];
$telefono = $_POST['telefono'];
$mensaje = saltoLinea($_POST['mensaje']);

if ($email_origen != "") {
// Cuerpo del mensaje
$mensaje = "$cine\n\n$mensaje\n\nEnviado por $nombre.";
// headers del email
$headers = "From: $email_origen\n\n";
// Enviamos el mensaje
if (mail($email_destino, $asunto, $mensaje, $headers)) {
echo "<script>
        alert('Email enviado correctamente.');
        window.location= '../../contacto.php'
      </script>";
} else {
echo "<script>
        alert('Error al enviar email.');
        window.location= '../../contacto.php'
      </script>";
}
} else {
echo "<script>
        alert('Debe ingresar un email.');
        window.location= '../../contacto.php'
      </script>";
}
?>
