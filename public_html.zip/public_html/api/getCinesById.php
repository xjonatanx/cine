<?php
include("./conexion.php");
$id = $_GET['id'];
$sql = "SELECT * FROM cines WHERE deleted = 0 AND id = $id;";
$result = $conn->query($sql);
$return_arr = array();
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $row_array['id'] = $row['id'];
        $row_array['nombre'] = $row['nombre'];
        $row_array['ciudad'] = $row['ciudad'];
        $row_array['direccion'] = $row['direccion'];
        $row_array['hora_apertura'] = $row['hora_apertura'];
        $row_array['hora_cierre'] = $row['hora_cierre'];
        $row_array['dia_inicio'] = $row['dia_inicio'];
        $row_array['dia_fin'] = $row['dia_fin'];
        $row_array['dir_map'] = $row['dir_map'];
        $row_array['url_imagen'] = $row['url_imagen'];
        array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
} else {
    echo 0;
}
$conn->close();
?>