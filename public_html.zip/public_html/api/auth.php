<?php
include("./conexion.php");
$email = $_POST["email"];
$password = md5($_POST["password"]);
$sql = "SELECT email, avatar, can_admin_user FROM usuarios WHERE email = '$email' AND passwd = '$password' AND bloqueado = 0;";
$result = $conn->query($sql);

session_start();
$email = "";
$avatar = "";

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $email = $row["email"];
        $avatar = $row["avatar"];
        $can_admin_user = $row["can_admin_user"];
    }
    $mensaje = "Sesión finalizada.";
    echo json_encode(array('email' => $email, 'avatar' => $avatar, 'can_admin_user' => $can_admin_user));
    $_SESSION['email'] = $email;
    $_SESSION['can_admin_user'] = $can_admin_user;
} else {
    echo 0;
}
$conn->close();
?>