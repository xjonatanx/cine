<?php
include "./conexion.php";
$id = $_POST['id'];
$passwd = md5($_POST['passwd']);

$sql = "UPDATE usuarios SET 
        passwd = '$passwd'
        WHERE id = $id";

if ($conn->query($sql) === TRUE) {
  echo true;
} else {
  echo $conn->error;
}

$conn->close();
?>