<?php
include("./conexion.php");
$id = $_GET['id'];
$sql = "SELECT * FROM usuarios WHERE id = $id;";
$result = $conn->query($sql);
$return_arr = array();
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $row_array['id'] = $row['id'];
        $row_array['email'] = $row['email'];
        $row_array['avatar'] = $row['avatar'];
        array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
} else {
    echo 0;
}
$conn->close();
?>