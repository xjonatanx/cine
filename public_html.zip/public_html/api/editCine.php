<?php
include "./conexion.php";
$id = $_POST['id'];
$nombre_cine = $_POST['nombre_cine'];
$ciudad_cine = $_POST['ciudad_cine'];
$direccion_cine = $_POST['direccion_cine'];
$apertura_cine = $_POST['apertura_cine'];
$cierre_cine = $_POST['cierre_cine'];
$dia_inicio_cine = $_POST['dia_inicio_cine'];
$dia_fin_cine = $_POST['dia_fin_cine'];
$dir_map_cine = $_POST['dir_map_cine'];

$sql = "UPDATE cines SET 
        nombre = '$nombre_cine', 
        ciudad = '$ciudad_cine', 
        direccion = '$direccion_cine', 
        hora_apertura = '$apertura_cine', 
        hora_cierre = '$cierre_cine', 
        dia_inicio = '$dia_inicio_cine', 
        dia_fin = '$dia_fin_cine', 
        dir_map = '$dir_map_cine' 
        WHERE id = $id";

if ($conn->query($sql) === TRUE) {
  echo true;
} else {
  echo $conn->error;
}

$conn->close();
?>