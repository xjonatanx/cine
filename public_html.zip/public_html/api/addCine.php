
<?php
$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
$path = '../img/'; // upload directory
$img = $_FILES['image']['name'];
$tmp = $_FILES['image']['tmp_name'];
// get uploaded file's extension
$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
// can upload same image using rand function
$final_image = date("dmYHis") . rand(1000, 1000000) . $img;
// check's valid format

if (in_array($ext, $valid_extensions)) {
  $path = $path . strtolower($final_image);
  $final_path = "img/" . strtolower($final_image);
  move_uploaded_file($tmp, $path);
    $nombre_cine = $_POST['nombre_cine'];
    $ciudad_cine = $_POST['ciudad_cine'];
    $direccion_cine = $_POST['direccion_cine'];
    $apertura_cine = $_POST['apertura_cine'];
    $cierre_cine = $_POST['cierre_cine'];
    $dia_inicio_cine = $_POST['dia_inicio_cine'];
    $dia_fin_cine = $_POST['dia_fin_cine'];
    $dir_map_cine = $_POST['dir_map_cine'];
    //include database configuration file
    include("./conexion.php");
    //insert form data in the database
    $insert = $conn->query("INSERT INTO cines (nombre, ciudad, direccion, hora_apertura, hora_cierre, dia_inicio, dia_fin, dir_map, url_imagen, deleted)
            VALUES ('$nombre_cine', '$ciudad_cine', '$direccion_cine', '$apertura_cine', '$cierre_cine', '$dia_inicio_cine', '$dia_fin_cine', '$dir_map_cine', '$final_path', 0);");
    echo $insert ? true : $conn->error;
} else {
  echo 'No se ha seleccionado ninguna imagen o el formato del archivo no está permitido.';
}
?>