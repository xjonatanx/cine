<?php
include("./conexion.php");

$sql = "SELECT peliculas.id as 'id', peliculas.nombre_pelicula as 'nombre_pelicula', peliculas.director_pelicula as 'director_pelicula', peliculas.reparto_pelicula as 'reparto_pelicula', peliculas.sinopsis_pelicula as 'sinopsis_pelicula', peliculas.fecha_inicio_3d as 'fecha_inicio_3d', peliculas.fecha_fin_3d as 'fecha_fin_3d', peliculas.fecha_inicio_2d as 'fecha_inicio_2d', peliculas.fecha_fin_2d as 'fecha_fin_2d', peliculas.horarios_pelicula_2d as 'horarios_pelicula_2d', peliculas.horarios_pelicula_3d as 'horarios_pelicula_3d', peliculas.duracion as 'duracion', peliculas.2d as '2d', peliculas.3d as '3d', peliculas.estreno as 'estreno', peliculas.preventa as 'preventa', peliculas.clasificacion as 'clasificacion', peliculas.cover as 'cover', peliculas.banner as 'banner', peliculas.proximo_estreno as 'proximo_estreno', peliculas.trailer as 'trailer', cines.nombre as 'cine' FROM peliculas INNER JOIN cines ON peliculas.fk_id_cine = cines.id;";
$result = $conn->query($sql);
$return_arr = array();
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $row_array['id'] = $row['id'];
        $row_array['nombre_pelicula'] = $row['nombre_pelicula'];
        $row_array['director_pelicula'] = $row['director_pelicula'];
        $row_array['reparto_pelicula'] = $row['reparto_pelicula'];
        $row_array['sinopsis_pelicula'] = $row['sinopsis_pelicula'];
        $row_array['fecha_inicio_2d'] = $row['fecha_inicio_2d'];
        $row_array['fecha_fin_2d'] = $row['fecha_fin_2d'];
        $row_array['fecha_inicio_3d'] = $row['fecha_inicio_3d'];
        $row_array['fecha_fin_3d'] = $row['fecha_fin_3d'];
        $row_array['horarios_pelicula_3d'] = $row['horarios_pelicula_3d'];
        $row_array['horarios_pelicula_2d'] = $row['horarios_pelicula_2d'];
        $row_array['2d'] = $row['2d'];
        $row_array['3d'] = $row['3d'];
        $row_array['duracion'] = $row['duracion'];
        $row_array['todo_espectador'] = $row['todo_espectador'];
        $row_array['estreno'] = $row['estreno'];
        $row_array['preventa'] = $row['preventa'];
        $row_array['proximo_estreno'] = $row['proximo_estreno'];
        $row_array['cover'] = $row['cover'];
        $row_array['banner'] = $row['banner'];
        $row_array['trailer'] = $row['trailer'];
        $row_array['cine'] = $row['cine'];
        array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
} else {
    echo 0;
}
$conn->close();
?>