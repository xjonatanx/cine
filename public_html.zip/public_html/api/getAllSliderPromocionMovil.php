<?php
include("./conexion.php");


$id_cine = $_GET["id_cine"];

$sql = "";

if ($id_cine == "") {
    $sql = "SELECT slider_promociones.id as 'id', slider_promociones.nombre as 'nombre', slider_promociones.create_at as 'create_at', cines.nombre as 'nombre_cine', slider_promociones.fk_id_cine as 'fk_id_cine', slider_promociones.url_slider as 'url_slider', slider_promociones.tipo as 'tipo', slider_promociones.create_at as 'create_at' FROM slider_promociones INNER JOIN cines ON slider_promociones.fk_id_cine = cines.id WHERE slider_promociones.tipo = 'movil';";
}

if ($id_cine != "") {
    $sql = "SELECT slider_promociones.id as 'id', slider_promociones.nombre as 'nombre', slider_promociones.create_at as 'create_at', cines.nombre as 'nombre_cine', slider_promociones.fk_id_cine as 'fk_id_cine', slider_promociones.url_slider as 'url_slider', slider_promociones.tipo as 'tipo', slider_promociones.create_at as 'create_at' FROM slider_promociones INNER JOIN cines ON slider_promociones.fk_id_cine = cines.id WHERE slider_promociones.tipo = 'movil' AND slider_promociones.fk_id_cine = $id_cine;";
}


$result = $conn->query($sql);
$return_arr = array();
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $row_array['id'] = $row['id'];
        $row_array['nombre'] = $row['nombre'];
        $row_array['nombre_cine'] = $row['nombre_cine'];
        $row_array['fk_id_cine'] = $row['fk_id_cine'];
        $row_array['url_slider'] = $row['url_slider'];
        $row_array['create_at'] = $row['create_at'];
        $row_array['tipo'] = $row['tipo'];
        $row_array['create_at'] = $row['create_at'];
        array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
} else {
    echo 0;
}
$conn->close();
?>