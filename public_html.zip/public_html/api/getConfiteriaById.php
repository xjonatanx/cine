<?php
include("./conexion.php");
$id = $_GET['id'];
$sql = "SELECT * FROM confiteria WHERE id = $id;";
$result = $conn->query($sql);
$return_arr = array();
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $row_array['id'] = $row['id'];
        $row_array['nombre_imagen'] = $row['nombre_imagen'];
        $row_array['orden'] = $row['orden'];
        $row_array['path_direccion'] = $row['path_direccion'];
        $row_array['create_at'] = $row['create_at'];
        $row_array['fk_id_cine'] = $row['fk_id_cine'];
        array_push($return_arr,$row_array);
    }
    echo json_encode($return_arr);
} else {
    echo 0;
}
$conn->close();
?>