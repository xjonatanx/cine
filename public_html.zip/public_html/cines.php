<!DOCTYPE html>
<html>
<?php
$title = "Cines";
include "./head.php"
?>

<body style="background-color: #e1e1e1;">
  <div class="container" style="background-color: white; padding-left: 0px; padding-right: 0px;">
      <!-- TOP NAV -->
      <?php
      $active = "cines";
      include "./nav.php";
      ?>
      <div class="row" style="width: 100%;">
        <div class="cell-sm-full cell-md-full cell-lg-full titulos">
          <b><span>NUESTROS CINES</span></b>
        </div>
      </div>
      <div id="content-cines"></div>
      <br>
  </div>
  
  <?php
  include "./footer.php"
  ?>
  <script>
    $(document).ready(function() {
      $.get("./api/getCines.php", function(cines, status) {
        let html = "";
        for (let i = 0; i < cines.length; i++) {
          html = html + `<div class="row">
                             <div style="padding-top: 20px !important; padding-bottom: 20px !important;" class="cell-sm-full cell-md-full cell-lg-full ${(i%2) ? "fondo-gray" : "fondo-orange"}">
                                 <div class="row">
                                     <div class="cell-sm-full cell-md-6 cell-lg-6 col-img" style="text-align: center;">
                                         <img class="img-cines" src="${cines[i]["url_imagen"]}" alt="">
                                     </div>
                                     <div class="cell-sm-full cell-md-6 cell-lg-6 col-img">
                                        <div class="card-content p-2 ">
                                            <h4 class="titulo-cines">${cines[i]["ciudad"]}</h4>
                                            <span class="descripcion-cine"><span class="mif-location"></span> ${cines[i]["direccion"]}</span><br>
                                            <h4 class="titulo-horario">Horario de atención</h4>
                                            <span class="descripcion-cine">de ${cines[i]["hora_apertura"].substring(0, cines[i]["hora_apertura"].length - 3)} a ${cines[i]["hora_cierre"].substring(0, cines[i]["hora_apertura"].length - 3)} hrs de ${cines[i]["dia_inicio"]} a ${cines[i]["dia_fin"]}</span>
                                            <br>
                                            <iframe class="mapa" src="${cines[i]["dir_map"]}" height="200" frameborder="0" style="border: 0; width: 100%;" allowfullscreen></iframe>
                                        </div>
                                     </div>
                                 </div>
                             </div>
                          </div><br><br>`;
        }
        $("#content-cines").html(
          html
        )
      }, "json");
    });
  </script>
</body>
<style>
  .jconfirm-box-container {
    margin: 0 auto !important;
  }
</style>

</html>