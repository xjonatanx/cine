<!DOCTYPE html>
<html>
<?php
$title = "Promociones";
include "./head.php"
?>
<body style="background-color: #e1e1e1;">
    <div class="container" style="background-color: white; padding-left: 0px; padding-right: 0px;">
        <!-- TOP NAV -->
      <?php 
        $active = "promociones";
        include "./nav.php"; 
      ?>
      <div class="row" style="width: 100%;">
        <div class="cell-sm-full cell-md-full cell-lg-full titulos">
          <b><span>PROMOCIONES</span></b>
        </div>
      </div>
      <div id="div-img"></div>
      <br><br><br>
    </div>
  <?php
    include "./footer.php"
  ?>
  <script>
    var id_cine = "";
      $(document).ready(function() {
            if(localStorage.getItem("id_cine")) {
                id_cine = localStorage.getItem("id_cine");
            }
          $.get("./api/getAllPromocionesWeb.php?id_cine=" + id_cine, function(data){
            let section_image = "";
            data.forEach(promocion => {
                section_image = section_image + `
                <div class="cell-sm-full cell-md-full cell-lg-full centrar" style="padding-left: 10px !important; padding-right: 10px !important;">
                  <img src="${promocion.path_direccion}" width="100%" alt="">
                </div>`;
            });
              
              $("#div-img").append(
                  `
                <div class="row">
                    ${section_image}
                </div>                `
              );
          }, "json");
      });
  </script>
</body>
<style>
    .jconfirm-box-container {
        margin: 0 auto !important;
    }
</style>
</html>
